# Consolidation audit

Scope: every resource, manifest, configuration, item migration and command in this new checkout. The uploaded originals exceeded the transfer limit and were not inspected, merged or pruned. Nothing from an unseen original server has been deleted.

| Overlap | Kept | Removed or consolidated |
| --- | --- | --- |
| Crime radius alerts, police radius alerts, emergency queue | `egg_dispatch`: service scope, history, accepted unit, persistence | The two older client dispatch handlers and their separate server alert loops. The police export is a compatibility facade into the same queue. |
| GPS, HUD and dispatch postal examples | `egg_work.Config.Postals`, shared server/client nearest-postal export | Dispatch's competing hardcoded postal anchors. The current original directory is small; no copied full map grid is claimed. |
| Multiple progress displays | `egg_hud` shared green task display when started | Work's separate display is suppressed when the shared HUD is running. A native fallback remains for a server using its original HUD. Only one is drawn. |
| Generic phone/appearance/HUD command names | Vendor phone and Illenium commands; `/eggphone`, `/eggappearance`, `/egghud` aliases | The expansion's generic `/appearance` and `/hud` registrations, avoiding takeover of installed commands. |
| Repeated item import sections | `sql/10_items.sql`, 33 unique original items | Work/drug migrations now create only their own tables. Old ESX inventory items are retained. |
| Duplicate ESX local in HUD | One shared-object binding | Repeated declaration removed. |
| Existing HUD versus new lower HUD | Existing upper-right Egg RP information | The new HUD has no upper-right panel. Enable it after hiding the old lower section; the original HUD source is required to make that exact edit. |
| Existing default menus versus Egg menu renderer | One registered renderer at a time | The optional Egg theme replaces the default registration; stopping it restores the original. No menu source files are overwritten. |
| Existing character login versus new spawn selector | Existing character/appearance backend | Spawn selector handles initial location only, defaults disabled and never adds create/delete/reselect operations. |
| Repeated recovery/identity rules | Bound action helpers in `egg_core/server_api.lua` | Helpers bind the original character across CFX callable-table references and fresh coroutines. Direct native operations also check stable identities. |

Housing, burglary, drug laboratories and spawn previews use different reserved ranges: housing 300001 onward; burglary 400000 + source; labs 500000 + source; preview 600000 + source. The 65536-wide source ranges do not intersect. Reserve these ranges from other installed instance resources or configure alternatives before staging.

An exact-content hash scan found no duplicated source/assets, and a command scan found no repeated command registrations in this checkout. Similar roles such as personal police lockers, room ownership and business banking remain separate because they provide different gameplay; removing one would remove a requested capability. Standard and `egg_` inventory names in compatibility allowlists are not duplicate grants.

This audit covers source. A staging audit must also inspect the existing resources tree and `server.cfg` for a second garage, HUD, multijob handler, robbery/dispatch resource or competing item/command registration. That tree was not available here.
