# Menu polish

`egg_menu` provides one original charcoal/red renderer for normal ESX default menus. Keyboard arrows browse and adjust sliders, Enter selects, and Back closes. Titles/items render as text; embedded HTML labels are stripped. All gameplay still goes through the original resource callbacks and server validations.

`Config.Enabled` defaults to false. Enable it on staging after your original `esx_menu_default` starts. It registers the standard default type; it does not edit the original menu files, phone, inventory, or Illenium UI. Disable it to retain your original renderer. On a normal stop it closes menus and restores the captured original renderer. Do not switch renderers while players have active menus.

Standard nested menus, refresh, selected entries, numeric sliders and zero-based option sliders are supported. Disabled/unselectable rows cannot submit. Numeric sliders clamp at limits. Version-specific HTML/custom components and every third-party menu have not been verified. Keep your existing menu for scripts relying on those features.

The implementation follows the public ESX menu API. The exact source for the user-named 1.4.36 build was unavailable; compatibility requires the documented `RegisterType`, `RegisteredTypes`, `GetOpened` and dot-call menu methods. Test your inventory, business, job and appearance menus on a real client before enabling it for all players.
