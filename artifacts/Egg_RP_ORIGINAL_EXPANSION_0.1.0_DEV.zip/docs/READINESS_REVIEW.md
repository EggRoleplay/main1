# Readiness review

The build supports local development, syntax checks, simulated ESX/CFX actions and packaging. It is a staging development build. Production RP readiness has not been established.

Confirmed issues corrected during review:

- CFX function references are callable tables and run on fresh coroutines; the core now accepts them and binds helpers explicitly across locks. Decoded ESX player tables are compared using immutable identifiers rather than table equality.
- Late callbacks cannot pay a reused player source or clock a replacement player on duty. Fingerprint requests recheck the target after database reads.
- Crime completion cleanup checks the expected local session; it cannot tear down a replacement character's new contract.
- Business item delivery compensates stored revenue/commissions before refunding; failed compensation is audited rather than issuing duplicate money.
- Housing reconnects have a durable exterior return record, matching the burglary recovery pattern. Drug interiors and spawn previews also restore their routing/player state.
- Shared instances use disjoint configured ranges. Duplicate dispatch renderers and competing postal data were removed.

Required external checks remain: actual ESX/inventory/SQL schema, migrations against MariaDB, multiplayer transactions and reconnects, OneSync entity/driver behavior, marker/interior/camera placement, voice and fuel APIs, and the retained original phone/HUD/appearance/login resources. See [LIVE_CHECKS.md](LIVE_CHECKS.md). Browser DOM tests check data handling and routes; they do not validate GTA rendering or pixel similarity.

Some workflows use ESX memory alongside SQL. A process crash between those two state changes can need audit/reconciliation; do not describe those exchanges as crash-atomic. Gameplay balance, police staffing thresholds and economy prices are initial configuration values. Load testing, resource CPU measurement and realistic city playtesting have not run.

No tracked user server files, production database or external server has been modified. The original ZIPs remain uninspected due to the transfer limit, so no archive-based duplicate removal or original-fix restoration is claimed.
