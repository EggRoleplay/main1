# What this build does

| Resource | Implemented workflow | Limits |
| --- | --- | --- |
| `egg_city` | Housing/motels, rental renewal, instanced rooms, approved multijob switching, business leases/banks/employee commissions/adverts, 7-Eleven and Bunnings stock, marketplace/auctions and offline claims | Stock interiors; no furnishing, house stashes or shared keys. Existing ESX jobs are prerequisites. |
| `egg_work` | Fishing tiers/logbook, blueprints/crafting, collection/sorting/smelting, mushrooms, pawn counter and GPS/postal item | Original small waypoint directory, configured recipes/trade stock; no copied map textures/grid. |
| `egg_drugs` | Persistent cultivation, lot quality, leased stock cocaine lockup, cutting/bagging workstations, sealed lab stock, timed deliveries, transfers and police risk | Abstract game items; quality transfers need `/passstock`; no paid lab assets or party invitations. |
| `egg_crime` | Mail, store and actual interior house robberies; rope ATM jobs; contract salvage; D/C/B/A/S boosting; Fleeca/Bobcat/Pacific unlocks; wreck/airdrop events; gang turf and missions | Timed heist stages, stock scenes, contract-only chopping, local rope scene. Not custom vaults/guards, flying crash cinematics or player-vehicle destruction. |
| `egg_police` | MDT, certifications, plate/ANPR lookup, loadout-verified weapon registry, consented fingerprints, evidence/cases/DOJ decisions, suspensions, barriers, private lockers, server-speed fines/notices | Registry serials are not inventory metadata; evidence/bodycam status is not recorded video. Existing ownership/users schema inspected at startup. |
| `egg_dispatch` | 000 calls, separate police/ambulance/fire queues, claim/cancel/history, server locations, original service card | Existing rescue/job resources still perform treatment and firefighting. |
| `egg_garages` | Twenty garages, authoritative ownership and network vehicle reservations, storage and audited recovery, suspension checks | Stock cars/motorcycles. Model/plate/colours retained; existing fuel, damage, tuning and boot integration requires server-specific work. |
| `egg_staff` | Permissions, reports/replies/claims, staff shifts with two-hour clock-off and optional Discord logs | Outbound logs, not a Discord remote-control bot; existing rank/ACE administration is retained. |
| `egg_guard` | Bounded explosion-abuse throttling and resource health console | Conservative guard, not a full commercial anticheat or a recovered Egg Guard 2.0 product. |
| `egg_quality` | Cosmetic sling, opt-in FPS budget, AFK handling, voice playback refresh, `/roll`, `/staff` | Sling is local; voice helper does not promise a complete network reconnect. |
| `egg_hud` | Screenshot-guided lower bars, compass/streets, compact vehicle display, postal footer, shared progress and pause labels | No upper-right replacement. Configure native fuel integration and the old HUD's lower section before enabling. |
| `egg_menu` | Optional unified default-menu skin, nested menus and basic sliders | Existing advanced/custom menu behavior must be checked on staging. |
| `egg_spawn` | Optional eight-choice aerial spawn selection after real ESX login, current character profile and owned-home exterior | Existing character creation/deletion and normal Illenium remain outside this resource. |

Smart Phone Pro, standard Illenium Appearance, the old HUD, ESX base, inventory, custom vehicles, branded map textures and the unidentified earlier fix were not supplied in readable form. They have not been recreated or silently replaced. This archive adds original expansion code to a functioning server; it is not a complete standalone server pack.
