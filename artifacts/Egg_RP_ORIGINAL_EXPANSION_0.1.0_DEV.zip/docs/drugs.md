# Growing, workbenches and street stock

`egg_drugs` is an original GTA roleplay resource. Cannabis crops, stock preparation, rented workshops and delivery jobs share ESX's standard menu and the city's amber work markers. Workshops use GTA's stock biker cocaine interior with configured equipment/shelving props and distinct cutting, packing and side benches. Cutting/bagging are abstract game item exchanges; they contain no real chemical process, quantities or production instructions. No Fat Duck Gaming script, video asset or private system is included.

Start `egg_core`, `es_extended`, `oxmysql` and `esx_menu_default` first. Import the central `sql/10_items.sql` definitions and `sql/35_drugs.sql`. `egg_police` is optional: when it is running, its server-only `Dispatch` export can receive a suspected-handover alert. `egg_hud` supplies the slim dark progress bar with a green fill; there is an ESX help-text fallback when that resource is absent. Stock actions use OneSync server coordinates.

## A run through the loop

1. Buy seeds, grow supply crates and packaging at the back lane supply counter. This counter takes cash. There are four configured Grapeseed patches, with two live crops allowed per character.
2. At a patch, press **E** and plant. A seed and a grow supply crate are consumed only when the server validates completion. Crops take 15 real minutes to mature; the timer continues while you are offline and across resource/server restarts. Quality and yield are fixed when planted.
3. Return and harvest the crop. The server gives 5–8 harvested cannabis with a recorded quality of 1–95. Higher growing skill improves starting quality. An unready crop cannot be harvested early.
4. Use the trimming bench to turn harvested cannabis into trimmed stock, then bag it using packaging. The menu shows the game item requirements. Server-owned lot records carry quantity and quality through each stage.
5. Bring at least two bagged stock to a street contact. The contact chooses a product, amount and address, then sends a route. You have ten minutes and the buyer needs at least 45 seconds before accepting it. Walk up to the drop and press **E**. Payment depends on server-recorded quality, with a two-minute recovery period between jobs.
6. Street-work progression opens cocaine cutting/bagging and lab batches at level 3, then sealed crystal stock at level 5. The La Mesa or Sandy workshop costs $2,400 for a 24-hour rental, paid through the bank. Rent at its door, enter the workshop, and use the separate interior benches. Cutting uses GTA's stock cocaine cutting animation with a scenario fallback if that animation cannot load. Work is rejected when the rental expires; the exit remains available.

These are criminal street-stock loops. The contact is a delivery contact, not a legitimate dealership or business licence. A successful handover has a configured 15% chance of a police search-area report. Ordinary fishing, recycling and pawnshop work in `egg_work` remain separate legal jobs.

## Controls and stock handoffs

| Control | Use |
| --- | --- |
| E at a patch/counter/bench | Open its menu |
| X during production | Cancel with no inputs consumed or outputs granted |
| `/stockbook` | View growing/street-work XP and registered lot quantities/quality; restore the current delivery route |
| `/passstock 27 green 2` | Pass two bagged cannabis to nearby player ID 27, preserving its lot record |
| Contact menu | Request/view or cancel a delivery |
| Workshop door / interior exit | Enter a leased instance / return to its original exterior |
| Patch menu → Clear patch | Discard your planted crop and supplies |

Supported handoff stock names are `crop`, `trim`, `green`, `batch`, `crystal`, `coke_batch`, and `cocaine`. Handoffs require the same routing bucket and no more than three metres separation. Both characters' ledger locks are acquired in a consistent order. Inventory capacity, current character identity and item count are checked before moving stock. Workshops are single-character instances, so pass stock outside.

ESX's standard stack inventory has no per-item metadata. Quality therefore belongs to a server-recorded quantity owned by a character. **Use `/passstock` to transfer the tracked items.** A normal inventory give/drop/pickup may move a visible item without moving its lot record, so the recipient cannot process or sell it through this resource. Staff-spawned tracked stock is also rejected unless it has a valid server lot. Configure external inventories to route tracked-item transfers through an equivalent supported integration before enabling their generic handoff UI. The stock book displays registered lots; outside inventory removals can leave stale registrations and need administrative reconciliation.

## Persistence and checks

The SQL migration creates `egg_drugs_plants`, `egg_drugs_leases`, `egg_drugs_lots` and `egg_drugs_contracts`. Skills use `egg_core`'s existing table, under `cultivation` and `contraband`. Planting awards 10 growing XP, harvest 35, trimming 18, bagging 16; the two side-bench stages award 25/30 street-work XP, cocaine cutting/bagging 25/22, and completed deliveries 30. Core's level curve is shared with the rest of the city.

The server creates single-use timed production sessions and validates location, on-foot state, character identity, stock, lot ownership, skill, active rental and elapsed time at completion. Clients supply a work selection, not a yield, quality, price or destination. Crop maturity and delivery deadlines come from persisted server timestamps. Failed capacity checks restore consumed materials; failed database transactions undo the inventory exchange. Refunding a disconnected character or an unexpected inventory mutation cannot be made atomic with an external inventory, so exceptional rollback failures are audited for staff rather than credited to a reused player ID.

All prices, locations, grow/rental timers, amounts and dispatch chance are configurable. Leases grant a server-assigned single-character routing bucket and teleport to the configured vanilla interior. Interior production requires that character's room record, current bucket, valid rental and proximity to the correct bench. The exit restores the prior bucket and exterior; a stopped resource returns occupants outside. A character saved inside without a live room record is recovered to the La Mesa door on loading. Reserve `Config.LabBucketBase` plus player IDs from other instance resources. There are no party invitations, paid maps or custom MLO assets.

Patches are character-owned slots, not globally exclusive fields. No harvesting props, drug effects, NPC pedestrians, vehicle distribution animation or inventory-specific item art is bundled. No delivery payout is available without the recorded matching stock. GTA interior prop/animation availability and exact bench positions must be checked against the deployed game build; the code does not claim pixel-identical reproduction of a supplied screenshot.

Before launch, test planting/harvesting across relog and restart, early and repeated completion requests, full inventory rollback, lease-gated doors, routing separation, expiry while inside, correct exit return, resource-stop recovery, ledger-preserving handoffs, ordinary untracked transfers being refused, completed/expired/replayed deliveries, and police dispatch with two connected players. Check marker heights, interior props/bench positions and cutting animation against the installed game build; tune income against the full city economy. Live FiveM playtesting is still required.

Required item names: `egg_weed_seed`, `egg_grow_crate`, `egg_packaging`, `egg_lab_crate`, `egg_weed_crop`, `egg_weed_trim`, `egg_weed_pack`, `egg_lab_batch`, `egg_lab_pack`, `egg_coca_crate`, `egg_cocaine_batch`, `egg_cocaine_bag`.
