# Emergency dispatch

`egg_dispatch` adds an original 000 request flow and a small translucent service card. The card sits on the right at 28% of screen height, below the existing upper-right Egg RP panel. It does not replace, edit or read an existing HUD, ambulance UI, phone or police resource. Ambulance calls use an Ambulance Victoria heading; police and fire headings come from the configured service.

Import `sql/90_dispatch.sql` and start the resource after `oxmysql`, `es_extended` and `egg_core`. The default service job mappings are `police`/`sheriff`, `ambulance`, and `fire`/`firefighter`. They must already exist in ESX. This resource sends requests and coordinates responses; existing ambulance/fire resources still handle treatment, revive actions, firefighting and any duty system. It does not create jobs or fabricate rescue gameplay.

## Use it

- Any character can open `/000`, choose police, ambulance or fire, describe the emergency and send a request. The server records their current OneSync position, character name/identifier, routing bucket, nearest configured postcode and server timestamp. Client coordinates, identity and time fields are ignored. A character may have two active calls and citizen requests have a 60-second cooldown.
- Responders receive calls for their own configured job/service. The card shows postcode, call number, description, coordinates, received time and assigned unit. Default command mappings are **7 Accept**, **8 Cancel**, **9 History**. These are configurable FiveM command bindings; they do not disable existing game controls. Set `EnableDefaultBindings = false` if those keys conflict, and use `/dispatchaccept`, `/dispatchcancel`, `/dispatchhistory` or `/dispatch` instead. Players can also change the registered mappings in FiveM key settings.
- Accepting an open call assigns the responder’s character, records the acceptance time and sets a GPS waypoint. No distance check is applied to remote coordination. Server permissions restrict acceptance to the call’s service. The call is locked and conditionally updated so two responders cannot claim it concurrently.
- For an unclaimed card, **8 Cancel** dismisses that alert locally; it leaves the call available to other units. For an assigned card, it opens history, where the assigned unit can close the call with a response outcome. Only the original caller or the currently assigned unit in the correct service can close it. Another unit cannot close someone else’s call. Callers can cancel their own active requests from `/000` with a reason.
- History contains the latest 40 service calls. Civilians see only their own latest 20 requests. Character identifiers are not sent to the UI. Unclaimed calls expire after 30 minutes; assigned calls remain active until closed or cancelled. Service assignment changes clear the client alert card. An open card hides after 45 seconds, while the persistent queue remains available through history.

The supplied four postal anchors are original example data, not a full map or an official Australian postcode dataset. Update the single `egg_work.Config.Postals` directory or adapt its `NearestPostal` export to your existing provider. HUD, GPS and dispatch share it. Do not claim an exact postal result from these sample anchors. Calls in an interior routing bucket are marked with their instance number in history; this resource does not move responders into that instance or change a housing system’s routing.

## Integrate trusted server alerts

```lua
if GetResourceState('egg_dispatch') == 'started' then
    local sent, callId = exports.egg_dispatch:Dispatch(source,
        'Reports of suspected street dealing', 'police')
end
```

The export accepts an online player source, a description and `police`, `ambulance` or `fire` (police is the default). It still derives identity and position on the server and applies the active-call cap. Trusted alerts do not use the citizen cooldown. There is no client-triggerable raw dispatch event. The bundled police facade and crime alerts route into this same queue. Their older alert/blip renderers have been removed.

The `egg_core` bridge binds each callback to its originating character/session, including lock callbacks. Additional checks compare immutable character identifiers after database reads before acting. Persisted service, caller and accepted-unit identifiers enforce access independently of client fields. Text is length checked, queries are parameterised, action callbacks are rate limited and rendered text is escaped.

## Verify on a server

Lua 5.4 and browser JavaScript syntax are checked locally. Boundary tests exercise caller ownership, responder job scope and stale-session checks with mocks. An actual FXServer and two connected players are required to validate map waypoints, ESX job changes, notification delivery and the card’s placement alongside your HUD. Test simultaneous acceptance, cancellation by another unit, a police unit attempting to accept an ambulance call, a civilian requesting history and a caller supplying fake coordinates. Confirm only the correct service receives the alert and that your existing medical/fire resources respond normally.
