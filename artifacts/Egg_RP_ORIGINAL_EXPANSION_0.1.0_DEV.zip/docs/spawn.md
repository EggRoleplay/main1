# Egg spawn selector

`egg_spawn` adds an original location selector **after the installed character
login system has loaded an ESX character**. A live aerial camera shows each chosen
part of the city. The screen has a small red Egg identity mark, the actual
character name, date of birth and employer, a transparent welcome panel, eight
location rows, a blue selection and a green confirmation button. It uses stock
world coordinates rather than a copied map or another server's assets.

It does not create, delete or switch characters. The change-character button is
disabled because this pack has not been supplied a verified multicharacter
backend contract. Keep character selection in the existing login system.

## Enable after checking the current login flow

The default is `Config.Enabled = false`. Import `sql/80_spawn.sql`, ensure
`es_extended`, `oxmysql` and `egg_core` are running, and start `egg_spawn` after
them. To try the selector, set the resource's local `Config.Enabled` to `true` on
a staging server, restart the resource, and log out and back in. Resource restarts
do not open a selector for characters who are already playing.

Only the real ESX server `esx:playerLoaded` event issues an admission. The client
waits briefly for normal ESX/spawnmanager initialization before sending its ready
action. Check this timing with the installed multicharacter and appearance scripts:
those scripts may have their own final spawn screen. Enable a single location
selector and let character creation finish before this one runs. If the existing
login system already handles locations, leave Egg's selector disabled.

The UI lists:

| Location | Availability |
| --- | --- |
| Last Location | A valid outdoor location recorded for this ESX character. |
| Apartment | Current owned home or active motel tenancy, via `egg_city`'s protected server export. |
| Alta Train Station | Public arrival point in the city centre. |
| Sandy Shores | Public arrival point near the main street. |
| Boardwalk | Public beachfront arrival point. |
| Paleto Bay | Public arrival point near the town centre. |
| LSIA Airport | The terminal forecourt. |
| MRPD | The public police headquarters entrance, outside secure areas. |

Apartment brings the player to the **building's exterior door in bucket 0**.
It does not enter a room, bypass a housing lock or reuse the housing interior
bucket. Its tenancy is checked again when confirming. Missing `egg_city`, no
ownership or an expired tenancy leaves the Apartment row unavailable.

Last Location uses the separate `egg_spawn_last_location` table; it does not
modify ESX `users`, multicharacter data or original saved-position fields. The
server samples living characters in the public world every 30 seconds and saves
after at least three metres of movement. Death, private routing buckets and
preview sessions are excluded. Coordinates must be finite, inside configured
world bounds, and above `z = -10`; negative-Z housing interiors are excluded.
These checks prevent arbitrary or interior positions from becoming a spawn
option, but do not prove that a custom map position has ground collision. Test
the configured points with your actual map before launch.

## Admission and cleanup

The login permission expires after two minutes. Ready can open it once. Preview
uses the isolated bucket `600000 + source`, with population off and client entity
creation locked down. The native camera previews the selected place without
teleporting the character between locations. The player's ped is frozen and
hidden locally; `LocalPlayer.state.eggSpawnSelecting` is true while the menu is
open so the installed HUD can hide its widgets.

Confirmation submits a point ID and the session token. The server resolves the
coordinates, verifies the bound character after database waits, moves a living
ped, consumes the permission, and restores bucket 0. It does not revive a dead
player, issue a vehicle, change belongings or accept a client coordinate.

Escape, timeout and resource-stop cleanup return to the server-captured login
position and release the preview bucket. If that original point is outside the
safe world bounds, the configured public default is used. Dead characters are
never moved or revived during cleanup. The client restores visibility, movement,
camera focus, radar and NUI focus on close, logout, ped replacement or resource
stop. A character change during an awaited request invalidates its permission;
source-number reuse cannot authorize another character's teleport.

The bundled Barlow Condensed fonts come from
[Google Fonts](https://github.com/google/fonts/tree/main/ofl/barlowcondensed) and
include the SIL Open Font License in `web/fonts/OFL.txt`. The NUI loads all files
locally and performs no third-party browser requests.

## Checks

```bash
node --check 'resources/[egg]/egg_spawn/web/app.js'
node 'resources/[egg]/egg_spawn/tests/ui.test.js'
PYTHONPATH=/tmp/egg-validation python3 'resources/[egg]/egg_spawn/tests/server_checks.py'
```

An optional DOM integration check exercises the real NUI document and routes:

```bash
npm_config_cache=/tmp/egg-spawn-npm-cache npm install --prefix /tmp/egg-spawn-dom --no-audit --no-fund jsdom@26.0.0
NODE_PATH=/tmp/egg-spawn-dom/node_modules node 'resources/[egg]/egg_spawn/tests/dom.test.js'
```

The server checks use the repository's pinned Lua 5.4 test runtime (`lupa==2.8`).
They cover disabled-by-default behavior, actual-load admission, one-use tokens,
fresh ESX player copies, source and await guards, approved coordinates, origin
restore, saved-coordinate rejection, changing tenancy, death, timeout and stop
cleanup. UI checks cover malformed data, duplicate IDs, disabled choices,
keyboard wrapping and strict availability. The DOM check also covers identity
HTML escaping through text rendering, selection and confirmation routes,
pending-selection races, server-denial recovery, Escape and message cleanup.
They do not claim live GTA camera, streaming or login compatibility. A full
headless screenshot check was unavailable in this workspace: Playwright's browser
download was blocked by the environment's network domain policy.

On staging, confirm all eight rows, the six fixed landing spots, a saved outdoor
location, an expired tenancy, one successful arrival, Escape, a two-minute
timeout, resource restart, death during preview and a full character logout.
Check the existing phone, standard Illenium Appearance, HUD and character login
still behave correctly. Keep this optional selector disabled until those checks
pass with the actual installed resources.
