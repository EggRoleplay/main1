# Crime, contracts and gangs

`egg_crime` is an original ESX resource. It uses the city map, normal ESX menus and server-checked timed tasks. It does not contain scripts or assets from Fat Duck Gaming.

Start it after ESX, oxmysql and `egg_core`, with OneSync enabled. Import `sql/40_crime.sql` and install the shared Egg inventory items. `esx_menu_default` is needed for contact and gang menus; direct E interactions still use ESX help notifications. The default payout account is `black_money`; change `Config.RewardAccount` if your economy uses another existing ESX account.

## Playing

- Visit the contact at the city yard, or use `/boost` there, to buy a D/C/B/A/S vehicle contract. Work at the marked pickup, unlock the vehicle and drive the exact marked car to the salvage yard. Classes require boosting levels 1/2/3/5/8 and increasing police presence. The fee is a contract cost, not a refundable deposit.
- The public salvage yard contact offers a chop contract. Collect its marked abandoned vehicle and remain in the driver seat at the yard for a 75-second salvage inspection. Cash, scrap and copper are awarded. Only resource-created contract cars qualify; civilian, player-owned and other mission cars cannot be submitted.
- E at a configured mailbox, shop till, house entrance, ATM or heist point starts the job. Shops require an equipped weapon. House/ATM/heist jobs consume an Egg lockpick. House burglary enters a furnished stock GTA apartment in its own routing bucket. Search three server-selected cupboards/drawers, each with a 35-second search at the marked furniture. Searching can be interrupted by moving away. Finish all three to receive cash and stolen goods and return outside; exit at the green doorway marker or use `/exitburglary` to leave early. Other fixed-target jobs are abandoned if you leave the area. Death, cancellation and disconnect lose unfinished sessions; target cooldowns remain saved.
- For ATM towing, open the casing, park a road vehicle beside the target, then press E from the driver seat. A rope and ATM overlay are rendered locally. Pull 12–60 metres slowly and maintain tension for five server samples (25 seconds). The server checks the original tow vehicle, driver, distance, speed, elapsed time and police presence before payment. Drive beyond the rope limit to break the job.
- Fleeca requires crime level 2. Bobcat requires level 4 and a previous Fleeca completion. Pacific requires level 6 and Bobcat. Each has three timed security/loot stages; completion prerequisites survive reconnects.
- Plane crash and supply-drop events appear every 45 minutes while players are online and expire after 15 minutes. Only one player can open a crate; successful looting removes the event for everyone. Scenes use a wrecked vanilla aircraft and/or crate at configured rural sites.
- `/gang` shows saved membership, territory ownership and treasury balance. Members take a pickup/delivery mission from the gang contact or enter a turf zone and contest it. Claimants must remain in the zone; a registered rival gang inside pauses the capture timer. Claims pay into the gang treasury, while delivery missions pay both the gang and the courier.
- `/cancelcrime` cancels a job. Fees and consumed lockpicks are not returned. `/crime` opens the contact menu and displays crime/boosting levels.

## Staff and configuration

Gang membership is assigned through the staff-only `/gangstaff` menu or server-console `eggsetgang <online ID> <gang|none>`. A player cannot select their own membership. Configure gang names in `Config.Gangs.allowed`; initial names are ballas, families, vagos, lost and triads. Treasury balance is stored for economy integrations; there is no player-controlled withdrawal endpoint.

Police counts use configured ESX job names and count online officers, without a dependency on a particular duty script. Alerts mark the target for police for 90 seconds. Adjust police counts, clocks, reward bands, skill gates, coordinates and cooldowns in `config.lua`. Server awards choose amounts; client requests cannot supply payout amounts, items, models or gang identities. Cooldowns are persisted when a target is accepted and survive resource/server restarts. Active sessions do not survive a restart. Burglary saves the entry coordinates, heading and original routing bucket on the server and restores them on completion, exit, cancellation, death or resource stop. A dedicated return-route record remains on disconnect and is recovered on the next ESX player load, covering ESX save-event ordering. The burglary bucket range starts at 400000, separate from the housing resource; avoid using that range for another resource.

Shared items used here:

| Item | Label | Weight |
| --- | --- | --- |
| `egg_lockpick` | Lockpick | 1 |
| `egg_stolen_mail` | Stolen mail | 1 |
| `egg_stolen_goods` | Stolen goods | 2 |
| `egg_scrap` | Scrap metal | 1 |
| `egg_copper` | Copper | 1 |

Item rewards additionally require inventory capacity; cash and XP are still paid if the small loot bonus cannot fit. The work/market resources can process or sell stolen goods and materials.

## What this release simplifies

These are functional starter loops, with timers and standard menus. Burglary uses one furnished stock GTA apartment with isolated sessions and configurable furniture objectives. It does not include bespoke property interiors, NPC residents, guard AI or persistence for partly searched houses. Heists use map access points and timed security stages, with no custom vault collision, thermite minigame, guard waves or authored cutscenes. Plane events place wreck scenes rather than simulating an airborne crash. ATM rope tension is validated on the server and displayed on the robber's client; the existing world ATM is not physically destroyed. Turf captures are persistent territory contests, not instanced deathmatches. There is no weapon unlock or laundering system inside this resource. Boosting and chopping use supplied contract vehicles to prevent stealing another player's persistent vehicle through a payout exploit.

The staging machine can check Lua parsing and mocked rules. Actual interior streaming, furniture coordinates, vehicle creation, rope rendering, map placement, inventory integration, police alerts and multiplayer contest behaviour require a FiveM server and GTA client smoke test.

## Live validation

1. With sufficient police and a lockpick, enter a house and confirm the furnished apartment loads. Attempt a search from the street or a different routing bucket: both must be refused. Start a marked furniture search and move away; it must reset. Complete all three searches and verify a single payout and restoration of the exact saved position/bucket. Test the exit marker, `/exitburglary`, cancellation, death, reconnect and resource restart; each must return you outside, with the house still on cooldown.
2. Complete a D contract. Try delivering another car or swapping into the passenger seat: both must be refused. Deliver the tagged target as driver while stopped; money and boosting XP should be awarded once.
3. Complete a salvage contract and stay in the assigned car at the yard for the inspection. Confirm scrap/copper, cash and crime XP, then attempt to replay the completion request: there must be no second payout.
4. Start an ATM job, attach from the driver's seat and pull slowly 12 metres. Hold for at least 25 seconds and finish. Test breaking the 60-metre limit and leaving the vehicle.
5. Check low-level heist refusal, then complete Fleeca/Bobcat/Pacific in order after raising skills through normal play or trusted server-side tooling.
6. Assign two test players to different gangs. The capture timer must pause while the rival remains inside the zone, and leaving the zone must abandon the claim. Reconnect and verify membership, treasury and turf ownership.
7. Reduce the event interval temporarily in staging. Confirm late joiners see the active crate, one claimant wins, and every client removes the scene on completion or expiry.
