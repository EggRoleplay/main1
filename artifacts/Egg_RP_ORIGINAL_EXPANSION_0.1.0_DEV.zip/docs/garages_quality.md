# Garages and everyday commands

`egg_garages` supplies 20 public road-vehicle garages on the stock map. On foot,
press **E** at a marker to collect an owned vehicle. Drive into a marker and press
**E** to store it. Collection is denied while `egg_police` reports a suspended
driving licence; storage remains available.

Import `sql/60_garages.sql`, then start `egg_garages` after `es_extended`,
`oxmysql`, `egg_core` and `esx_menu_default`. FiveM OneSync must be enabled; the
server creates vehicles and checks player positions, drivers and passengers.
Start `egg_quality` after `egg_core`. Neither resource replaces your inventory,
HUD, phone, appearance system or the original ESX ownership table.

## Bring across existing vehicles

Turn off the old public garage before starting this one. The ownership source is
ESX's `owned_vehicles` table with `owner`, `plate` and vehicle-properties JSON in
`vehicle`. Optional `type` is respected: only road vehicles are listed. Original
`stored = 0` records enter the separate Egg table as `legacy_out`; they are not
silently duplicated. Registrations must fit GTA's eight-character plate limit.

The new `egg_garage_state` table reserves each collection before vehicle creation.
Storage requires the owner in the driver's seat, the database model and plate,
the original server-spawned network ID and the checkout session marker. The
server deletes the entity before marking the reservation stored. Passengers must
leave first. All collection bays share a spawn lock, and each plate has a lock.
The garage never updates `owned_vehicles`, its JSON or its schema.

After a lost vehicle or server restart, staff can use:

```text
/garagerecover playerID PLATE
```

The owner must be online. Recovery checks that the plate is owned by that player
and that no live vehicle with the same plate exists anywhere on the server. A
server crash during collection or storage leaves its reservation blocked until
this check runs. The console can also run the command. Recovery is audited.
Existing third-party garage vehicles need this audit before their first Egg
collection; they are not accepted as an Egg checkout merely because their plate
matches.

Collection keeps the database model, registration and bounded primary,
secondary, pearl and wheel colours. It does not replay arbitrary vehicle JSON,
custom handling, tuning, custom RGB paint, damage, fuel or inventory contents.
This first version does not supply an impound, vehicle sale/key-sharing system,
aircraft hangar or boat depot. A production server should integrate its existing
vehicle fuel/damage/boot inventory system before switching its public garage.
Use `Config.Motorcycles` to classify additional motorcycle models for FiveM's
server vehicle setter. Verify each collection bay in-game before launch,
especially if the city uses custom map replacements.

## Commands

| Command | Behaviour |
| --- | --- |
| `/sling` | Toggles a local cosmetic long-gun prop on your back after switching weapons. It requires the weapon to remain in the ped's native loadout. |
| `/fps` | Toggles reduced model budgets, lower visual draw detail and fewer decals. It does not change jobs, traffic rules or server simulation. |
| `/resetvoice` | Refreshes local pma-voice playback and channel volumes through its supported exports. |
| `/roll [sides]` | Rolls a server-generated die with 2–100 sides. Defaults to six. Players within 15 metres in the same instance see the result. |
| `/staff` | Opens the existing `egg_staff` menu. Its server permissions still decide access. |

Sling and FPS preferences are saved locally. The sling is a visual for its wearer;
this version does not synchronize it to other clients. Custom inventory scripts
that remove unselected native weapons need their own supported sling adapter.
Weapon props grant no ammunition or inventory items. Disabled FPS mode sleeps
instead of running a frame loop, and default sling polling is every 350 ms.

`/resetvoice` does **not** restart pma-voice or reconnect Mumble. pma-voice's
[`toggleMutePlayer(serverId)`](https://github.com/AvarianKnight/pma-voice/blob/master/client/init/main.lua)
is toggled twice for each streamed peer to reset playback overrides while
preserving that peer's mute state. Newer versions' `getRadioVolume`,
`getCallVolume`, `setRadioVolume` and `setCallVolume` exports reapply current
channel volumes. The command does not change radio channels or microphone-click
preferences. pma-voice's `setTalkingMode` event is a notification, not a setter;
it is deliberately not used as a fake reset. Microphone or Mumble connection
faults can still require reconnecting.

## Idle protection

The server samples actual ped movement every 30 seconds, warns after 25 minutes
and disconnects after 30. Moving at least two metres resets the timer. There is
no client heartbeat that can keep an unattended player connected. Long stationary
roleplay can trigger the warning; move your character when warned.

Staff, `egg_staff` duty sessions and the `egg.afk.bypass` ACE are exempt. Configured
service jobs are exempt when `job.onDuty` is not explicitly false. If the existing
duty script keeps the same ESX job name while off duty, integrate its authoritative
`job.onDuty` state or remove that job from `Config.Afk.exemptJobs`.

## Acceptance checks on a staging server

1. Register a standard ESX road vehicle. Collect and store it at two different
   garages; check ownership JSON remains unchanged and colour changes persist.
2. Try two collection requests for the same plate, request someone else's plate,
   store a cloned or mismatched model, and collect while a bay is occupied.
   Each request must leave a single reservation and no duplicate vehicle.
3. Suspend the owner's driver licence. Confirm collection is refused and storage
   still works. Reinstate it and collect again.
4. Restart `egg_garages` with a checked-out vehicle. Confirm its original session
   can still be stored. Restart the server, then recover the absent vehicle using
   the staff command. Recovery must fail while any matching plate remains live.
5. Test sling with the installed inventory and character skin. Toggle `/fps`
   twice, run `/roll 20` with a nearby and distant player, and test `/resetvoice`
   with an intentionally muted peer to ensure the mute remains unchanged.
6. On staging, temporarily shorten AFK thresholds. Confirm server movement resets
   the timer, warnings appear, a stationary ordinary player is disconnected, and
   staff/duty exemptions hold. Restore production thresholds afterwards.

Lua parsing and simulated server-action checks can validate source and reservation
branches in this workspace. They do not establish live FiveM streaming, map
coordinates, inventory compatibility or voice audio; the staging checks above
are still required.
