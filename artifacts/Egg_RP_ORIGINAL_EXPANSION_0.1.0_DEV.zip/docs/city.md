# Civic life and local trade

`egg_city` gives residents a place to arrange a room, hold several approved jobs, run a small business and trade with each other. It uses the installed ESX menus and GTA keyboard. The city map shows the civic centre, functional businesses and each housing building once. Interactions and code are original Egg RP work.

## Installation

Import `sql/20_city.sql` into the same database as ESX. Start `oxmysql`, `es_extended`, `esx_menu_default` and `egg_core` before `egg_city`. OneSync must be enabled for authoritative proximity checks and room routing buckets. Configure locations, room prices, job hiring grades, business products and permitted market items in `resources/[egg]/egg_city/config.lua`.

The default marker locations use the standard GTA map; no paid MLO or shell is needed. Interior buckets begin at `71001`. Reserve this range for this resource. Room ownership uses the full ESX character identifier, so ESX multicharacter prefixes remain distinct.

## Resident workflow

Use `/city` to mark the civic centre on GPS. At the civic-centre marker, press **E**:

- **Homes & short stays:** purchase one of two Alta Street apartments or rent a Pink Cage/Sandy Shores room for seven real days. Rent is prepaid; renewing adds seven days to the later of the current expiry and today. Each character can hold two rooms. Use the building entrance marker to enter your own room and the interior-door marker to leave. A tenancy that ends during a visit returns the resident to the entrance. Resource shutdown also restores their previous bucket and returns them outside.
- **Employment desk:** retain approved ESX jobs and choose the active one. Existing active employment is recorded on the first visit. Staff or configured senior employers can grant a real ESX job/grade to another character standing at the desk. Non-staff employers can only grant grades below their own. The employer desk also removes recorded roles. Job definitions and payroll still belong to ESX.
- **Local business hub:** buy a lease for Egg Pier Café, 7-Eleven in Sandy Shores, Strawberry Lunch Bar or Bunnings Warehouse, move money between your own bank and the business account, record employees with commissions up to 15 percent, and post a paid community notice. Shops sell their configured products at a physical counter. Bunnings sells supported fishing rods, bait and vehicle toolkits at the stock You Tool retail site on the highway. A buyer can choose a registered, nearby staff member who receives a commission in the payout ledger. A self-service sale credits the entire purchase to the business. Business names are directory/counter labels; branded map textures or custom interiors are not supplied.
- **Community marketplace:** place permitted stackable inventory items in escrow as a fixed-price bundle or a 1/6/24-hour auction. Fixed listings expire after seven days. Auctions require paid bids; increasing your own high bid debits only the difference. An outbid character receives a persistent refund. Auctions with bids cannot be cancelled. Expired auctions resolve every minute, and marketplace visits also process overdue auctions.
- **Collect payments / parcels:** collect sale proceeds, outbid refunds and staff commissions into your bank, and recover purchased, won, cancelled or expired listing items. Offline characters keep their money and parcels in the database. Large payment balances are collected in $1 million instalments. Parcels remain uncollected when inventory capacity is insufficient.
- **Around town:** read one current notice per business. Notices expire after 24 real hours and cost $250 from the business account.

All marketplace prices cover the **whole bundle**, not each item. The marketplace whitelist is a deliberate first release limit. Add only real inventory item names after checking your installed inventory's item definitions.

## Trust and persistence

Prices, products, grants and ownership come from server configuration or persisted records. Clients cannot mint money, submit arbitrary job permissions or sell an unapproved item. Economic mutations validate proximity, numeric bounds, current records and identity; shared market operations are serialized using `egg_core:WithLock`. Auction resolution writes the listing state, seller payment and winner parcel in one InnoDB transaction. Bid replacement writes the new bidder and previous bidder's refund in one transaction. SQL updates debit business balances conditionally to prevent overdrafts. Parcel claims use conditional status updates to prevent double collection.

These locks assume **one FXServer process using these tables**. ESX account/inventory changes occur in framework memory while escrow records live in SQL. Compensation handles ordinary command failures, but a hard process crash between a framework mutation and a SQL commit is not an atomic distributed transaction. Preserve database backups and audit logs; reconcile the affected transaction before relaunching after a mid-transaction crash. A production server requiring strict crash atomicity needs an inventory/banking adapter with its own durable transaction journal.

Use the civic employer desk for removals while characters are online. An external job-management script that removes a role while it is inactive must also delete that role from `egg_city_jobs`; otherwise the stored employment remains selectable. This resource does not replace ESX payroll or society permissions.

## Included scope and limits

This is a runnable first version of housing, multi-job records, business banking/commissions/adverts, marketplace and auctions. Homes currently provide private interiors and tenancy; decoration, shared keys, guests, furniture, wardrobes and property stashes are not included. Businesses use configured products rather than a stock-management or player crafting supply chain. Staff commissions are credited on actual counter sales; employees cannot submit an arbitrary sale amount. Marketplace escrow handles simple item names/counts and deliberately does not accept weapon metadata, inventory-specific serialised items or vehicles.

The appearance menu and phone remain separate integrations. Live GTA collision, routing behaviour, UI layout and your selected inventory must be checked on your licensed FiveM server; static Lua validation cannot establish those results.

## Live acceptance checks

With two test characters and a backed-up test database, check these flows before launch:

1. Book and renew a motel room, enter/exit it, confirm another character cannot enter, and confirm two rooms at one entrance use separate buckets. Restart `egg_city` while a resident is inside and confirm safe return outside.
2. Grant a job with a senior employer, switch to it, revoke it, and verify it no longer appears. Attempt an unapproved grade from an ordinary player and a job change from outside the desk.
3. Buy a business, deposit/withdraw funds, hire an employee, make a served purchase and verify that the business balance plus the employee payout equals the configured sale price. Reject a fake employee or remote staff member.
4. List a bundle, buy it with the second character, collect it once, and collect the seller's proceeds. Cancel an unbid auction and recover its items.
5. Place a bid, outbid it with the second character, increase a character's own high bid, and confirm refunds and bank debits. Let the auction expire and confirm one winner parcel and one seller payment, including after a resource restart.
6. Fill an inventory, try collecting a parcel, make room, then collect successfully. Repeat the same claim and verify it fails. Exercise simultaneous bidders and repeated requests while checking balances and server logs.

## Server exports

- `exports.egg_city:IsBusinessOwner(source, businessId)` returns whether the character owns a configured business (database lookup).
- `exports.egg_city:GetBusinesses()` returns the configured business catalog for server-side integration.
- `exports.egg_city:GetOwnedSpawnPoint(source)` returns an active tenant/home owner's configured **exterior** entrance as `{ label, roomId, coords = { x, y, z, h } }`, or `nil`. It accepts a live numeric source only, derives the identifier on the server, checks expiry and rechecks the live identifier after the database lookup. A spawn selector must still check its own action session before teleporting and leave the player in bucket zero.

All client interactions use the registered `city.*` actions through `egg_core`; this resource registers no inbound server network events for money or job changes.
