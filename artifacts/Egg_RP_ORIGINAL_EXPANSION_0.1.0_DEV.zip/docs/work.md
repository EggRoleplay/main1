# Local work and progression

`egg_work` supplies original fishing, recycling, workshop, foraging and trade loops. It uses stock GTA locations and ESX's standard menu. There are no copied Fat Duck Gaming scripts, map assets or postal files.

Start `egg_core`, `es_extended`, `oxmysql` and `esx_menu_default` before `egg_work`. Import `sql/10_items.sql` and `sql/30_work.sql` after the ESX/core migrations, then restart ESX so it loads the item definitions. Item SQL targets the ESX Legacy `items(name,label,weight)` schema. Slot inventories need equivalent supported item definitions and a compatible ESX inventory bridge. Do not run the item insert against a legacy `limit` schema without adapting it.

## A first shift

1. Head to the tackle counter on Del Perro pier. Buy a rod, bait and a street directory. All counter transactions use your bank account.
2. Walk to a marked fishing spot, press **E**, and cast a line. Stay on foot at the spot until the bar completes. **X** cancels. Every successful cast consumes one bait and adds fishing XP.
3. Sell your catch at Catch of the Day. Bream and flathead are available from level 1; snapper unlocks at level 3 at tier 2/3 spots; tuna unlocks at level 6 at tier 3 spots. Each catch records species, weight and the personal best in a persistent logbook.
4. Collect a recycling bag at Cypress, sort it at the nearby bench, and smelt three scrap into a steel bar at La Mesa. Sorting yields scrap/plastic with a chance of copper. Collection has a 30-second recovery period per character.
5. Buy a plan from the tackle counter and **use the blueprint item** to learn it permanently. The Davis workshop offers fishing rods at workshop level 1, lockpicks at level 3, and vehicle toolkits at level 5. Recipes show their exact material requirements before starting.
6. Pick mushrooms on the Grapeseed track and sell them at the produce stall. Each patch recovers after three minutes per character. The pawn counter buys configured recycled materials and crafted toolkits.

Skills persist through `egg_core`: `fishing`, `crafting`, `recycling`, `foraging`. Its shared level curve is `floor(sqrt(XP / 100)) + 1`, capped at 100. Fishing awards 18 XP; gathering recycling 5; sorting 14; smelting steel 16; foraging 12. Workshop recipes award 20/28/40 XP. All prices, requirements, durations and locations are in `resources/[egg]/egg_work/config.lua`.

## Controls

| Control | Use |
| --- | --- |
| E near a work marker | Open the local counter or job menu |
| X during a job | Cancel; no materials are consumed and no reward is granted |
| `/workskills` | View the four work skills |
| `/fishlog` | View catch totals and best weights |
| Use `egg_gps` | Open the street directory |
| `/postal` | Open the directory, with the item required |
| `/postal 101` | Route to an original named directory waypoint |
| Use a blueprint | Learn the matching workshop recipe |

The directory is a small original set of named waypoints, not a full numbered street grid. A GPS item is reusable. Blueprint items are consumed once; reading a plan you already know leaves the item intact.

## Items

`egg_fishing_rod`, `egg_bait`, `egg_bream`, `egg_flathead`, `egg_snapper`, `egg_tuna`, `egg_recyclables`, `egg_scrap`, `egg_plastic`, `egg_copper`, `egg_steel`, `egg_timber`, `egg_mushroom`, `egg_gps`, `egg_lockpick`, `egg_toolkit`, `egg_blueprint_rod`, `egg_blueprint_lockpick`, `egg_blueprint_toolkit`.

Lockpicks and toolkits are crafting outputs used by the crime integration; this resource does not register competing usable-item callbacks for them. A pawnshop can buy more items only after they are explicitly added to `Config.SellStock.pawn` with fixed server prices.

## Validation and limits

The server chooses every yield and price. It checks inventory, location, player state, skill and blueprint requirements; it creates a single-use timed session, enforces elapsed time at completion, and verifies the player is still on foot at the configured spot. Cancelling, disconnecting or leaving does not grant rewards. Inventory exchanges roll back when items do not fit. Work/session locks serialize purchases, sales and exchanges for the same character. Failed refunds are logged for staff to reconcile.

Persistent catch counts, largest weights and learned recipes require the SQL migration. Catch grants remain single-use if a logbook write fails, and the player is told to notify staff. Patch/collection recovery timers and unfinished sessions reset when the resource restarts; inventory and progression remain persistent.

Live FiveM checks are required before opening the city: confirm marker height against your installed map, complete and cancel each loop, test full inventories and missing materials, verify blueprint/logbook persistence through relog/restart, check GPS routes, and reject early/replayed completion requests. Prices are starter defaults and need a whole-city economy review. No boat simulation, cooking, gathering props, minigame, MLO, custom inventory or phone is bundled by this resource.
