# Staging acceptance checks

No FXServer, ESX runtime, GTA client or live MariaDB database was available in the build workspace. Python/Lua mock tests and syntax checks do not establish multiplayer readiness. These checks must pass on your staging server before deploying.

Use two ordinary characters, one authorised police character and one staff member. Record balances/items before each economic test. Do not use a live economy to test failure paths.

| Area | Check | Expected |
| --- | --- | --- |
| Startup | Import all SQL; start the dependencies then `exec egg.cfg` | No missing item/table/native/export errors; `egghealth` reports started resources |
| Permissions | Open `/staff` as ordinary player, then staff; try police actions as civilian | Civilian actions denied; staff abilities follow their separate permissions |
| Phone/appearance | Open your normal Smart Phone Pro key, then `/eggphone`; visit clothing shop and `/eggappearance` | Existing phone data/UI stays; normal Illenium menu and persisted appearance |
| HUD | Keep original top-right panel; enable only new lower section | No duplicated bars, top-right unchanged, pause hides new HUD, voice/needs/fuel sensible |
| Housing | Buy two rooms with different characters, enter/exit and reconnect | Correct ownership, isolated interior buckets, exits restored; rent expiration enforced |
| Jobs | Employer hires lower grade; player switches stored job; employer revokes it | No self-granted police job or promotion; revocation survives reconnect |
| Business | Buy lease, hire worker, sell product, bank funds and post advert | Money conserved, configured commission recorded, unrelated player denied |
| Market | List and purchase item, outbid, expire auction, claim refund/parcel | Item escrow and one winner, offline refunds/claims survive restart; duplicate claim denied |
| Work | Fish with bait/rod; complete/cancel; learn blueprint; sort/smelt/forage/pawn | Real items exchanged, tier/XP gates respected, early/repeated completion denied |
| Drugs | Plant, wait, harvest; lease lab; process batch; hand off and deliver contract | Server timers, lot ownership/quality, ingredients and one payout; check restart timers |
| Crime | Civilian vehicle vs marked boost/chop vehicle; each boost class and heist tier | Ownership gates prevent chopping player vehicles; timers, police count, progression gates work |
| ATM | Start rope job, connect valid tow vehicle, pull out of radius | Visual rope and server distance requirements; disconnected/deleted vehicle cannot pay |
| Events/gangs | Spawn timed wreck/airdrop, claim once; staff assigns gang, capture turf | Shared event one payout, membership checks, cooldown and contested capture work |
| Police | Issue certification, ANPR real plate, fingerprint with/without consent, register actual weapon | Scope/certification/range/consent checks; false plate or weapon denied |
| Evidence/DOJ | Create evidence and case; suspend licence, try garage, reinstate | Persisted audit/case records and garage licence enforcement; records aren't actual video files |
| Fines | Drive past configured camera below/above limit, change driver, pay notice twice | Server sampled speed/driver; one payment; correct driver receives notice |
| Garages | Store/retrieve owned car; second character tries same plate; restart with car out | No duplicated spawn, unrelated owner denied, reservations reconciled conservatively |
| Quality | Sling on weapon switch, FPS toggle, voice reset, AFK warning/kick, `/roll` | No duplicate weapon grant; supported voice reset; exempt staff not kicked; server roll |
| Reports | Submit, claim, reply, close; two staff try same report | One handler, reporter receives replies, two-hour clock logs off |
| Restart | Disconnect mid-work, restart each expansion resource with active sessions | No free repeated payout or leaked routing bucket/entity; inspect recoverable leftovers |

Also verify standard ESX menus and keyboard entry at your target resolution, screen safe-zone, inventory weight boundary, vehicle persistence schema and resource start order. Do a two-player test for each shared economy action and test resource restarts before considering a production rollout.
