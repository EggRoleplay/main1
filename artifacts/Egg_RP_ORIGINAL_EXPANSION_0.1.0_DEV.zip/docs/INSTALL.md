# Install on your Egg RP server

This is an original **development expansion**, not the contents of either supplied ZIP and not a copy of Fat Duck Gaming. The large ZIPs and video uploads could not be transferred. No exact archive restoration, video match or unidentified previous fix is claimed.

## Prerequisites

- A working FiveM FXServer with OneSync enabled, GTA V build compatible with your maps, and an existing ESX Legacy base.
- `es_extended` exposing `getSharedObject`, `GetItems`, server callbacks, weight/carry-aware inventory and normal cash, bank and black-money accounts. This pack uses the standard ESX inventory API. A replacement inventory must supply that compatible API before use.
- `oxmysql`, the ESX base schema (`users`, `items`, `jobs`, `job_grades`, `owned_vehicles`), `esx_menu_default` and `esx_menu_dialog`.
- Normal configured police and legal jobs. Job switching does not create jobs or let players self-hire.
- `esx_status` for food/water HUD readings and `pma-voice` for voice recovery. The resource-specific notes identify optional dependencies and fallbacks.
- Your own **Smart Phone Pro** files and their licensed dependencies, if that is your original phone. The default guessed resource name is `qs-smartphone-pro`; confirm against your installation. This pack does not supply that paid product, export its source, migrate its SQL, or replace your phone.
- Standard **Illenium Appearance** and its dependencies. `/eggappearance` opens its normal clothing menu at a configured clothing shop; no custom appearance UI is included. Use a version supported by your ESX base and keep its persistence/configuration intact.

## First installation

1. Back up the live server and database. Use a staging server first.
2. Copy `resources/[egg]` into the server's existing resources folder. Do not replace the existing resources tree.
3. Import `sql/00_core.sql`, then `sql/10_items.sql`, then the remaining numbered SQL files into **the existing ESX database**. Read `10_items.sql` before import: it targets an ESX `items` table with `name`, `label`, `weight`, `rare`, `can_remove`. Servers with a limit-based/different item schema must map the listed item definitions to their existing loader. No ESX base tables are dropped or rebuilt.
4. If ESX was already running during the import, restart the staging server so the item registry refreshes. Confirm `bread`, `water` and all `egg_` items are registered. Do not hot-restart ESX on a populated live server.
5. Copy `egg.cfg` next to `server.cfg`; put `exec egg.cfg` after the database, ESX, inventory and menus. Keep your existing phone, HUD and Illenium startup lines.
6. Review every resource's `config.lua`: locations, economy prices, police requirements, cooldowns, job grades, garage models and interaction keys are initial tuning values, not a tested production economy.
7. Set `egg_core/Config.PhoneResource`, `PhoneCommand` or documented `PhoneOpenEvent` for your Smart Phone Pro edition. `/eggphone` is an alias; it does not override your existing phone command or key.
8. Configure staff permissions using existing ESX groups or the ACE examples in `egg.cfg`. Only administrators/owners are staff by default in core; helpers/moderators using ACE must receive `egg.staff` plus the separate desk/report permissions. `egg.staff` alone does not grant kick or teleport permissions.
9. Start the resources in the order in `egg.cfg`. Run `egghealth` from the server console, then follow [the live checks](LIVE_CHECKS.md).

Optional polish is deliberate: `egg_menu` and `egg_spawn` start with `Config.Enabled = false`. Enable each after verifying the existing menu/login flow on staging. The HUD startup line remains commented until the old lower HUD is hidden. Only one lower HUD and one default-menu renderer should be active.

## HUD integration

`egg_hud` draws only lower status/location information and vehicle instruments. **Its HTML contains no top-right panel.** It does not edit your current HUD. Leave it disabled until the current HUD is configured to keep its top-right section and hide the status/instruments it will replace; the original files are needed to make that precise change. Enable the optional line in `egg.cfg` once configured. `/egghud` toggles the new lower section for each player.

ESX needs readings refresh every two seconds. Without `esx_status`, food and water stay at their initial display values; this is not a substitute status implementation. Vehicle fuel uses the GTA native; configure your existing fuel script to keep that native synchronised. The seatbelt locks exiting while buckled. Disable its belt option if your server already supplies belt/ejection behaviour.

The HUD follows the supplied screenshots: coloured lower bars, centre compass/street, compact bottom-centre speed, lower-right postal text, and a green task bar. Video playback and live GTA rendering were not available. Exact top-right preservation also requires your current HUD files.

## Updating and recovery

Each cloud task is isolated; use the existing checkout and do not create a Git worktree unless explicitly requested. Shut down only services you started when checking local builds. An expansion resource hot-restart can interrupt active sessions: schedule restarts outside gameplay and inspect the audit records afterward.

Importing `CREATE TABLE IF NOT EXISTS` is repeatable. It does not migrate a changed existing schema; review diffs before later version updates. There is no tested upgrade/migration from the unavailable V2.3 files. New tables are namespaced `egg_`, but earlier packs may already use the same namespace; compare them in staging before importing.

ESX money and inventory reside partly in memory. Database transactions protect shared business/market rows; a process kill between SQL and an ESX mutation can still require reconciliation. This development pack does not promise crash-atomic money/inventory exchanges. Keep backups and audit abnormal transactions.

No proxy secrets, production database credentials or external paid resources are included. Discord logging is optional; configure a server-only `egg_discord_webhook` convar from a private config. It accepts only the official Discord webhook host. Logs travel outbound only; this is not a remote Discord moderation bot.
