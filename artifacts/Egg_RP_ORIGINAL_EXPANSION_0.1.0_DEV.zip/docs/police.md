# Egg police and court records

`egg_police` is an original ESX resource with a compact records terminal, station lockers and traffic notices. It uses Australian terminology and fictional Egg branding. The camera limits, fines and recorded points are gameplay settings, not a reproduction of current Victorian legislation.

Import `sql/50_police.sql` after the core schema. Start `es_extended`, `oxmysql` and `egg_core` before this resource, with OneSync enabled. Configure the existing ESX `police` job; the resource does not create or replace ESX jobs. Optional job names `sheriff`, `judge`, `doj` and `lawyer` are mapped in `config.lua`. A lawyer can add court notes; licence orders and case closure require a `judge`/`doj` job or an eligible police supervisor.

## Run a shift

1. Assign an ESX police supervisor at grade 3 or above. Open `/mdt` (F10), choose **Certifications**, select the officer and grant training after assessment. Supervisors may grant their own certificates to bootstrap a new server; staff access alone does not grant an unrelated job access to police records.
2. Use **People** to select an online character or search names when ESX identity columns are installed. Searches are capped at 20 matches. The record includes fingerprints, registered weapons, suspensions, recent cases and notices.
3. Use `/anpr` while seated in a vehicle or standing near one to fill the registration field, or type a plate in **Vehicle intelligence**. Vehicle intelligence certification is required. A lookup checks `owned_vehicles`; it does not identify the current driver.
4. Open a case, select a subject if known, write an initial summary and add investigation notes. Police can add evidence entries with a title, chain of custody description and optional HTTPS media reference. The server records the officer, timestamp and their position. References are stored as text; this resource does not upload files, fetch media or record video.
5. Fingerprint collection requires forensics training and both players must be in the same routing bucket. Select the online person and choose **Request fingerprints** while within three metres. A 30-second consent prompt appears for that person. Collection occurs only after they accept and both players remain nearby and authorised. Closing or declining collects nothing. The fingerprint is a stable hash of the character identifier.
6. Firearms-trained officers may register a nearby person’s weapon name, such as `WEAPON_PISTOL`. The server verifies that weapon exists in that person’s ESX loadout. This is a persisted registry keyed by character and weapon type. It does not add serial metadata to individual inventory weapons and cannot track two identical weapons, weapon transfers or recovered inventory metadata automatically. Integrate an inventory-specific serial adapter separately if your inventory supports that.
7. Move a case to **Before court** and let the configured court jobs add court notes. Police supervisors and `judge`/`doj` can change case status. Traffic-certified police or `judge`/`doj` may record a 1–90-day driver or weapon licence suspension; a police supervisor or `judge`/`doj` can reinstate it with a reason. Expired suspensions automatically stop blocking garages. Existing `esx_license` tables are left unchanged.

## Equipment and traffic

- `/policelocker` opens your personal locker view. You must stand within four metres of a configured station location to view or transfer contents. Lockers default to routing bucket 0; change `LockerRoutingBucket` for instanced stations. Each character has its own persisted locker. The default capacity is 100 ESX items; the explicit item allowlist is in `config.lua`. Weapon loadouts are excluded. Successful transfers are serialised per locker and failed storage/add operations are compensated. A process crash between an ESX inventory mutation and its database write still requires administrator reconciliation; the two systems cannot share one atomic transaction.
- `/barrier` places a networked, frozen traffic barrier just in front of the officer. `/barrier remove` removes the nearest police barrier within four metres. The limit is four live barriers per officer. Barriers are removed when the placing officer disconnects or the resource stops. No inventory item is required.
- `/bodycam` toggles a small officer/time indicator at the top centre. Camera notices appear at the bottom centre. Existing HUD data and the top-right HUD/branding are not modified. The bodycam is a roleplay status indicator; no video is captured.
- Three configurable cameras sample OneSync vehicle speed and movement on the server in routing bucket 0 (`CameraRoutingBucket`). The player must be driving. A previous sample from the same vehicle is required; inconsistent teleports or implausible speeds are ignored. The lower native/movement speed is compared against the configured limit and brackets. Client speed, fine amounts and camera claims are never accepted. Camera placement and radius should be drive-tested on your map before launch.
- A camera creates a persisted infringement and sends the driver a short notice. `/infringements` opens all recent personal notices. The driver can pay an unpaid notice from their bank account. Payments verify ownership and amount on the server, lock each notice and compensate failed database updates. Recorded points are shown for roleplay; there is no automatic points-based licence suspension.

## Server integration

```lua
-- Both source IDs and ESX character identifiers are accepted.
local suspended = exports.egg_police:IsLicenseSuspended(source, 'driver')
local same = exports.egg_police:HasSuspendedLicense(source, 'drive')
local notices = exports.egg_police:GetActiveInfringements(source)
-- Trusted server resources only. The position comes from the player entity.
exports.egg_police:Dispatch(source, 'Reports of suspected street dealing')
```

`driver`, `drive` and `driving` refer to the same licence type. `weapon` is also supported. Egg garages check the driver suspension export on withdrawal; suspended players can still store a vehicle. Integrations must call the exports from a server script and guard `GetResourceState('egg_police')` if police is optional.

When `egg_dispatch` is started, the police dispatch export forwards to its canonical persistent police call workflow. Otherwise its compatibility fallback notifies online police and marks a 150-metre search area for 90 seconds. Both paths never run for the same alert. The alert does not identify the reported person. There is no client-triggerable dispatch event. Client exports `OpenMDT()` for an existing police menu integration.

Name search adapts to existing `users.identifier`, `firstname` and `lastname` columns. ANPR adapts to `owned_vehicles.owner` and `plate`. When an optional schema is absent the terminal explains the unavailable lookup; consent, cases, lockers and notices use the Egg schema. Permissions, proximity, transfer quantities, weapon ownership, fines and notice ownership are checked on the server. Database queries and results are capped and parameterised. Audit events use `egg_audit` through `egg_core`.

## Validation before opening the server

The repository checks parse the Lua and JavaScript and exercise mocked permission, consent and inventory boundaries. Live Cfx natives, entity replication, camera measurements, ESX custom inventories and visual layout need an actual FXServer and two connected clients. Verify a civilian cannot open the MDT, a declined/distant fingerprint request collects nothing, one officer cannot withdraw from another officer’s locker, a paid notice cannot be paid twice and a suspension blocks garage withdrawal. Test camera positioning and barrier ground alignment on the installed map.
