-- ESX's existing owned_vehicles table remains the source of ownership.
-- Expected columns: owner, plate and vehicle (the ESX vehicle-properties JSON).
-- No ALTER or UPDATE of owned_vehicles is performed by this resource.
CREATE TABLE IF NOT EXISTS egg_garage_state (
    owner VARCHAR(191) NOT NULL,
    plate VARCHAR(16) NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'stored',
    garage_id VARCHAR(40) NULL,
    net_id INT UNSIGNED NULL,
    session_token VARCHAR(64) NULL,
    appearance LONGTEXT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (owner, plate),
    KEY egg_garage_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Migration guidance only: turn off any other public owned-vehicle garage before
-- enabling egg_garages. Two garage scripts cannot coordinate their reservations.
-- Existing ESX rows with stored = 0 are imported as 'legacy_out', and cannot be
-- withdrawn until staff verify the plate is absent using /garagerecover ID PLATE.
-- If stored is absent, new rows are treated as stored. Complete an ownership and
-- live-vehicle audit before enabling this resource on a pre-existing server.
