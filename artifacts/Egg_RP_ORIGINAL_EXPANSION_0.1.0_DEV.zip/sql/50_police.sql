CREATE TABLE IF NOT EXISTS egg_police_certifications (
  identifier VARCHAR(80) NOT NULL,
  certification VARCHAR(32) NOT NULL,
  granted_by VARCHAR(80) NOT NULL,
  granted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (identifier, certification)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS egg_police_cases (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title VARCHAR(120) NOT NULL,
  summary TEXT NOT NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'open',
  subject_identifier VARCHAR(80) NULL,
  officer_identifier VARCHAR(80) NOT NULL,
  officer_name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id), KEY cases_status (status), KEY cases_subject (subject_identifier)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS egg_police_case_notes (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  case_id BIGINT UNSIGNED NOT NULL,
  author_identifier VARCHAR(80) NOT NULL,
  author_name VARCHAR(100) NOT NULL,
  note_type VARCHAR(16) NOT NULL DEFAULT 'investigation',
  note TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id), KEY case_notes_case (case_id),
  CONSTRAINT egg_case_notes_fk FOREIGN KEY (case_id) REFERENCES egg_police_cases(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS egg_police_evidence (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  case_id BIGINT UNSIGNED NOT NULL,
  author_identifier VARCHAR(80) NOT NULL,
  author_name VARCHAR(100) NOT NULL,
  title VARCHAR(120) NOT NULL,
  description TEXT NOT NULL,
  media_reference VARCHAR(240) NULL,
  x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id), KEY evidence_case (case_id),
  CONSTRAINT egg_evidence_case_fk FOREIGN KEY (case_id) REFERENCES egg_police_cases(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS egg_police_fingerprints (
  identifier VARCHAR(80) NOT NULL,
  fingerprint VARCHAR(24) NOT NULL,
  collected_by VARCHAR(80) NOT NULL,
  collected_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (identifier), UNIQUE KEY fingerprint_unique (fingerprint)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS egg_police_weapon_registry (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  owner_identifier VARCHAR(80) NOT NULL,
  weapon_name VARCHAR(64) NOT NULL,
  serial VARCHAR(32) NOT NULL,
  registered_by VARCHAR(80) NOT NULL,
  registered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id), UNIQUE KEY weapon_owner_type (owner_identifier, weapon_name),
  UNIQUE KEY weapon_serial (serial)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS egg_police_lockers (
  identifier VARCHAR(80) NOT NULL,
  item VARCHAR(64) NOT NULL,
  quantity INT UNSIGNED NOT NULL DEFAULT 0,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (identifier, item)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS egg_license_suspensions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  identifier VARCHAR(80) NOT NULL,
  licence_type VARCHAR(16) NOT NULL,
  reason VARCHAR(500) NOT NULL,
  imposed_by VARCHAR(80) NOT NULL,
  imposed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME NOT NULL,
  reinstated_at DATETIME NULL,
  reinstated_by VARCHAR(80) NULL,
  PRIMARY KEY (id), KEY licence_active (identifier, licence_type, reinstated_at, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS egg_police_infringements (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  identifier VARCHAR(80) NOT NULL,
  driver_name VARCHAR(100) NOT NULL,
  plate VARCHAR(16) NOT NULL,
  camera_id VARCHAR(32) NOT NULL,
  location VARCHAR(100) NOT NULL,
  speed INT UNSIGNED NOT NULL,
  speed_limit INT UNSIGNED NOT NULL,
  fine INT UNSIGNED NOT NULL,
  points TINYINT UNSIGNED NOT NULL,
  issued_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_at DATETIME NULL,
  PRIMARY KEY (id), KEY infringement_owner (identifier, paid_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
