CREATE TABLE IF NOT EXISTS `egg_drugs_plants` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(100) NOT NULL,
    `spot` VARCHAR(40) NOT NULL,
    `ready_at` BIGINT UNSIGNED NOT NULL,
    `quality` SMALLINT UNSIGNED NOT NULL,
    `yield_count` SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (`id`), UNIQUE KEY `character_spot` (`identifier`, `spot`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `egg_drugs_leases` (
    `identifier` VARCHAR(100) NOT NULL,
    `lab` VARCHAR(40) NOT NULL,
    `expires_at` BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (`identifier`, `lab`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `egg_drugs_lots` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(100) NOT NULL,
    `item` VARCHAR(60) NOT NULL,
    `quantity` INT UNSIGNED NOT NULL,
    `quality` SMALLINT UNSIGNED NOT NULL,
    `origin` VARCHAR(80) NOT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`), KEY `character_stock` (`identifier`, `item`, `quantity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `egg_drugs_contracts` (
    `identifier` VARCHAR(100) NOT NULL,
    `status` VARCHAR(16) NOT NULL,
    `item` VARCHAR(60) NOT NULL,
    `quantity` SMALLINT UNSIGNED NOT NULL,
    `drop_id` VARCHAR(40) NOT NULL,
    `quality_quote` SMALLINT UNSIGNED NOT NULL,
    `base_price` INT UNSIGNED NOT NULL,
    `min_complete_at` BIGINT UNSIGNED NOT NULL,
    `expires_at` BIGINT UNSIGNED NOT NULL,
    `next_available` BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Item definitions are centralized in 10_items.sql.
