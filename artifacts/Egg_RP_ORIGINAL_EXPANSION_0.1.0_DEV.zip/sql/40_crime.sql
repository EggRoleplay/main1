CREATE TABLE IF NOT EXISTS egg_crime_cooldowns (
  cooldown_key VARCHAR(128) NOT NULL PRIMARY KEY,
  expires BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS egg_heist_progress (
  identifier VARCHAR(80) NOT NULL,
  heist VARCHAR(32) NOT NULL,
  PRIMARY KEY (identifier, heist)
);
CREATE TABLE IF NOT EXISTS egg_gang_members (
  identifier VARCHAR(80) NOT NULL PRIMARY KEY,
  gang VARCHAR(32) NOT NULL
);
CREATE TABLE IF NOT EXISTS egg_gang_turf (
  turf_id VARCHAR(40) NOT NULL PRIMARY KEY,
  gang VARCHAR(32) NOT NULL,
  claimed_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS egg_gang_treasury (
  gang VARCHAR(32) NOT NULL PRIMARY KEY,
  balance BIGINT UNSIGNED NOT NULL DEFAULT 0
);
-- Persists the exterior return route in case ESX saves an interior position on disconnect.
CREATE TABLE IF NOT EXISTS egg_crime_house_returns (
  identifier VARCHAR(80) NOT NULL PRIMARY KEY,
  return_coords LONGTEXT NOT NULL,
  previous_bucket INT NOT NULL DEFAULT 0
);
