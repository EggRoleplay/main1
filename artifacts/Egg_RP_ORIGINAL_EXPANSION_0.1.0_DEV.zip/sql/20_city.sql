CREATE TABLE IF NOT EXISTS egg_city_rooms (
    room_id VARCHAR(48) PRIMARY KEY,
    owner VARCHAR(80) NOT NULL,
    expires_at BIGINT NOT NULL DEFAULT 0,
    INDEX room_owner (owner)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS egg_city_jobs (
    identifier VARCHAR(80) NOT NULL,
    job_name VARCHAR(48) NOT NULL,
    grade INT NOT NULL,
    PRIMARY KEY (identifier, job_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Retained across disconnect until the character is moved back outside.
CREATE TABLE IF NOT EXISTS egg_city_room_returns (
    identifier VARCHAR(80) PRIMARY KEY,
    room_id VARCHAR(48) NOT NULL,
    previous_bucket INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS egg_city_businesses (
    business_id VARCHAR(48) PRIMARY KEY,
    owner VARCHAR(80) NOT NULL,
    balance BIGINT NOT NULL DEFAULT 0,
    INDEX business_owner (owner)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS egg_city_employees (
    business_id VARCHAR(48) NOT NULL,
    identifier VARCHAR(80) NOT NULL,
    commission INT NOT NULL DEFAULT 8,
    PRIMARY KEY (business_id, identifier)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS egg_city_adverts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    business_id VARCHAR(48) NOT NULL,
    text VARCHAR(180) NOT NULL,
    expires_at BIGINT NOT NULL,
    INDEX advert_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS egg_city_listings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    seller VARCHAR(80) NOT NULL,
    item VARCHAR(48) NOT NULL,
    quantity INT NOT NULL,
    kind VARCHAR(12) NOT NULL,
    price BIGINT NOT NULL,
    bidder VARCHAR(80) DEFAULT NULL,
    bid BIGINT NOT NULL DEFAULT 0,
    expires_at BIGINT NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'open',
    INDEX market_status (status, expires_at),
    INDEX market_seller (seller)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Refunds and sale proceeds are claimed through the civic centre. This keeps
-- payouts safe for offline characters without editing ESX account JSON.
CREATE TABLE IF NOT EXISTS egg_city_payouts (
    identifier VARCHAR(80) PRIMARY KEY,
    amount BIGINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS egg_city_claims (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(80) NOT NULL,
    listing_id INT UNSIGNED NOT NULL,
    item VARCHAR(48) NOT NULL,
    quantity INT NOT NULL,
    claimed TINYINT NOT NULL DEFAULT 0,
    UNIQUE KEY one_listing_claim (listing_id),
    INDEX claim_owner (identifier, claimed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
