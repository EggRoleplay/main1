-- Run after ESX and egg_core migrations. Skills live in egg_core, not this resource.
CREATE TABLE IF NOT EXISTS `egg_work_fishing` (
    `identifier` VARCHAR(100) NOT NULL,
    `species` VARCHAR(32) NOT NULL,
    `catches` INT UNSIGNED NOT NULL DEFAULT 0,
    `total_grams` BIGINT UNSIGNED NOT NULL DEFAULT 0,
    `largest_grams` INT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (`identifier`, `species`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `egg_work_blueprints` (
    `identifier` VARCHAR(100) NOT NULL,
    `recipe` VARCHAR(32) NOT NULL,
    `learned_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`identifier`, `recipe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Item definitions are centralized in 10_items.sql.
