#!/usr/bin/env python3
"""Lua 5.4 syntax and mocked FiveM/ESX boundary tests; no live FXServer claim.

Install the pinned check dependency in an external directory:
    python3 -m pip install --target /tmp/egg-validation lupa==2.8
    PYTHONPATH=/tmp/egg-validation python3 tests/run_checks.py
"""
from pathlib import Path
import re
import sys

try:
    from lupa.lua54 import LuaRuntime
except ImportError:
    sys.exit("Missing Lua 5.4 runtime: install lupa==2.8 as shown in this file's docstring.")

ROOT = Path(__file__).resolve().parents[1]
RESOURCES = ROOT / "resources" / "[egg]"

MOCKS = r'''
Mock = { timer=10000, now=1700000000, current='egg_core', players={}, items={},
    callbacks={}, events={}, exports={}, resources={}, positions={}, buckets={},
    threads={}, commands={}, calls={}, rules={}, skills={}, clients={}, cancelled=0,
    entities={}, nextEntity=1000, nextInsert=0, waits=0 }
local mt = {}
mt.__sub = function(a,b) return setmetatable({x=a.x-b.x,y=a.y-b.y,z=a.z-b.z},mt) end
mt.__len = function(a) return math.sqrt(a.x*a.x+a.y*a.y+a.z*a.z) end
function vector3(x,y,z) return setmetatable({x=x,y=y,z=z},mt) end
function GetGameTimer() return Mock.timer end
function GetInvokingResource() return Mock.invoking or Mock.current end
function GetCurrentResourceName() return Mock.current end
function CreateThread(fn) Mock.threads[#Mock.threads+1]={fn=fn, resource=Mock.current} end
function Wait(ms)
    if Mock.threadMode then coroutine.yield(ms); return end
    Mock.waits=Mock.waits+1
    if Mock.waits>100 then error('Mock wait budget exceeded: possible unreleased lock') end
    Mock.timer=Mock.timer+ms
end
function IsPlayerAceAllowed(src,perm) return Mock.players[src] and Mock.players[src].aces[perm]==true or false end
function GetPlayerPed(src) return Mock.players[tonumber(src)] and tonumber(src) or 0 end
function DoesEntityExist(id) return Mock.players[id]~=nil or Mock.entities[id]~=nil end
function GetEntityCoords(id) return Mock.positions[id] or vector3(0,0,0) end
function GetEntityHealth(id) return Mock.players[id] and Mock.players[id].health or 200 end
function GetVehiclePedIsIn(id) return Mock.players[id] and Mock.players[id].vehicle or 0 end
function GetPlayerRoutingBucket(id) return Mock.buckets[id] or 0 end
function SetPlayerRoutingBucket(id,bucket) Mock.buckets[id]=bucket end
function GetEntityRoutingBucket(id) return Mock.buckets[id] or 0 end
function SetEntityRoutingBucket(id,bucket) Mock.buckets[id]=bucket end
function SetRoutingBucketPopulationEnabled() end
function SetEntityCoords(id,x,y,z) Mock.positions[id]=vector3(x,y,z) end
function GetPlayers()
    local result={} for id in pairs(Mock.players) do result[#result+1]=tostring(id) end
    table.sort(result) return result
end
function GetPlayerName(id) return Mock.players[tonumber(id)] and Mock.players[tonumber(id)].getName() or nil end
function GetEntityHeading() return 0 end
function SetRoutingBucketEntityLockdownMode() end
function GetPlayerPing() return 35 end
function GetResourceState(name) return Mock.resources[name] and 'started' or 'missing' end
function GetConvar(_,fallback) return fallback end
function GetConvarInt(_,fallback) return fallback end
function TriggerClientEvent(name,src,...) Mock.clients[#Mock.clients+1]={name=name,source=src,args={...}} end
function TriggerEvent(name,...) Mock.fire(name,0,...) end
function AddEventHandler(name,fn)
    Mock.events[name]=Mock.events[name] or {}
    Mock.events[name][#Mock.events[name]+1]={fn=fn,resource=Mock.current}
end
function RegisterNetEvent(name,fn) if fn then AddEventHandler(name,fn) end end
function RegisterCommand(name,fn) Mock.commands[name]={fn=fn,resource=Mock.current} end
function CancelEvent() Mock.cancelled=Mock.cancelled+1 end
function DropPlayer(src,message) Mock.players[src]=nil; Mock.dropped=message end
function PerformHttpRequest(_,cb) cb(204,'') end
function GetHashKey(name)
    local n=17 for i=1,#name do n=(n*31+name:byte(i))%4294967296 end return n
end
joaat=GetHashKey
function CreateVehicleServerSetter(model,kind,x,y,z,h)
    Mock.nextEntity=Mock.nextEntity+1 local id=Mock.nextEntity
    Mock.entities[id]={model=model,kind=kind,plate='',state={},speed=0,driver=0}
    Mock.positions[id]=vector3(x,y,z) return id
end
function CreateObject(model,x,y,z) return CreateVehicleServerSetter(model,'object',x,y,z,0) end
function DeleteEntity(id) Mock.entities[id]=nil; Mock.positions[id]=nil end
function GetAllVehicles()
    local result={} for id,e in pairs(Mock.entities) do if e.kind~='object' then result[#result+1]=id end end return result
end
function NetworkGetNetworkIdFromEntity(id) return DoesEntityExist(id) and id or 0 end
function NetworkGetEntityFromNetworkId(id) return DoesEntityExist(id) and id or 0 end
function GetEntityModel(id) return Mock.entities[id] and Mock.entities[id].model or 0 end
function GetEntityType(id) return Mock.entities[id] and (Mock.entities[id].kind=='object' and 3 or 2) or 1 end
function SetVehicleNumberPlateText(id,plate) Mock.entities[id].plate=plate end
function GetVehicleNumberPlateText(id) return Mock.entities[id] and Mock.entities[id].plate or '' end
function GetEntitySpeed(id) return Mock.entities[id] and Mock.entities[id].speed or 0 end
function GetPedInVehicleSeat(id) return Mock.entities[id] and Mock.entities[id].driver or 0 end
function GetVehicleClass() return 0 end
function SetEntityHeading() end
function FreezeEntityPosition() end
function SetEntityOrphanMode() end
function Entity(id)
    local data=Mock.entities[id].state
    local state=setmetatable({set=function(_,key,val) data[key]=val end},{__index=data})
    return {state=state}
end
json={ encode=function(value) Mock.lastJson=value; return type(value)=='table' and 'mock JSON object' or tostring(value) end,
    decode=function(value) if type(value)=='table' then return value end error('JSON fixture must be a table') end }
local realPrint=print
print=function(...) Mock.lastPrint={...} end
local nativeTime=os.time
os.time=function() return Mock.now end
ESX={}
function ESX.GetPlayerFromId(src)
    local player=Mock.players[tonumber(src)]
    if not player or not Mock.freshPlayers then return player end
    local copy={} for key,value in pairs(player) do copy[key]=value end return copy
end
function ESX.GetItems() return Mock.items end
function ESX.GetExtendedPlayers() return Mock.players end
function ESX.RegisterServerCallback(name,fn)
    if Mock.crossrefs then
        local resource=Mock.current
        Mock.callbacks[name]=function(...) return Mock.cross(fn,resource,...) end
    else Mock.callbacks[name]=fn end
end
function ESX.RegisterUsableItem(name,fn) Mock.usables=Mock.usables or {}; Mock.usables[name]=fn end
function ESX.DoesJobExist(name,grade) return type(name)=='string' and name~='fake' and type(grade)=='number' and grade>=0 and grade<=5 end
function Mock.cross(fn,resource,...)
    local args=table.pack(...)
    local previous,invoking=Mock.current,Mock.invoking
    Mock.invoking,Mock.current=previous,resource
    local thread=coroutine.create(function() return fn(table.unpack(args,1,args.n)) end)
    local results=table.pack(coroutine.resume(thread))
    Mock.current,Mock.invoking=previous,invoking
    assert(results[1],results[2])
    assert(coroutine.status(thread)=='dead','Cross-reference mock yielded unexpectedly')
    return table.unpack(results,2,results.n)
end
function Mock.marshal(value,resource,seen)
    if type(value)=='function' then return setmetatable({__cfx_functionReference='test-ref'}, {__call=function(_, ...)
        local args=table.pack(...)
        local caller=Mock.current
        for i=1,args.n do args[i]=Mock.marshal(args[i],caller) end
        local results=table.pack(Mock.cross(value,resource,table.unpack(args,1,args.n)))
        for i=1,results.n do results[i]=Mock.marshal(results[i],resource) end
        return table.unpack(results,1,results.n)
    end}) end
    if type(value)=='table' and rawget(value,'__cfx_functionReference') then return value end
    if type(value)~='table' then return value end
    seen=seen or {} if seen[value] then return seen[value] end
    local copy={} seen[value]=copy
    for key,item in pairs(value) do copy[key]=Mock.marshal(item,resource,seen) end
    return setmetatable(copy,getmetatable(value))
end
exports=setmetatable({}, {
    __call=function(_,name,fn)
        Mock.exports[Mock.current]=Mock.exports[Mock.current] or {}
        Mock.exports[Mock.current][name]=fn
    end,
    __index=function(_,resource)
        if resource=='es_extended' then return {getSharedObject=function() return ESX end} end
        return setmetatable({}, {__index=function(_,key)
            return function(_,...) local fn=Mock.exports[resource] and Mock.exports[resource][key]
                assert(fn,'Missing export '..resource..':'..key)
                if not Mock.crossrefs then return fn(...) end
                local args=table.pack(...)
                local caller=Mock.current
                for i=1,args.n do args[i]=Mock.marshal(args[i],caller) end
                local results=table.pack(Mock.cross(fn,resource,table.unpack(args,1,args.n)))
                for i=1,results.n do results[i]=Mock.marshal(results[i],resource) end
                return table.unpack(results,1,results.n)
            end
        end})
    end
})
function Mock.addPlayer(id,job,grade,group)
    local p={source=id,identifier='license:player'..id,job={name=job or 'unemployed',grade=grade or 0,label=job or 'Unemployed'},
        group=group or 'user',aces={},money=5000,accounts={bank={money=500000},black_money={money=0}},inventory={},health=200,vehicle=0,carry=true,loadout={}}
    p.getIdentifier=function() return p.identifier end
    p.getName=function() return 'Player '..id end
    p.getGroup=function() return p.group end
    p.getJob=function() return p.job end
    p.setJob=function(name,rank) p.job={name=name,grade=rank,label=name} end
    p.getMoney=function() return p.money end
    p.addMoney=function(amount) p.money=p.money+amount end
    p.removeMoney=function(amount) p.money=p.money-amount end
    p.getAccount=function(name) return p.accounts[name] end
    p.addAccountMoney=function(name,amount) p.accounts[name].money=p.accounts[name].money+amount end
    p.removeAccountMoney=function(name,amount) p.accounts[name].money=p.accounts[name].money-amount end
    p.getInventoryItem=function(name)
        if not Mock.items[name] then return nil end
        return {name=name,label=name,count=p.inventory[name] or 0,limit=p.limit or -1}
    end
    p.canCarryItem=function(name,count) return p.carry==true and (not p.denyItem or name~=p.denyItem) end
    p.addInventoryItem=function(name,count) p.inventory[name]=(p.inventory[name] or 0)+count end
    p.removeInventoryItem=function(name,count) p.inventory[name]=(p.inventory[name] or 0)-count end
    p.getLoadout=function() return p.loadout end
    Mock.players[id]=p Mock.positions[id]=vector3(0,0,0) return p
end
function Mock.sql(kind,sql,args)
    args=args or {}
    Mock.calls[#Mock.calls+1]={kind=kind,sql=sql,args=args}
    for _,rule in ipairs(Mock.rules) do
        if rule.kind==kind and ((type(sql)=='string' and sql:find(rule.pattern,1,true)) or (kind=='transaction' and rule.pattern=='')) then
            if rule.error then error(rule.error) end
            if rule.fn then return rule.fn(kind=='transaction' and sql or args,sql) end
            return rule.value
        end
    end
    if kind=='scalar' then
        if sql:find('SELECT xp',1,true) then return Mock.skills[args[1]..':'..args[2]] or 0 end
        if sql:find('COUNT(',1,true) or sql:find('SUM(',1,true) then return 0 end
        if sql:find('UUID()',1,true) then return 'mock-unique-uuid' end
        if sql:find('SHA2(',1,true) then return 'EGG-MOCK-FINGERPRINT' end
        return nil
    elseif kind=='query' then return {}
    elseif kind=='single' then return nil
    elseif kind=='transaction' then return true
    elseif kind=='insert' then Mock.nextInsert=Mock.nextInsert+1 return Mock.nextInsert
    elseif kind=='update' then
        if sql:find('INSERT INTO egg_skills',1,true) then
            local key=args[1]..':'..args[2] Mock.skills[key]=math.min(980100,(Mock.skills[key] or 0)+args[3])
        end
        return 1
    end
    error('Unknown DB operation '..tostring(kind))
end
MySQL={ready=function(fn) fn() end}
for _,kind in ipairs({'scalar','single','query','insert','update','transaction'}) do
    MySQL[kind]=setmetatable({await=function(sql,args) return Mock.sql(kind,sql,args) end},
        {__call=function(_,sql,args) return Mock.sql(kind,sql,args) end})
end
function Mock.action(src,name,payload)
    local result, count=nil,0
    Mock.callbacks['egg:action'](src,function(value) result=value count=count+1 end,name,payload or {})
    assert(count==1,'Action callback must answer exactly once') return result
end
function Mock.advance(seconds) Mock.now=Mock.now+seconds Mock.timer=Mock.timer+seconds*1000 Mock.waits=0 end
function Mock.move(src,point) Mock.positions[src]=vector3(point.x,point.y,point.z) end
function Mock.addRule(kind,pattern,value)
    Mock.rules[#Mock.rules+1]={kind=kind,pattern=pattern,value=value}
end
function Mock.countSql(fragment)
    local count=0 for _,call in ipairs(Mock.calls) do if type(call.sql)=='string' and call.sql:find(fragment,1,true) then count=count+1 end end return count
end
function Mock.fire(name,src,...)
    local previous=Mock.current
    for _,event in ipairs(Mock.events[name] or {}) do
        local env=Mock.resources[event.resource] env.source=src
        Mock.current=event.resource
        if Mock.crossrefs then Mock.cross(event.fn,event.resource,...) else event.fn(...) end
    end
    Mock.current=previous
end
function Mock.loadResource(name)
    local env=setmetatable({}, {__index=_G})
    env.GetCurrentResourceName=function() return name end
    Mock.resources[name]=env Mock.current=name return env
end
'''


class Harness:
    def __init__(self, *modules, crossrefs=True, fresh_players=True):
        self.lua = LuaRuntime(unpack_returned_tuples=True)
        self.lua.execute(MOCKS)
        self.g = self.lua.globals()
        self.mock = self.g.Mock
        self.mock.crossrefs = crossrefs
        self.mock.freshPlayers = fresh_players
        self.mock.addPlayer(1)
        self.mock.addPlayer(2)
        item_names = {"bread", "water", "fish", "iron", "copper", "gold", "bandage", "medikit", "repairkit", "lockpick", "radio", "phone", "gps"}
        for path in RESOURCES.rglob("*.lua"):
            item_names.update(re.findall(r"['\"](egg_[a-z_]+)['\"]", path.read_text()))
        for name in item_names:
            self.mock["items"][name] = self.lua.table_from({"name": name})
        self.envs = {}
        self.load("egg_core")
        for name in modules:
            self.load(name)

    def load(self, name):
        env = self.mock.loadResource(name)
        self.envs[name] = env
        directory = RESOURCES / name
        if (directory / "config.lua").exists():
            self.chunk(directory / "config.lua", env)
        bridge = RESOURCES / "egg_core" / "server_api.lua"
        if name != "egg_core" and bridge.exists():
            self.chunk(bridge, env)
        files = [directory / "server.lua"] if (directory / "server.lua").exists() else sorted((directory / "server").rglob("*.lua"))
        assert files, f"Missing server implementation: {name}"
        for path in files:
            self.chunk(path, env)
        return env

    def chunk(self, path, env):
        fn = self.lua.eval("function(code,name,env) local fn,err=load(code,name,'t',env); assert(fn,err); return fn() end")
        fn(path.read_text(), str(path.relative_to(ROOT)), env)

    def in_resource(self, name, code):
        env = self.mock.resources[name]
        assert env is not None, f"Resource must be loaded: {name}"
        self.mock.current = name
        fn = self.lua.eval("function(code,name,env) local fn,err=load(code,name,'t',env); assert(fn,err); return fn() end")
        fn(code, f"test:{name}", env)

    def execute(self, code):
        self.lua.execute(code)

    def table(self, value):
        if isinstance(value, dict):
            return self.lua.table_from({key: self.table(item) for key, item in value.items()})
        if isinstance(value, list):
            return self.lua.table_from([self.table(item) for item in value])
        return value

    def action(self, name, payload=None, source=1, advance=2):
        self.mock.advance(advance)
        return self.mock.action(source, name, self.table(payload or {}))

    def core(self, name, *args):
        return self.mock.exports.egg_core[name](*args)

    def player(self, source=1):
        return self.mock.players[source]

    def move(self, point, source=1):
        self.mock.move(source, point)

    def rule(self, kind, pattern, value):
        self.mock.addRule(kind, pattern, self.table(value))


CHECKS = []


def check(name):
    def register(fn):
        CHECKS.append((name, fn))
        return fn
    return register


def rejected(value, fragment=None):
    assert value["ok"] is False, f"Expected rejection, got {value}"
    assert isinstance(value["error"], str) and value["error"], "Rejection needs a useful error"
    if fragment:
        assert fragment.lower() in value["error"].lower(), value["error"]


def accepted(value):
    assert value["ok"] is True, f"Expected success, got error {value['error']}"


@check("Lua 5.4 compiles every resource script and manifest")
def syntax():
    lua = LuaRuntime(unpack_returned_tuples=True)
    compile_lua = lua.eval("function(code,name) local fn,err=load(code,name,'t',{}); assert(fn,err); return true end")
    paths = sorted(RESOURCES.rglob("*.lua"))
    assert len(paths) >= 20, "Expected a nonempty resource pack"
    for path in paths:
        compile_lua(path.read_text(), str(path.relative_to(ROOT)))
    print(f"    compiled {len(paths)} Lua files")


@check("Every bound API consumer declares bridge load before its server implementation")
def bridge_manifests():
    consumers = 0
    for directory in RESOURCES.iterdir():
        if not directory.is_dir() or directory.name == "egg_core":
            continue
        server_files = ([directory / "server.lua"] if (directory / "server.lua").exists()
                        else list((directory / "server").rglob("*.lua")))
        if any("EggCore" in path.read_text() for path in server_files):
            consumers += 1
            manifest = (directory / "fxmanifest.lua").read_text()
            assert "@egg_core/server_api.lua" in manifest, f"Missing bridge: {directory.name}"
            bridge_pos = manifest.index("@egg_core/server_api.lua")
            for path in server_files:
                relative = path.relative_to(directory).as_posix()
                assert relative in manifest, f"Missing server declaration: {relative}"
                assert bridge_pos < manifest.index(relative), f"Bridge loads too late: {directory.name}"
    assert consumers >= 6, "Expected bound API modules"


@check("Core rejects unavailable players and unknown actions")
def unavailable():
    h = Harness()
    h.execute("exports.egg_core:RegisterAction('test.valid',{},function() return {ok=true} end)")
    rejected(h.action("test.valid", source=88), "unavailable")
    rejected(h.action("missing"), "unavailable")


@check("Core enforces staff, ACE, and job gates before mutation")
def gates():
    h = Harness()
    h.execute("hits=0; exports.egg_core:RegisterAction('test.staff',{staff=true},function() hits=hits+1 return {ok=true} end); exports.egg_core:RegisterAction('test.police',{job={police=true}},function() hits=hits+1 return {ok=true} end)")
    rejected(h.action("test.staff"), "staff")
    rejected(h.action("test.police"), "job")
    assert h.g.hits == 0
    h.player().group = "admin"
    accepted(h.action("test.staff"))
    h.player().group = "user"
    h.player().aces["egg.staff"] = True
    accepted(h.action("test.staff"))
    h.player().setJob("police", 0)
    accepted(h.action("test.police"))
    assert h.g.hits == 3


@check("Core rejects cooldown and global callback spam")
def cooldowns():
    h = Harness()
    h.execute("hits=0; for _,name in ipairs({'a','b'}) do exports.egg_core:RegisterAction(name,{cooldown=1000},function() hits=hits+1 return {ok=true} end) end")
    accepted(h.action("a"))
    rejected(h.action("a", advance=0), "moment")
    rejected(h.action("b", advance=0), "moment")
    rejected(h.action("a", advance=0.2), "moment")
    accepted(h.action("b", advance=0))
    accepted(h.action("a", advance=1))
    assert h.g.hits == 3


@check("Core bounds nested, oversized and nonfinite client payloads")
def payloads():
    h = Harness()
    h.execute("hits=0; exports.egg_core:RegisterAction('payload',{},function() hits=hits+1 return {ok=true} end)")
    bad = [{"text": "x" * 4097}, {str(i): i for i in range(101)},
           {"a": "x" * 4000, "b": "x" * 4000, "c": "x" * 4000, "d": "x" * 4000},
           {"a": {"b": {"c": {"d": {"e": 1}}}}},
           {"number": float("nan")}, {"number": float("inf")}, {"number": -float("inf")}]
    for payload in bad:
        rejected(h.action("payload", payload), "invalid")
    accepted(h.action("payload", {"a": {"b": {"c": 1}}, "flag": True}))
    assert h.g.hits == 1


@check("Core money helpers reject invalid amounts, missing accounts and overspend")
def funds():
    h = Harness()
    original = h.player().accounts.bank.money
    for amount in [-1, 0, 0.5, 10000001, float("nan"), float("inf"), "50"]:
        assert h.core("TryDebit", 1, amount, "bank") is False
        assert h.core("Credit", 1, amount, "bank") is False
    assert h.core("TryDebit", 1, original + 1, "bank") is False
    assert h.core("TryDebit", 1, 1, "missing") is False
    assert h.core("Credit", 1, 1, "missing") is False
    assert h.core("Credit", 88, 1, "bank") is False
    assert h.player().accounts.bank.money == original
    assert h.core("TryDebit", 1, 250, "bank") is True
    assert h.player().accounts.bank.money == original - 250
    assert h.core("Credit", 1, 250, "bank") is True
    assert h.player().accounts.bank.money == original


@check("Core item helpers enforce definitions, quantity, ownership and capacity")
def items():
    h = Harness()
    for count in [-1, 0, 0.5, 1001, float("nan"), float("inf")]:
        assert h.core("AddItem", 1, "bread", count) is False
        assert h.core("RemoveItem", 1, "bread", count) is False
    assert h.core("AddItem", 1, "unregistered", 1) is False
    assert h.core("AddItem", 88, "bread", 1) is False
    assert h.core("RemoveItem", 1, "bread", 1) is False
    h.player().carry = False
    assert h.core("AddItem", 1, "bread", 1) is False
    h.player().carry = True
    assert h.core("AddItem", 1, "bread", 3) is True
    assert h.core("HasItem", 1, "bread", 3) is True
    assert h.core("RemoveItem", 1, "bread", 4) is False
    assert h.core("RemoveItem", 1, "bread", 2) is True
    assert h.player().inventory.bread == 1
    h.player().canCarryItem = None
    h.player().limit = 1
    assert h.core("AddItem", 1, "bread", 1) is False


@check("Core skill XP progression uses persisted authoritative grants and caps")
def progression():
    h = Harness()
    assert h.core("GetSkill", 1, "fishing")["level"] == 1
    assert h.core("AddXP", 1, "fishing", 100) is True
    assert h.core("GetSkill", 1, "fishing")["level"] == 2
    for value in [0, -1, 1.5, 1001]:
        assert h.core("AddXP", 1, "fishing", value) is False
    assert h.core("AddXP", 1, "bad;sql", 10) is False
    assert h.core("AddXP", 88, "fishing", 10) is False
    h.mock.skills["license:player1:fishing"] = 980050
    assert h.core("AddXP", 1, "fishing", 100) is True
    record = h.core("GetSkill", 1, "fishing")
    assert record["level"] == 100 and record["xp"] == 980100


@check("Core locks and busy state release after throws; callbacks answer failures")
def recovery():
    h = Harness()
    h.execute("local good=pcall(function() exports.egg_core:WithLock('broken',function() error('expected') end) end); assert(not good); assert(exports.egg_core:WithLock('broken',function() return 42 end)==42); exports.egg_core:RegisterAction('broken',{},function() error('expected handler failure') end); exports.egg_core:RegisterAction('next',{},function() return {ok=true} end); exports.egg_core:RegisterAction('empty',{},function() end)")
    rejected(h.action("broken"), "could not complete")
    accepted(h.action("next"))
    rejected(h.action("empty"), "no result")
    h.execute("local good=pcall(function() Mock.callbacks['egg:action'](1,function() error('callback throws') end,'next',{}) end); assert(not good)")
    accepted(h.action("next"))


@check("Core proximity checks require spawned player and server coordinates")
def proximity():
    h = Harness()
    assert h.core("RequireNear", 1, h.table({"x": 0, "y": 0, "z": 0}), 4) is True
    assert h.core("RequireNear", 1, h.table({"x": 10, "y": 0, "z": 0}), 4) is False
    for radius in [-1, 0, 251]:
        assert h.core("RequireNear", 1, h.table({"x": 0, "y": 0, "z": 0}), radius) is False
    assert h.core("RequireNear", 88, h.table({"x": 0, "y": 0, "z": 0}), 4) is False


@check("Stopped resource action handlers cannot remain callable")
def stop_resource():
    h = Harness()
    h.mock.current = "temporary"
    h.execute("exports.egg_core:RegisterAction('temporary.action',{},function() return {ok=true} end)")
    accepted(h.action("temporary.action"))
    h.mock.fire("onResourceStop", 0, "temporary")
    rejected(h.action("temporary.action"), "unavailable")


@check("Disconnect and reused player source cannot receive stale action money or items")
def source_reuse():
    h = Harness()
    h.execute("""
        exports.egg_core:RegisterAction('disconnect',{},function(source,player,data,context)
            Mock.fire('playerDropped',source)
            Mock.addPlayer(source).identifier='license:new-character'
            assert(context.Identifier(nil,source)==nil)
            assert(not context.Credit(nil,source,250,'bank'))
            assert(not context.TryDebit(nil,source,250,'bank'))
            assert(not context.AddItem(nil,source,'bread',1))
            assert(not context.AddXP(nil,source,'fishing',100))
            staleGuardComplete=true
            return {ok=true}
        end)
    """)
    h.execute("local replies=0; Mock.callbacks['egg:action'](1,function() replies=replies+1 end,'disconnect',{}); assert(replies==0,'Disconnected source must not receive callback'); assert(staleGuardComplete)")
    assert h.player().accounts.bank.money == 500000
    assert (h.player().inventory.bread or 0) == 0
    assert h.core("GetSkill", 1, "fishing").xp == 0
    assert h.core("Credit", 1, 250, "bank") is True
    assert h.player().accounts.bank.money == 500250


@check("CFX functionref coroutine boundaries preserve bound identity inside nested locks")
def crossreference_bound_context():
    h = Harness("egg_staff", crossrefs=True, fresh_players=True)
    h.in_resource("egg_staff", """
        local core=EggCore
        core:RegisterAction('bridge.stale',{},function(source)
            return core:WithLock('outer',function()
                return core:WithLock('inner',function()
                    assert(core:Credit(source,10,'bank'))
                    Mock.fire('playerDropped',source)
                    Mock.addPlayer(source).identifier='license:replacement-bridge'
                    assert(not core:SessionAlive())
                    assert(core:Identifier(source)==nil)
                    assert(not core:Credit(source,999,'bank'))
                    assert(not core:AddItem(source,'bread',1))
                    assert(not core:AddXP(source,'fishing',100))
                    bridgeTestCompleted=true
                    return {ok=true}
                end)
            end)
        end)
    """)
    h.execute("local replies=0; Mock.callbacks['egg:action'](1,function() replies=replies+1 end,'bridge.stale',{}); assert(replies==0)")
    assert h.envs["egg_staff"].bridgeTestCompleted is True
    assert h.player().accounts.bank.money == 500000
    assert (h.player().inventory.bread or 0) == 0
    assert h.core("GetSkill", 1, "fishing").xp == 0
    h.execute("assert(exports.egg_core:WithLock('outer',function() return 42 end)==42); assert(exports.egg_core:WithLock('inner',function() return 24 end)==24)")


@check("Fresh decoded ESX player wrappers can clock on without table identity checks")
def fresh_player_staff_duty():
    h = Harness("egg_staff", crossrefs=True, fresh_players=True)
    h.player().group = "admin"
    h.execute("assert(ESX.GetPlayerFromId(1)~=ESX.GetPlayerFromId(1))")
    accepted(h.action("staff:duty"))
    assert h.mock.exports.egg_staff.IsOnDuty(1) is True
    accepted(h.action("staff:desk"))
    accepted(h.action("staff:duty"))
    assert h.mock.exports.egg_staff.IsOnDuty(1) is False


@check("Work sessions reject early, forged and replayed claims; award once")
def work_sessions():
    h = Harness("egg_work")
    cfg = h.envs["egg_work"].Config
    station = next(s for _, s in cfg.Stations.items() if s.id == "recycle_collect")
    rejected(h.action("work:begin", {"station": station.id}), "walk")
    h.move(station)
    start = h.action("work:begin", {"station": station.id})
    accepted(start)
    rejected(h.action("work:finish", {"token": "forged"}), "ended")
    rejected(h.action("work:finish", {"token": start.token}, advance=0.6), "running")
    done = h.action("work:finish", {"token": start.token}, advance=20)
    accepted(done)
    assert h.player().inventory.egg_recyclables == cfg.Collection.count
    xp = h.core("GetSkill", 1, "recycling").xp
    rejected(h.action("work:finish", {"token": start.token}), "ended")
    assert h.player().inventory.egg_recyclables == cfg.Collection.count
    assert h.core("GetSkill", 1, "recycling").xp == xp
    rejected(h.action("work:begin", {"station": station.id}), "recover")


@check("Work output capacity failure rolls back inputs and partial grants")
def work_rollback():
    h = Harness("egg_work")
    cfg = h.envs["egg_work"].Config
    station = next(s for _, s in cfg.Stations.items() if s.id == "smelter")
    recipe = cfg.Smelting[1]
    # Both orderings of Lua pairs must restore the same inputs if either output fails.
    recipe.outputs.egg_scrap = 2
    recipe.outputs.egg_plastic = 1
    h.player().inventory.egg_scrap = 3
    h.player().denyItem = "egg_plastic"
    h.move(station)
    start = h.action("work:begin", {"station": station.id, "recipe": recipe.id})
    accepted(start)
    rejected(h.action("work:finish", {"token": start.token}, advance=30), "room")
    assert h.player().inventory.egg_scrap == 3
    assert (h.player().inventory.egg_steel or 0) == 0
    assert (h.player().inventory.egg_plastic or 0) == 0
    assert h.core("GetSkill", 1, "recycling").xp == 0


@check("Work requires learned blueprint and never accepts a client price")
def work_blueprints_prices():
    h = Harness("egg_work")
    cfg = h.envs["egg_work"].Config
    workshop = next(s for _, s in cfg.Stations.items() if s.id == "workshop")
    h.move(workshop)
    rejected(h.action("work:begin", {"station": workshop.id, "recipe": "rod"}), "blueprint")
    h.move(next(s for _, s in cfg.Stations.items() if s.id == "supplies"))
    bank = h.player().accounts.bank.money
    accepted(h.action("work:trade", {"station": "supplies", "item": "egg_bait", "count": 2, "price": 0}))
    price = next(s.price for _, s in cfg.Shop.items() if s.item == "egg_bait")
    assert h.player().accounts.bank.money == bank - price * 2
    assert h.player().inventory.egg_bait == 2
    rejected(h.action("work:trade", {"station": "supplies", "item": "egg_bait", "count": -2}), "valid")


@check("Work shop refunds when inventory cannot accept purchase")
def work_refund():
    h = Harness("egg_work")
    h.move(next(s for _, s in h.envs["egg_work"].Config.Stations.items() if s.id == "supplies"))
    h.player().carry = False
    bank = h.player().accounts.bank.money
    rejected(h.action("work:trade", {"station": "supplies", "item": "egg_bait", "count": 1}), "room")
    assert h.player().accounts.bank.money == bank
    assert (h.player().inventory.egg_bait or 0) == 0


@check("Crime sessions enforce location, time and single completion payout")
def crime_replay():
    h = Harness("egg_crime")
    cfg = h.envs["egg_crime"].Config
    location = cfg.Locations.mail[1]
    rejected(h.action("crime:start", {"kind": "mail", "location": location.id}), "closer")
    h.move(location.coords)
    start = h.action("crime:start", {"kind": "mail", "location": location.id})
    accepted(start)
    rejected(h.action("crime:step", {"id": "forged"}), "active")
    rejected(h.action("crime:step", {"id": start.session.id}), "finished")
    accepted(h.action("crime:step", {"id": start.session.id}, advance=30))
    balance = h.player().accounts.black_money.money
    assert location.minPay <= balance <= location.maxPay
    assert h.player().inventory.egg_stolen_mail == 1
    rejected(h.action("crime:step", {"id": start.session.id}), "active")
    assert h.player().accounts.black_money.money == balance
    assert h.player().inventory.egg_stolen_mail == 1
    rejected(h.action("crime:start", {"kind": "mail", "location": location.id}), "recently")


@check("Crime police, class and staff checks cannot be supplied by client")
def crime_gates():
    h = Harness("egg_crime")
    cfg = h.envs["egg_crime"].Config
    location = cfg.Locations.store[1]
    h.move(location.coords)
    rejected(h.action("crime:start", {"kind": "store", "location": location.id, "police": 99}), "police")
    h.move(cfg.CrimeDesk)
    rejected(h.action("crime:start", {"kind": "boost", "class": "S", "level": 100}), "level")
    rejected(h.action("crime:gangSet", {"target": 2, "gang": "ballas"}), "staff")
    assert h.mock.countSql("INSERT INTO egg_gang_members") == 0


@check("House burglary requires three timed interior searches and restores original dimension")
def crime_house():
    h = Harness("egg_crime")
    cfg = h.envs["egg_crime"].Config
    h.player(2).setJob("police", 0)
    h.mock.addPlayer(3, "police", 0, "user")
    house = cfg.Locations.house[1]
    h.move(house.coords)
    h.mock.buckets[1] = 7
    h.player().inventory.egg_lockpick = 1
    start = h.action("crime:start", {"kind": "house", "location": house.id})
    accepted(start)
    assert start.session.searches == 3
    assert h.player().inventory.egg_lockpick == 0
    assert h.mock.buckets[1] == cfg.House.bucketBase + 1
    sid = start.session.id
    rejected(h.action("crime:work", {"id": sid}), "closer")
    h.move(start.session.coords)
    h.mock.buckets[1] = 99
    rejected(h.action("crime:work", {"id": sid}), "house")
    h.mock.buckets[1] = cfg.House.bucketBase + 1
    session = start.session
    for _ in range(3):
        h.move(session.coords)
        accepted(h.action("crime:work", {"id": sid}))
        rejected(h.action("crime:step", {"id": sid}), "finished")
        outcome = h.action("crime:step", {"id": sid}, advance=cfg.House.searchSeconds + 1)
        accepted(outcome)
        session = outcome.session
    assert outcome.completed is True
    assert h.mock.buckets[1] == 7
    assert abs(h.mock.positions[1].x - house.coords.x) < 0.01
    balance = h.player().accounts.black_money.money
    assert house.minPay <= balance <= house.maxPay
    assert h.player().inventory.egg_stolen_goods == 1
    rejected(h.action("crime:step", {"id": sid}), "active")
    assert h.player().accounts.black_money.money == balance


@check("City ownership and employment checks reject remote or self grants")
def city_gates():
    h = Harness("egg_city")
    cfg = h.envs["egg_city"].Config
    room = cfg.Rooms[1]
    bank = h.player().accounts.bank.money
    rejected(h.action("city.room.buy", {"id": room.id}), "civic")
    assert h.player().accounts.bank.money == bank
    h.move(room.door)
    rejected(h.action("city.room.enter", {"id": room.id}), "keys")
    assert h.mock.buckets[1] is None
    h.move(cfg.Hub)
    h.move(cfg.Hub, source=2)
    rejected(h.action("city.job.hire", {"target": 2, "job": "police", "grade": 5}), "rank")
    h.player().group = "admin"
    rejected(h.action("city.job.hire", {"target": 1, "job": "police", "grade": 0}), "another")
    assert h.mock.countSql("INSERT INTO egg_city_jobs") == 0


@check("City room purchase returns money if SQL transaction fails")
def city_refund():
    h = Harness("egg_city")
    cfg = h.envs["egg_city"].Config
    h.move(cfg.Hub)
    bank = h.player().accounts.bank.money
    h.rule("transaction", "", False)
    rejected(h.action("city.room.buy", {"id": cfg.Rooms[1].id}), "returned")
    assert h.player().accounts.bank.money == bank


@check("City business sale conserves buyer, revenue and commission across failed delivery")
def city_business_sale():
    h = Harness("egg_city")
    business = h.envs["egg_city"].Config.Businesses[1]
    product = business.products[1]
    h.move(business.location)
    h.move(business.location, source=2)
    h.rule("scalar", "SELECT owner FROM egg_city_businesses", "license:business-owner")
    h.rule("scalar", "SELECT commission FROM egg_city_employees", 10)
    h.execute("""
        businessRevenue=0; employeePayout=0
        Mock.rules[#Mock.rules+1]={kind='transaction',pattern='',fn=function(queries)
            if rejectNextBusinessTransaction then rejectNextBusinessTransaction=false return false end
            for _,query in ipairs(queries) do
                local sql,args=query.query,query.values
                if sql:find('egg_city_businesses',1,true) then
                    if sql:find('balance = balance +',1,true) then businessRevenue=businessRevenue+args[1]
                    else businessRevenue=businessRevenue-args[1] end
                elseif sql:find('egg_city_payouts',1,true) then
                    if sql:find('INSERT INTO',1,true) then employeePayout=employeePayout+args[2]
                    else employeePayout=employeePayout-args[1] end
                end
            end
            return true
        end}
    """)
    bank = h.player().accounts.bank.money
    payload = {"id": business.id, "product": 1, "employee": 2, "price": 0, "commission": 99}
    h.player().carry = False
    rejected(h.action("city.business.sale", payload), "returned")
    assert h.player().accounts.bank.money == bank
    assert h.g.businessRevenue == 0 and h.g.employeePayout == 0
    assert (h.player().inventory[product.item] or 0) == 0
    h.player().carry = True
    accepted(h.action("city.business.sale", payload))
    expected_commission = int(product.price * 10 / 100)
    assert h.player().accounts.bank.money == bank - product.price
    assert h.g.businessRevenue == product.price - expected_commission
    assert h.g.employeePayout == expected_commission
    assert h.player().accounts.bank.money + h.g.businessRevenue + h.g.employeePayout == bank
    assert h.player().inventory[product.item] == 1
    h.execute("rejectNextBusinessTransaction=true")
    rejected(h.action("city.business.sale", payload), "returned")
    assert h.player().accounts.bank.money == bank - product.price
    assert h.player().inventory[product.item] == 1
    assert h.player().accounts.bank.money + h.g.businessRevenue + h.g.employeePayout == bank


@check("Police records, certificates, lockers and notices deny privilege bypass")
def police_gates():
    h = Harness("egg_police")
    rejected(h.action("police:dashboard"), "job")
    rejected(h.action("police:certify", {"target": 2, "certification": "traffic"}), "job")
    rejected(h.action("police:lockerTransfer", {"item": "bread", "count": 1, "direction": "withdraw"}), "job")
    h.player().setJob("police", 0)
    accepted(h.action("police:dashboard"))
    rejected(h.action("police:fingerprintRequest", {"target": 2}), "certification")
    rejected(h.action("police:lockerTransfer", {"item": "bread", "count": 1, "direction": "withdraw"}), "station")
    rejected(h.action("police:payNotice", {"id": 1}), "unavailable")
    assert h.mock.countSql("INSERT INTO egg_police_fingerprints") == 0


@check("Police fingerprint consent requires current nearby request and is single use")
def police_fingerprints():
    h = Harness("egg_police")
    h.player().setJob("police", 0)
    h.rule("scalar", "egg_police_certifications", 1)
    h.move(h.table({"x": 10, "y": 0, "z": 0}), source=2)
    rejected(h.action("police:fingerprintRequest", {"target": 2}), "within")
    h.move(h.table({"x": 1, "y": 0, "z": 0}), source=2)
    accepted(h.action("police:fingerprintRequest", {"target": 2}, advance=4))
    event = next(e for _, e in h.mock.clients.items() if e.name == "egg_police:fingerprintRequest")
    token = event.args[1].token
    rejected(h.action("police:fingerprintConsent", {"token": "forged", "accept": True}, source=2), "expired")
    accepted(h.action("police:fingerprintConsent", {"token": token, "accept": True}, source=2))
    assert h.mock.countSql("INSERT INTO egg_police_fingerprints") == 1
    assert h.mock.countSql("INSERT INTO egg_audit") == 1
    rejected(h.action("police:fingerprintConsent", {"token": token, "accept": True}, source=2), "expired")
    assert h.mock.countSql("INSERT INTO egg_police_fingerprints") == 1


@check("Police cannot collect consent or use lockers across routing buckets")
def police_dimensions():
    h = Harness("egg_police")
    h.player().setJob("police", 0)
    h.rule("scalar", "egg_police_certifications", 1)
    h.mock.buckets[2] = 77
    rejected(h.action("police:fingerprintRequest", {"target": 2}), "within")
    cfg = h.envs["egg_police"].Config
    h.move(cfg.LockerLocations[1])
    h.mock.buckets[1] = 77
    rejected(h.action("police:lockerTransfer", {"item": "bread", "count": 1, "direction": "deposit"}), "station")
    assert h.mock.countSql("INSERT INTO egg_police_fingerprints") == 0
    assert h.mock.countSql("INSERT INTO egg_police_lockers") == 0


@check("Police notice payment never debits a reused player source after SQL yield")
def police_payment_reuse():
    h = Harness("egg_police")
    h.execute("""
        Mock.rules[#Mock.rules+1]={kind='single',pattern='FROM egg_police_infringements',fn=function()
            Mock.addPlayer(1).identifier='license:replacement-driver'
            return {fine=210}
        end}
    """)
    rejected(h.action("police:payNotice", {"id": 1}), "changed")
    assert h.player().accounts.bank.money == 500000
    assert h.mock.countSql("UPDATE egg_police_infringements") == 0


@check("Staff requires permissions and duty for privileged actions")
def staff_permissions():
    h = Harness("egg_staff")
    rejected(h.action("staff:desk"), "staff")
    rejected(h.action("staff:duty"), "staff")
    rejected(h.action("staff:player", {"target": 2, "action": "kick", "reason": "test reason"}), "clock")
    h.player().group = "admin"
    accepted(h.action("staff:desk"))
    rejected(h.action("staff:ticket", {"id": 1, "action": "claim"}), "clock")
    accepted(h.action("staff:duty"))
    assert h.mock.exports.egg_staff.IsOnDuty(1) is True
    accepted(h.action("staff:player", {"target": 2, "action": "kick", "reason": "test reason"}))
    assert h.mock.players[2] is None
    accepted(h.action("staff:duty"))
    assert h.mock.exports.egg_staff.IsOnDuty(1) is False


@check("Guard explosion burst cancellation is bounded and recovers")
def guard_bursts():
    h = Harness("egg_guard")
    for _ in range(12):
        h.mock.fire("explosionEvent", 1, 1, h.table({}))
    assert h.mock.cancelled == 0
    h.mock.fire("explosionEvent", 1, 1, h.table({}))
    assert h.mock.cancelled == 1
    assert h.mock.countSql("INSERT INTO egg_audit") == 1
    h.mock.advance(11)
    h.mock.fire("explosionEvent", 1, 1, h.table({}))
    assert h.mock.cancelled == 1


@check("Staff source reuse during duty insert cannot grant replacement duty")
def staff_reuse():
    h = Harness("egg_staff")
    h.player().group = "admin"
    h.execute("""
        Mock.rules[#Mock.rules+1]={kind='insert',pattern='INSERT INTO egg_staff_duty',fn=function()
            Mock.addPlayer(1).identifier='license:replacement-staff'
            return 7
        end}
    """)
    rejected(h.action("staff:duty"), "changed")
    assert h.mock.exports.egg_staff.IsOnDuty(1) is False
    assert not any(e.name == "egg_staff:duty" and e.args[1] is True for _, e in h.mock.clients.items())
    assert h.mock.countSql("UPDATE egg_staff_duty") >= 1


@check("Staff two-hour shift warns five minutes before automatic clock-off")
def staff_clock():
    h = Harness("egg_staff")
    h.player().group = "admin"
    accepted(h.action("staff:duty"))
    cfg = h.envs["egg_staff"].Config
    h.execute("Mock.threadMode=true; staffCoroutine=coroutine.create(Mock.threads[#Mock.threads].fn); assert(coroutine.resume(staffCoroutine))")
    h.mock.advance(cfg.DutySeconds - 300)
    h.execute("assert(coroutine.resume(staffCoroutine))")
    assert h.mock.exports.egg_staff.IsOnDuty(1) is True
    assert any(e.name == "egg_core:notify" and "Five minutes" in e.args[1] for _, e in h.mock.clients.items())
    h.mock.advance(300)
    h.execute("assert(coroutine.resume(staffCoroutine))")
    assert h.mock.exports.egg_staff.IsOnDuty(1) is False
    assert any(e.name == "egg_staff:duty" and e.args[1] is False for _, e in h.mock.clients.items())


@check("Garages reject remote, invalid and unowned vehicle checkout")
def garage_gates():
    h = Harness("egg_garages")
    cfg = h.envs["egg_garages"].Config
    garage = cfg.Garages[1]
    rejected(h.action("garages:withdraw", {"garage": garage.id, "plate": "TEST123"}), "visit")
    h.move(garage.point)
    rejected(h.action("garages:withdraw", {"garage": garage.id, "plate": "TEST<script>"}, advance=4), "visit")
    rejected(h.action("garages:withdraw", {"garage": garage.id, "plate": "TEST123"}, advance=4), "owned")
    rejected(h.action("garages:store", {"garage": garage.id, "netId": 9999}), "driving")
    assert len(list(h.mock.entities.items())) == 0


@check("Garage authoritative checkout rejects duplicate release and forged vehicle properties")
def garage_cycle():
    h = Harness("egg_garages")
    cfg = h.envs["egg_garages"].Config
    garage = cfg.Garages[1]
    h.move(garage.point)
    h.execute("""
        garageModel=GetHashKey('sultan')
        garageRow={owner='license:player1',plate='TEST123',type='car',stored=1,vehicle={model=garageModel,color1=20,color2=30}}
        garageState={owner='license:player1',plate='TEST123',status='stored',appearance={color1=5,color2=6}}
        Mock.rules[#Mock.rules+1]={kind='query',pattern='FROM owned_vehicles',value={garageRow}}
        Mock.rules[#Mock.rules+1]={kind='single',pattern='FROM egg_garage_state',value=garageState}
        Mock.rules[#Mock.rules+1]={kind='update',pattern='UPDATE egg_garage_state',fn=function(args,sql)
            if sql:find("SET status = 'spawning'",1,true) then
                assert(garageState.status=='stored') garageState.status='spawning' garageState.session_token=args[1]
            elseif sql:find("SET status = 'out', net_id",1,true) then
                assert(garageState.status=='spawning') garageState.status='out' garageState.net_id=args[1]
            elseif sql:find("SET status = 'storing'",1,true) then
                assert(garageState.status=='out') garageState.status='storing'
            elseif sql:find("SET status = 'stored'",1,true) then
                assert(garageState.status=='storing') garageState.status='stored' garageState.session_token=nil garageState.net_id=nil
            else error('Unhandled garage state update: '..sql) end
            return 1
        end}
    """)
    checkout = h.action("garages:withdraw", {"garage": garage.id, "plate": "TEST123"}, advance=4)
    accepted(checkout)
    assert checkout.properties.model == h.g.garageModel
    assert checkout.properties.plate == "TEST123"
    assert h.g.garageState.status == "out"
    rejected(h.action("garages:withdraw", {"garage": garage.id, "plate": "TEST123"}, advance=4), "already")
    entity = h.mock.entities[checkout.netId]
    entity.driver = 1
    h.player().vehicle = checkout.netId
    entity.model = h.g.garageModel + 1
    rejected(h.action("garages:store", {"garage": garage.id, "netId": checkout.netId}), "model")
    assert h.g.garageState.status == "out" and h.mock.entities[checkout.netId] is not None
    entity.model = h.g.garageModel
    entity.state.eggGarageSession = "forged-session"
    rejected(h.action("garages:store", {"garage": garage.id, "netId": checkout.netId}, advance=3), "checked out")
    entity.state.eggGarageSession = h.g.garageState.session_token
    accepted(h.action("garages:store", {"garage": garage.id, "netId": checkout.netId,
        "properties": {"model": 999, "plate": "OTHER", "color1": -1, "color2": 50}}, advance=3))
    assert h.g.garageState.status == "stored"
    assert h.mock.entities[checkout.netId] is None
    assert h.mock.lastJson.model == h.g.garageModel
    assert h.mock.lastJson.plate == "TEST123"
    assert h.mock.lastJson.color1 == 5 and h.mock.lastJson.color2 == 50
    rejected(h.action("garages:store", {"garage": garage.id, "netId": checkout.netId}, advance=3), "driving")


@check("Quality dice are server rolled, bounded, throttled and local to routing bucket")
def quality_roll():
    h = Harness("egg_quality")
    h.execute("Mock.commands.roll.fn(1,{'-20'}); assert(#Mock.clients==1 and Mock.clients[1].name=='egg_core:notify'); Mock.clients={}; Mock.buckets[2]=2; Mock.commands.roll.fn(1,{'20'})")
    events = list(h.mock.clients.items())
    assert len(events) == 1
    event = events[0][1]
    assert event.source == 1 and event.name == "egg_quality:roll"
    assert 1 <= event.args[2] <= 20
    assert event.args[3] == 20
    h.execute("Mock.commands.roll.fn(1,{'20'})")
    assert len(list(h.mock.clients.items())) == 1


@check("Quality AFK sample warns, resets on movement, and honors staff exemptions")
def quality_afk():
    h = Harness("egg_quality")
    cfg = h.envs["egg_quality"].Config
    h.player(2).group = "admin"
    h.execute("Mock.threadMode=true; afkCoroutine=coroutine.create(Mock.threads[#Mock.threads].fn); assert(coroutine.resume(afkCoroutine)); assert(coroutine.resume(afkCoroutine))")
    h.mock.advance(cfg.Afk.warningMinutes * 60 + 1)
    h.execute("assert(coroutine.resume(afkCoroutine))")
    assert h.mock.players[1] is not None and h.mock.players[2] is not None
    assert any(e.name == "egg_core:notify" and e.source == 1 for _, e in h.mock.clients.items())
    h.move(h.table({"x": 3, "y": 0, "z": 0}))
    h.mock.advance(1)
    h.execute("assert(coroutine.resume(afkCoroutine))")
    h.mock.advance(cfg.Afk.kickMinutes * 60 - 1)
    h.execute("assert(coroutine.resume(afkCoroutine))")
    assert h.mock.players[1] is not None
    h.mock.advance(2)
    h.execute("assert(coroutine.resume(afkCoroutine))")
    assert h.mock.players[1] is None
    assert h.mock.players[2] is not None


@check("City market listings escrow actual inventory and refund transaction failure")
def city_market_escrow():
    h = Harness("egg_city")
    h.move(h.envs["egg_city"].Config.Hub)
    rejected(h.action("city.market.list", {"item": "bread", "quantity": 3, "price": 100, "kind": "fixed"}), "quantity")
    h.player().inventory.bread = 3
    h.rule("transaction", "", False)
    rejected(h.action("city.market.list", {"item": "bread", "quantity": 3, "price": 100, "kind": "fixed"}), "returned")
    assert h.player().inventory.bread == 3
    h.execute("Mock.rules={}")
    accepted(h.action("city.market.list", {"item": "bread", "quantity": 3, "price": 100, "kind": "fixed"}))
    assert h.player().inventory.bread == 0
    rejected(h.action("city.market.list", {"item": "bread", "quantity": 3, "price": 100, "kind": "fixed"}), "quantity")


@check("City parcels enforce owner and consume once; capacity failures restore claim")
def city_parcels():
    h = Harness("egg_city")
    h.move(h.envs["egg_city"].Config.Hub)
    h.execute("""
        parcel={id=9,identifier='license:player1',item='bread',quantity=2,claimed=0}
        Mock.rules[#Mock.rules+1]={kind='single',pattern='FROM egg_city_claims',fn=function(args)
            if args[1]==parcel.id and args[2]==parcel.identifier and parcel.claimed==0 then return parcel end
        end}
        Mock.rules[#Mock.rules+1]={kind='update',pattern='UPDATE egg_city_claims',fn=function(args,sql)
            if sql:find('claimed = 1',1,true) then
                if parcel.claimed~=0 then return 0 end parcel.claimed=1 return 1
            else parcel.claimed=0 return 1 end
        end}
    """)
    h.move(h.envs["egg_city"].Config.Hub, source=2)
    rejected(h.action("city.collect.item", {"id": 9}, source=2), "belongs")
    h.player().carry = False
    rejected(h.action("city.collect.item", {"id": 9}), "space")
    assert h.g.parcel.claimed == 0
    h.player().carry = True
    accepted(h.action("city.collect.item", {"id": 9}))
    assert h.player().inventory.bread == 2 and h.g.parcel.claimed == 1
    rejected(h.action("city.collect.item", {"id": 9}), "collected")
    assert h.player().inventory.bread == 2


@check("Drugs production requires provenance, server duration, and single-use completion")
def drugs_production():
    h = Harness("egg_drugs")
    cfg = h.envs["egg_drugs"].Config
    station = next(s for _, s in cfg.Stations.items() if s.id == "trim")
    h.move(station)
    h.player().inventory.egg_weed_crop = 3
    rejected(h.action("drugs:begin", {"station": "trim", "recipe": "trim", "quality": 100}), "lot")
    h.rule("query", "FROM egg_drugs_lots", [{"id": 1, "quantity": 3, "quality": 70}])
    start = h.action("drugs:begin", {"station": "trim", "recipe": "trim", "duration": 0})
    accepted(start)
    assert start.duration == 20
    rejected(h.action("drugs:finish", {"token": "forged"}), "ended")
    rejected(h.action("drugs:finish", {"token": start.token}), "running")
    accepted(h.action("drugs:finish", {"token": start.token}, advance=25))
    assert h.player().inventory.egg_weed_crop == 0
    assert h.player().inventory.egg_weed_trim == 2
    xp = h.core("GetSkill", 1, "cultivation").xp
    assert xp > 0
    rejected(h.action("drugs:finish", {"token": start.token}), "ended")
    assert h.player().inventory.egg_weed_trim == 2
    assert h.core("GetSkill", 1, "cultivation").xp == xp


@check("Drugs production restores stock and skips XP on ledger transaction failure")
def drugs_rollback():
    h = Harness("egg_drugs")
    cfg = h.envs["egg_drugs"].Config
    h.move(next(s for _, s in cfg.Stations.items() if s.id == "trim"))
    h.player().inventory.egg_weed_crop = 3
    h.rule("query", "FROM egg_drugs_lots", [{"id": 1, "quantity": 3, "quality": 70}])
    h.rule("transaction", "", False)
    start = h.action("drugs:begin", {"station": "trim", "recipe": "trim"})
    accepted(start)
    rejected(h.action("drugs:finish", {"token": start.token}, advance=25), "saved")
    assert h.player().inventory.egg_weed_crop == 3
    assert (h.player().inventory.egg_weed_trim or 0) == 0
    assert h.core("GetSkill", 1, "cultivation").xp == 0


@check("Drugs contracts require server travel time, location, price and single payout")
def drugs_contracts():
    h = Harness("egg_drugs")
    cfg = h.envs["egg_drugs"].Config
    drop = cfg.Drops[1]
    h.player().inventory.egg_weed_pack = 3
    h.rule("query", "FROM egg_drugs_lots", [{"id": 1, "quantity": 3, "quality": 80}])
    h.execute("""
        contract={identifier='license:player1',status='active',item='egg_weed_pack',quantity=3,drop_id='vespucci',
            quality_quote=80,base_price=360,min_complete_at=Mock.now+45,expires_at=Mock.now+600,next_available=0}
        Mock.rules[#Mock.rules+1]={kind='single',pattern='FROM egg_drugs_contracts',value=contract}
        Mock.rules[#Mock.rules+1]={kind='transaction',pattern='',fn=function(queries)
            for _,q in ipairs(queries) do if q.query:find("status = 'completed'",1,true) then contract.status='completed' end end
            return true
        end}
    """)
    h.move(drop)
    rejected(h.action("drugs:deliver", {"amount": 999999}), "ready")
    h.move(h.table({"x": 0, "y": 0, "z": 0}))
    rejected(h.action("drugs:deliver", advance=50), "address")
    h.move(drop)
    cash = h.player().money
    accepted(h.action("drugs:deliver", {"amount": 999999}))
    expected = int(360 * 3 * (0.75 + 80 / 200))
    assert h.player().money == cash + expected
    assert h.player().inventory.egg_weed_pack == 0
    rejected(h.action("drugs:deliver"), "active")
    assert h.player().money == cash + expected


@check("Drugs handoff cannot move stock to a reused target source during ledger query")
def drugs_handoff_reuse():
    h = Harness("egg_drugs")
    h.player().inventory.egg_weed_pack = 3
    h.execute("""
        Mock.rules[#Mock.rules+1]={kind='query',pattern='FROM egg_drugs_lots',fn=function()
            Mock.addPlayer(2).identifier='license:replacement-target'
            return {{id=1,quantity=3,quality=70}}
        end}
    """)
    rejected(h.action("drugs:handoff", {"target": 2, "stock": "green", "count": 1}), "player")
    assert h.player().inventory.egg_weed_pack == 3
    assert (h.player(2).inventory.egg_weed_pack or 0) == 0


@check("Drug laboratory requires actual lease and owned interior bucket through completion")
def drugs_laboratory():
    h = Harness("egg_drugs")
    cfg = h.envs["egg_drugs"].Config
    exterior = next(s for _, s in cfg.Stations.items() if s.id == "city_lab")
    bench = next(s for _, s in cfg.Interior.stations.items() if s.id == "cocaine_cut")
    rejected(h.action("drugs:enterLab", {"station": exterior.id, "lease": True}), "door")
    h.move(exterior)
    rejected(h.action("drugs:enterLab", {"station": exterior.id, "lease": True}), "rent")
    h.move(bench)
    rejected(h.action("drugs:begin", {"station": bench.id, "recipe": "cocaine_cut"}), "walk")
    h.rule("scalar", "FROM egg_drugs_leases", h.mock.now + 3600)
    h.mock.buckets[1] = 7
    h.move(exterior)
    accepted(h.action("drugs:enterLab", {"station": exterior.id}))
    assert h.mock.buckets[1] == cfg.LabBucketBase + 1
    assert abs(h.mock.positions[1].x - cfg.Interior.entry.x) < 0.01
    h.move(bench)
    h.player().inventory.egg_coca_crate = 1
    h.mock.skills["license:player1:contraband"] = 400
    h.mock.buckets[1] = 99
    rejected(h.action("drugs:begin", {"station": bench.id, "recipe": "cocaine_cut"}), "walk")
    h.mock.buckets[1] = cfg.LabBucketBase + 1
    start = h.action("drugs:begin", {"station": bench.id, "recipe": "cocaine_cut"})
    accepted(start)
    assert start.duration == 30
    h.execute("Mock.rules={}")
    rejected(h.action("drugs:finish", {"token": start.token}, advance=40), "rental")
    assert h.player().inventory.egg_coca_crate == 1
    assert (h.player().inventory.egg_cocaine_batch or 0) == 0
    assert h.core("GetSkill", 1, "contraband").xp == 400
    h.move(cfg.Interior.exit)
    accepted(h.action("drugs:exitLab"))
    assert h.mock.buckets[1] == 7
    assert abs(h.mock.positions[1].x - exterior.x) < 0.01
    rejected(h.action("drugs:exitLab"), "workshop")


@check("CFX callable-table references are accepted while plain tables are rejected")
def callable_reference_contract():
    h = Harness()
    h.execute("""
      local ref=Mock.marshal(function() return 7 end,'egg_core')
      assert(type(ref)=='table' and ref()==7)
      assert(not pcall(function() Mock.exports.egg_core.RegisterAction('bad.ref',{}, {}) end))
      Mock.current='test.resource'
      exports.egg_core:RegisterAction('test.ref',{},function() return {ok=true,value=7} end)
    """)
    assert h.action("test.ref").value == 7


@check("Dispatch ignores invented locations and uses the same postal directory as GPS")
def dispatch_authoritative_location():
    h = Harness("egg_work", "egg_dispatch")
    h.move(h.table({"x": 215.76, "y": -810.12, "z": 30.73}))
    result = h.action("dispatch:create", {"service": "police", "message": "Someone needs help at the square.", "x": 9999, "postcode": "FAKE"})
    assert result.ok
    h.execute("""
      local found=false
      for _,call in ipairs(Mock.calls) do
        if type(call.sql)=='string' and call.sql:find('INSERT INTO egg_dispatch_calls',1,true) then
          assert(call.args[5]=='101' and call.args[6]==215.76 and call.args[7]==-810.12)
          found=true
        end
      end
      assert(found)
    """)


@check("Dispatch service scope rejects civilians and cross-service acceptance")
def dispatch_permissions():
    h = Harness("egg_dispatch")
    assert not h.action("dispatch:queue").ok
    assert not h.action("dispatch:history").ok
    h.player().job = h.table({"name": "police", "grade": 3})
    h.rule("single", "SELECT * FROM egg_dispatch_calls", {"id": 9, "service": "ambulance", "status": "open"})
    assert not h.action("dispatch:accept", {"id": 9}).ok


@check("Fingerprint request cannot reach a replacement character after the UUID query")
def fingerprint_target_reuse():
    h = Harness("egg_police")
    h.player().job = h.table({"name": "police", "grade": 3})
    h.rule("scalar", "SELECT 1 FROM egg_police_certifications", 1)
    h.execute("""
      Mock.addRule('scalar','SELECT UUID()',nil)
      Mock.rules[#Mock.rules].fn=function()
        Mock.fire('playerDropped',2)
        Mock.players[2]=nil
        Mock.addPlayer(2).identifier='license:new-character'
        return 'fingerprint-race'
      end
    """)
    assert not h.action("police:fingerprintRequest", {"target": 2}).ok
    h.execute("for _,event in ipairs(Mock.clients) do assert(event.name~='egg_police:fingerprintRequest') end")


@check("Housing persists a return route and recovers a reconnect from its interior")
def housing_reconnect():
    h = Harness("egg_city")
    room = h.envs["egg_city"].Config.Rooms[1]
    owner = h.player().identifier
    h.move(room.door)
    h.rule("single", "SELECT owner, expires_at FROM egg_city_rooms", {"owner": owner, "expires_at": 0})
    assert h.action("city.room.enter", {"id": room.id}).ok
    assert h.mock.buckets[1] == room.bucket
    h.rule("single", "SELECT room_id, previous_bucket FROM egg_city_room_returns", {"room_id": room.id, "previous_bucket": 0})
    h.mock.fire("playerDropped", 1)
    h.move(room.inside)
    h.mock.fire("esx:playerLoaded", 0, 1)
    h.execute("Mock.threads[#Mock.threads].fn()")
    assert h.mock.buckets[1] == 0
    assert h.mock.positions[1].x == room.door.x
    assert h.mock.positions[1].y == room.door.y


@check("Spawn preview cannot run economy actions until its one-use selection is finished")
def spawn_modal_gate():
    h = Harness("egg_spawn")
    h.envs["egg_spawn"].Config.Enabled = True
    h.in_resource("egg_spawn", "EggCore:RegisterAction('test.modal.money',{},function(source) return {ok=EggCore:Credit(source,1,'bank')} end)")
    h.mock.fire("esx:playerLoaded", 0, 1)
    ready = h.action("spawn.ready")
    assert ready.ok
    initial = h.player().accounts.bank.money
    assert not h.action("test.modal.money").ok
    assert h.player().accounts.bank.money == initial
    assert h.action("spawn.confirm", {"token": ready.token, "id": "alta"}).ok
    assert h.action("test.modal.money").ok
    assert h.player().accounts.bank.money == initial + 1


def main():
    failures = []
    for name, fn in CHECKS:
        try:
            fn()
            print(f"PASS {name}")
        except Exception as error:
            failures.append((name, error))
            print(f"FAIL {name}: {error}", file=sys.stderr)
    print(f"\n{len(CHECKS) - len(failures)}/{len(CHECKS)} checks passed; mocked runtime, not a live FXServer test.")
    if failures:
        sys.exit(1)


if __name__ == "__main__":
    main()
