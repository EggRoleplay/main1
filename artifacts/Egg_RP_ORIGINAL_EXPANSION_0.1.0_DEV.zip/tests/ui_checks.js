'use strict';
// npm install --prefix /tmp/egg-spawn-dom jsdom@26.0.0
// NODE_PATH=/tmp/egg-spawn-dom/node_modules node tests/ui_checks.js
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');
const root = path.resolve(__dirname, '../resources/[egg]');
function load(name) {
  const directory = path.join(root, name, 'web');
  const dom = new JSDOM(fs.readFileSync(path.join(directory, 'index.html'), 'utf8'), { runScripts: 'outside-only' });
  return { dom, window: dom.window, directory, send: data => dom.window.dispatchEvent(new dom.window.MessageEvent('message', { data })) };
}
const hud = load('egg_hud');
let frame;
hud.window.requestAnimationFrame = fn => { frame = fn; return 1; };
hud.window.cancelAnimationFrame = () => { frame = null; };
hud.window.eval(fs.readFileSync(path.join(hud.directory, 'app.js'), 'utf8'));
hud.send({ action: 'state', visible: true, showStatus: true, showLocation: true, compass: true, heading: 90,
  showVehicle: true, vehicle: true, health: 75, armour: 0, hunger: -4, thirst: 400, stamina: 50,
  road: '<img src=x onerror=alert(1)>', area: 'City', postal: { code: '101', distance: 12 }, speed: 38, fuel: 50, engine: 80, gear: 2, beltEnabled: true });
assert.equal(hud.window.document.getElementById('hud').hidden, false);
assert.equal(hud.window.document.querySelector('[data-stat="hunger"] span').textContent, '0');
assert.equal(hud.window.document.querySelector('[data-stat="thirst"] span').textContent, '100');
assert.equal(hud.window.document.querySelector('[data-stat="armour"]').hidden, true);
assert.equal(hud.window.document.getElementById('road').textContent, '<img src=x onerror=alert(1)>');
assert.equal(hud.window.document.querySelector('img'), null);
assert.equal(hud.window.document.getElementById('compass-heading').textContent, 'W');
assert.equal(hud.window.document.getElementById('speed').textContent, '38');
assert(hud.window.document.getElementById('postal-code').textContent.includes('101'));
hud.send({ action: 'progress', label: 'Cutting cocaine…', duration: 1000 });
assert.equal(hud.window.document.getElementById('progress').hidden, false);
frame(hud.window.performance.now() + 500);
assert(Number.parseFloat(hud.window.document.getElementById('progress-fill').style.width) >= 50);
hud.send({ action: 'progressStop' });
assert.equal(hud.window.document.getElementById('progress').hidden, true);
hud.send({ action: 'state', visible: false });
assert.equal(hud.window.document.getElementById('hud').hidden, true);

const menu = load('egg_menu');
menu.window.eval(fs.readFileSync(path.join(menu.directory, 'app.js'), 'utf8'));
menu.send({ action: 'open', title: 'Business bank', index: 2, limit: 3,
  rows: [{ label: 'Deposit', selected: false }, { label: '<svg onload=alert(1)>', selected: true, slider: true, value: 0 }, { label: 'Unavailable', disabled: true }] });
assert.equal(menu.window.document.getElementById('menu').hidden, false);
assert.equal(menu.window.document.querySelector('.selected').textContent, '<svg onload=alert(1)>‹ 0 ›');
assert.equal(menu.window.document.querySelector('svg'), null);
assert.equal(menu.window.document.getElementById('counter').textContent, '2 / 3');
assert.equal(menu.window.document.querySelector('.disabled').textContent, 'Unavailable');
menu.send({ action: 'close' });
assert.equal(menu.window.document.getElementById('menu').hidden, true);
console.log('HUD/menu DOM checks passed: state bounds, safe text, visibility, compass, postal, progress/cancel and row rendering.');
