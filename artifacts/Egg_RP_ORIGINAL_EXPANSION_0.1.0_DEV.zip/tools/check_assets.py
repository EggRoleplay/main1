#!/usr/bin/env python3
"""Check packaged manifest assets, unique commands, item registry and JS syntax."""
from collections import defaultdict
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
RESOURCES = ROOT / 'resources' / '[egg]'

def main():
    errors, commands, item_names = [], defaultdict(list), set()
    resources = sorted(path for path in RESOURCES.iterdir() if path.is_dir())
    for directory in resources:
        manifest = directory / 'fxmanifest.lua'
        if not manifest.is_file():
            errors.append(f'Missing manifest: {directory.name}')
            continue
        source = manifest.read_text()
        for match in re.finditer(r'(?m)^\s*(?:shared_scripts?|client_scripts?|server_scripts?|ui_page|files)\s+(\{[^}]*\}|[^\n]+)', source):
            for name in re.findall(r"['\"]([^'\"]+)['\"]", match.group(1)):
                if name.startswith('@'):
                    dependency, relative = name[1:].split('/', 1)
                    if dependency.startswith('egg_') and not (RESOURCES / dependency / relative).is_file():
                        errors.append(f'{directory.name}: missing {name}')
                    continue
                if not list(directory.glob(name)):
                    errors.append(f'{directory.name}: missing {name}')
        for path in directory.rglob('*.lua'):
            source = path.read_text()
            for name in re.findall(r"RegisterCommand\(['\"]([^'\"]+)", source):
                commands[name].append(path.relative_to(ROOT))
            # Resource names also use egg_; only names registered below are item requirements.
            item_names.update(re.findall(r"['\"](egg_[a-z_]+)['\"]", source))
    for name, paths in commands.items():
        if len(paths) > 1:
            errors.append(f'Repeated command {name}: {paths}')
    item_sql = (ROOT / 'sql' / '10_items.sql').read_text()
    registered = re.findall(r"\('([^']+)',", item_sql)
    if len(registered) != len(set(registered)):
        errors.append('Duplicate item registry rows')
    required_items = {'egg_' + suffix for suffix in (
        'fishing_rod bait bream flathead snapper tuna recyclables scrap plastic copper steel timber mushroom gps lockpick toolkit '
        'blueprint_rod blueprint_lockpick blueprint_toolkit stolen_mail stolen_goods weed_seed grow_crate packaging lab_crate '
        'weed_crop weed_trim weed_pack lab_batch lab_pack coca_crate cocaine_batch cocaine_bag').split()}
    if set(registered) != required_items:
        errors.append(f'Item registry mismatch: {set(registered) ^ required_items}')
    for path in RESOURCES.rglob('*.js'):
        result = subprocess.run(['node', '--check', str(path)], capture_output=True, text=True)
        if result.returncode:
            errors.append(f'{path.relative_to(ROOT)}: {result.stderr}')
    if errors:
        raise SystemExit('\n'.join(errors))
    print(f'Asset checks passed: {len(resources)} resources, {len(commands)} unique commands, {len(registered)} unique items, all JS syntax.')

if __name__ == '__main__':
    main()
