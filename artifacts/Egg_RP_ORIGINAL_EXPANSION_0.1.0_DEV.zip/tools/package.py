#!/usr/bin/env python3
"""Package original source only. Never includes an existing server or credentials."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "artifacts" / "Egg_RP_ORIGINAL_EXPANSION_0.1.0_DEV.zip"
INPUTS = [ROOT / "README.md", ROOT / "egg.cfg"]
for directory in ("resources", "sql", "docs", "tests", "tools"):
    INPUTS.extend(p for p in (ROOT / directory).rglob("*") if p.is_file() and "__pycache__" not in p.parts)

def package():
    OUTPUT.parent.mkdir(exist_ok=True)
    files = sorted(set(INPUTS))
    manifest = {}
    with zipfile.ZipFile(OUTPUT, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in files:
            if path.is_symlink() or not path.resolve().is_relative_to(ROOT):
                raise ValueError(f"Refusing external/symlink input: {path.name}")
            name = path.relative_to(ROOT).as_posix()
            content = path.read_bytes()
            manifest[name] = hashlib.sha256(content).hexdigest()
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, content)
        archive.writestr("SHA256_MANIFEST.json", json.dumps(manifest, indent=2, sort_keys=True))
    with zipfile.ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None, "Archive integrity check failed"
        for name, digest in manifest.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name
    print(f"Packaged {len(files)} files · {OUTPUT.stat().st_size:,} bytes · {OUTPUT}")

if __name__ == "__main__":
    package()
