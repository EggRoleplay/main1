local ESX = exports['es_extended']:getSharedObject()
local activeRoom, cachedStatus = nil, nil
local keyboardActive = false
local openHub, openHousing, openJobs, openBusiness, openMarketplace

local function safe(value)
    return tostring(value or ''):gsub('&', '&amp;'):gsub('<', '&lt;'):gsub('>', '&gt;')
end
local function money(amount) return '$' .. tostring(math.floor(tonumber(amount) or 0)) end
local function itemName(item) return Config.ItemLabels[item] or tostring(item):gsub('^egg_', ''):gsub('_', ' ') end
local function notice(text) ESX.ShowNotification(text) end
local function action(name, payload, callback)
    exports.egg_core:Action(name, payload or {}, function(result)
        if not result or not result.ok then notice(result and result.error or 'The counter is unavailable.'); return end
        if result.message then notice(result.message) end
        if callback then callback(result) end
    end)
end
local function run(name, payload, refresh)
    ESX.UI.Menu.CloseAll()
    action(name, payload, function() if refresh then SetTimeout(1400, refresh) end end)
end
local function menu(id, title, elements, choose, back)
    ESX.UI.Menu.CloseAll()
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), id, {
        title = title, align = 'top-left', elements = elements
    }, function(data, handle) choose(data.current, handle) end,
    function(_, handle) handle.close(); if back then back() end end)
end
local function input(label, limit)
    ESX.UI.Menu.CloseAll()
    keyboardActive = true
    AddTextEntry('EGG_CITY_INPUT', label)
    DisplayOnscreenKeyboard(1, 'EGG_CITY_INPUT', '', '', '', '', '', limit or 80)
    while UpdateOnscreenKeyboard() == 0 do Wait(0) end
    keyboardActive = false
    if UpdateOnscreenKeyboard() ~= 1 then return nil end
    local result = GetOnscreenKeyboardResult()
    if not result or result == '' then return nil end
    return result
end
local function number(label, minimum, maximum)
    local value = tonumber(input(label, 12))
    if not value then return nil end
    if value % 1 ~= 0 or value < minimum or value > maximum then notice('Enter a whole number between ' .. minimum .. ' and ' .. maximum .. '.'); return nil end
    return value
end
local function teleport(position)
    DoScreenFadeOut(180)
    Wait(200)
    local ped = PlayerPedId()
    SetEntityCoords(ped, position.x, position.y, position.z, false, false, false, false)
    if position.heading then SetEntityHeading(ped, position.heading) end
    Wait(100)
    DoScreenFadeIn(180)
end
local function roomRow(id)
    for _, row in ipairs(cachedStatus and cachedStatus.rooms or {}) do if row.room_id == id then return row end end
end
local function businessRow(id)
    for _, row in ipairs(cachedStatus and cachedStatus.businesses or {}) do if row.business_id == id then return row end end
end
local function loadStatus(callback) action('city.status', {}, function(result) cachedStatus = result; callback() end) end

openHousing = function()
    local elements = {}
    for _, room in ipairs(Config.Rooms) do
        local row = roomRow(room.id)
        local occupied = row and (row.expires_at == 0 or row.expires_at > cachedStatus.now)
        local status = occupied and (row.owned and 'Your room' or 'Occupied') or 'Available'
        elements[#elements + 1] = { label = safe(room.name) .. ' · ' .. status .. ' · ' .. money(room.price) .. (room.rent and '/7 days' or ''), room = room }
    end
    menu('housing', 'Homes & short stays', elements, function(entry)
        local room, row = entry.room, roomRow(entry.room.id)
        local options = { { label = 'Mark entrance on GPS', value = 'gps' } }
        if not row or row.expires_at ~= 0 and row.expires_at <= cachedStatus.now or row.owned and room.rent then
            options[#options + 1] = { label = (row and row.owned and 'Renew tenancy' or room.rent and 'Book seven days' or 'Purchase home') .. ' · ' .. money(room.price), value = 'buy' }
        end
        menu('room', room.name, options, function(choice)
            if choice.value == 'gps' then SetNewWaypoint(room.door.x, room.door.y); notice('The entrance is on your GPS.'); return end
            run('city.room.buy', { id = room.id }, openHub)
        end, openHousing)
    end, openHub)
end

local function employmentForm(remove)
    local target = number('Employee server ID', 1, 65535); if not target then return end
    local job = input('ESX job name (example: police)', 48); if not job then return end
    if remove then run('city.job.revoke', { target = target, job = job }, openHub); return end
    local grade = number('Approved job grade', 0, 50); if not grade then return end
    run('city.job.hire', { target = target, job = job, grade = grade }, openHub)
end
openJobs = function()
    action('city.jobs', {}, function(result)
        local elements = {}
        for _, job in ipairs(result.jobs) do elements[#elements + 1] = { label = safe(Config.JobLabels[job.job_name] or job.job_name) .. ' · Grade ' .. job.grade, value = job.job_name } end
        elements[#elements + 1] = { label = 'Employer desk · hire or update a role', value = 'hire' }
        elements[#elements + 1] = { label = 'Employer desk · end employment', value = 'revoke' }
        menu('jobs', 'Employment desk', elements, function(entry)
            if entry.value == 'hire' or entry.value == 'revoke' then employmentForm(entry.value == 'revoke'); return end
            run('city.job.switch', { job = entry.value }, openHub)
        end, openHub)
    end)
end

local function businessManagement(business)
    local row, elements = businessRow(business.id), {}
    if not row then
        elements[#elements + 1] = { label = 'Purchase business lease · ' .. money(business.price), value = 'buy' }
    elseif row.owned then
        elements = {
            { label = 'Bank · ' .. money(row.balance), value = 'bank' },
            { label = 'Hire or update employee commission', value = 'employee' },
            { label = 'Remove employee', value = 'remove' },
            { label = 'Post community notice · ' .. money(Config.AdvertPrice), value = 'advert' }
        }
    end
    elements[#elements + 1] = { label = 'Mark shop on GPS', value = 'gps' }
    menu('business', business.name, elements, function(entry)
        if entry.value == 'gps' then SetNewWaypoint(business.location.x, business.location.y); notice('The shop is on your GPS.'); return end
        if entry.value == 'buy' then run('city.business.buy', { id = business.id }, openHub); return end
        if entry.value == 'bank' then
            menu('business_bank', business.name .. ' · Bank', { { label = 'Deposit from your bank', value = 'deposit' }, { label = 'Withdraw to your bank', value = 'withdraw' } }, function(choice)
                local amount = number('Amount in dollars', 1, Config.MaxPrice); if not amount then return end
                run('city.business.bank', { id = business.id, amount = amount, direction = choice.value }, openHub)
            end, function() businessManagement(business) end)
        elseif entry.value == 'employee' or entry.value == 'remove' then
            local target = number('Employee server ID · they must be here', 1, 65535); if not target then return end
            local rate = 0
            if entry.value ~= 'remove' then rate = number('Commission percent (0–' .. Config.MaxCommission .. ')', 0, Config.MaxCommission); if not rate then return end end
            run('city.business.employee', { id = business.id, target = target, commission = rate, remove = entry.value == 'remove' }, openHub)
        elseif entry.value == 'advert' then
            local text = input('Community board notice · 4–180 characters', Config.AdvertMaxLength); if not text then return end
            run('city.business.advert', { id = business.id, text = text }, openHub)
        end
    end, openBusiness)
end
openBusiness = function()
    local elements = {}
    for _, business in ipairs(Config.Businesses) do
        local row = businessRow(business.id)
        elements[#elements + 1] = { label = safe(business.name) .. ' · ' .. (row and (row.owned and 'Your business' or 'Locally owned') or 'Lease available'), business = business }
    end
    menu('business_hub', 'Local business hub', elements, function(entry) businessManagement(entry.business) end, openHub)
end

local function newListing()
    local elements = {}
    for item in pairs(Config.MarketItems) do elements[#elements + 1] = { label = safe(itemName(item)), item = item } end
    table.sort(elements, function(a, b) return a.item < b.item end)
    menu('list_item', 'What are you selling?', elements, function(entry)
        local item = entry.item
        menu('listing_kind', 'Choose sale type', { { label = 'Fixed price · seven-day listing', value = 'fixed' }, { label = 'Auction · paid bids held in escrow', value = 'auction' } }, function(choice)
            local quantity = number('How many? (1–' .. Config.MaxItemCount .. ')', 1, Config.MaxItemCount); if not quantity then return end
            local price = number(choice.value == 'fixed' and 'Total bundle price in dollars' or 'Starting bid for the whole bundle', 1, Config.MaxPrice); if not price then return end
            local hours = 0
            if choice.value == 'auction' then
                hours = number('Auction duration: 1, 6 or 24 hours', 1, 24)
                if not hours then return end
                if not Config.AuctionHours[hours] then notice('Choose 1, 6 or 24 hours.'); return end
            end
            run('city.market.list', { item = item, quantity = quantity, price = price, kind = choice.value, hours = hours }, openMarketplace)
        end, newListing)
    end, openMarketplace)
end
openMarketplace = function()
    action('city.market', {}, function(result)
        local elements = { { label = 'Create a listing', value = 'new' } }
        for _, listing in ipairs(result.listings) do
            local amount = listing.kind == 'auction' and math.max(listing.price, listing.bid) or listing.price
            local remaining = math.max(1, math.ceil((listing.expires_at - result.now) / 60))
            elements[#elements + 1] = { label = '#' .. listing.id .. ' · ' .. listing.quantity .. '× ' .. safe(itemName(listing.item)) .. ' · ' .. money(amount) .. (listing.kind == 'auction' and ' · Auction · ' .. remaining .. ' min left' or ''), listing = listing }
        end
        menu('market', 'Community marketplace', elements, function(entry)
            if entry.value == 'new' then newListing(); return end
            local listing = entry.listing
            if listing.owned then
                menu('own_listing', 'Your listing #' .. listing.id, { { label = 'Cancel and recover the parcel · no bids only', value = 'cancel' } }, function()
                    run('city.market.cancel', { id = listing.id }, openMarketplace)
                end, openMarketplace)
            elseif listing.kind == 'fixed' then
                menu('buy_listing', listing.quantity .. '× ' .. safe(itemName(listing.item)), { { label = 'Purchase bundle · ' .. money(listing.price), value = 'buy' } }, function()
                    run('city.market.buy', { id = listing.id }, openHub)
                end, openMarketplace)
            else
                local amount = number('Your total bid · current ' .. money(listing.bid) .. ' · reserve ' .. money(listing.price), 1, Config.MaxPrice)
                if not amount then return end
                run('city.market.bid', { id = listing.id, amount = amount }, openMarketplace)
            end
        end, openHub)
    end)
end

local function notices()
    local elements = {}
    for _, advert in ipairs(cachedStatus.adverts or {}) do
        local name = advert.business_id
        for _, business in ipairs(Config.Businesses) do if business.id == advert.business_id then name = business.name end end
        elements[#elements + 1] = { label = safe(name) .. ' · ' .. safe(advert.text:sub(1, 60)) .. (#advert.text > 60 and '…' or ''), text = name .. ': ' .. advert.text }
    end
    if #elements == 0 then elements[1] = { label = 'No notices today. Drop by again soon.' } end
    menu('notices', 'Around town', elements, function(entry) if entry.text then notice(entry.text) end end, openHub)
end
local function parcels()
    local elements = {}
    for _, claim in ipairs(cachedStatus.claims or {}) do elements[#elements + 1] = { label = claim.quantity .. '× ' .. safe(itemName(claim.item)), id = claim.id } end
    if #elements == 0 then notice('There are no parcels waiting.'); return end
    menu('parcels', 'Parcel collection', elements, function(entry) run('city.collect.item', { id = entry.id }, openHub) end, openHub)
end
openHub = function()
    loadStatus(function()
        menu('hub', 'Egg RP · Civic centre', {
            { label = 'Homes & short stays', value = 'housing' },
            { label = 'Employment desk', value = 'jobs' },
            { label = 'Local business hub', value = 'business' },
            { label = 'Community marketplace', value = 'market' },
            { label = 'Around town · community notices', value = 'notices' },
            { label = 'Collect payments · ' .. money(cachedStatus.payout), value = 'payments' },
            { label = 'Collect parcels · ' .. #cachedStatus.claims .. ' waiting', value = 'parcels' }
        }, function(entry)
            local handlers = { housing = openHousing, jobs = openJobs, business = openBusiness, market = openMarketplace, notices = notices, parcels = parcels }
            if handlers[entry.value] then handlers[entry.value](); return end
            if entry.value == 'payments' then run('city.collect.money', {}, openHub) end
        end)
    end)
end

local function doorstep(position)
    loadStatus(function()
        local elements = {}
        for _, room in ipairs(Config.Rooms) do
            if math.abs(room.door.x - position.x) < 0.1 and math.abs(room.door.y - position.y) < 0.1 then
                local row = roomRow(room.id)
                if row and row.owned and (row.expires_at == 0 or row.expires_at > cachedStatus.now) then elements[#elements + 1] = { label = safe(room.name) .. ' · Enter', room = room } end
            end
        end
        if #elements == 0 then notice('Arrange a tenancy at the civic centre.'); return end
        menu('doorstep', 'Your keys', elements, function(entry)
            ESX.UI.Menu.CloseAll()
            action('city.room.enter', { id = entry.room.id }, function(result) activeRoom = entry.room; teleport(result.position) end)
        end)
    end)
end
local function shop(business)
    local elements = {}
    for index, product in ipairs(business.products) do elements[#elements + 1] = { label = safe(product.label) .. ' · ' .. money(product.price), index = index } end
    menu('shop', business.name, elements, function(entry)
        menu('checkout', 'At the counter', { { label = 'Self-service purchase', value = 'self' }, { label = 'Served by a staff member', value = 'staff' } }, function(choice)
            local employee
            if choice.value == 'staff' then employee = number('Staff member server ID', 1, 65535); if not employee then return end end
            run('city.business.sale', { id = business.id, product = entry.index, employee = employee }, function() shop(business) end)
        end, function() shop(business) end)
    end)
end

local function mapBlip(position, name, style)
    local blip = AddBlipForCoord(position.x, position.y, position.z)
    SetBlipSprite(blip, style.sprite); SetBlipColour(blip, style.colour); SetBlipScale(blip, style.scale)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName('STRING'); AddTextComponentString(name); EndTextCommandSetBlipName(blip)
end

RegisterCommand('city', function()
    local coords = GetEntityCoords(PlayerPedId())
    if #(coords - vector3(Config.Hub.x, Config.Hub.y, Config.Hub.z)) > 4.0 then
        SetNewWaypoint(Config.Hub.x, Config.Hub.y); notice('The civic centre is marked on your GPS.'); return
    end
    openHub()
end, false)
RegisterNetEvent('egg_city:roomEnded', function(position) activeRoom = nil; ESX.UI.Menu.CloseAll(); teleport(position) end)

CreateThread(function()
    mapBlip(Config.Hub, 'Civic Centre', Config.Blips.civic)
    for _, business in ipairs(Config.Businesses) do if business.blip then mapBlip(business.location, business.name, business.blip) end end
    local buildings = {}
    for _, room in ipairs(Config.Rooms) do
        local key = room.door.x .. ':' .. room.door.y .. ':' .. room.door.z
        if not buildings[key] then
            mapBlip(room.door, room.building or room.name, room.rent and Config.Blips.motel or Config.Blips.apartment)
            buildings[key] = true
        end
    end
    while true do
        local delay, coords, nearest = 650, GetEntityCoords(PlayerPedId()), nil
        local points = {}
        if activeRoom then
            points[1] = { position = activeRoom.inside, text = 'Press ~INPUT_CONTEXT~ to leave your room.', action = function()
                action('city.room.leave', {}, function(result) activeRoom = nil; teleport(result.position) end)
            end }
        else
            points[#points + 1] = { position = Config.Hub, text = 'Press ~INPUT_CONTEXT~ for civic services.', action = openHub }
            local seen = {}
            for _, room in ipairs(Config.Rooms) do
                local key = room.door.x .. ':' .. room.door.y
                if not seen[key] then
                    local position = room.door
                    points[#points + 1] = { position = position, text = 'Press ~INPUT_CONTEXT~ to use your keys.', action = function() doorstep(position) end }
                    seen[key] = true
                end
            end
            for _, business in ipairs(Config.Businesses) do
                local current = business
                points[#points + 1] = { position = current.location, text = 'Press ~INPUT_CONTEXT~ to shop local.', action = function() shop(current) end }
            end
        end
        local distance = Config.InteractionDistance
        for _, point in ipairs(points) do
            local position = point.position
            local range = #(coords - vector3(position.x, position.y, position.z))
            if range < Config.MarkerDistance then
                delay = 0
                DrawMarker(2, position.x, position.y, position.z + 0.15, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0, 0.17, 0.17, 0.17, 221, 204, 149, 150, false, true, 2, false, nil, nil, false)
            end
            if range < distance then nearest, distance = point, range end
        end
        if nearest and not keyboardActive and #ESX.UI.Menu.GetOpenedMenus() == 0 and not IsPauseMenuActive() then
            ESX.ShowHelpNotification(nearest.text)
            if IsControlJustReleased(0, 38) then nearest.action(); Wait(250) end
        end
        Wait(delay)
    end
end)
