fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'egg_city'
description 'Egg RP civic services, homes, businesses and public trade'
author 'Egg Roleplay'
version '1.0.0'

dependencies { 'es_extended', 'oxmysql', 'egg_core', 'esx_menu_default' }
shared_script 'config.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', '@egg_core/server_api.lua', 'server.lua' }
client_script 'client.lua'
