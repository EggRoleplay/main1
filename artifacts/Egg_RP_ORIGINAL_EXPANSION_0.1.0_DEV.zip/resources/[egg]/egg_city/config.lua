Config = {}
Config.RoomBucketBase = 300000

Config.Hub = { x = -545.35, y = -204.07, z = 38.22 }
Config.Blips = {
    civic = { sprite = 419, colour = 4, scale = 0.72 },
    apartment = { sprite = 40, colour = 4, scale = 0.65 },
    motel = { sprite = 40, colour = 26, scale = 0.65 }
}
Config.MarkerDistance = 24.0
Config.InteractionDistance = 2.0
Config.MaxListings = 8
Config.MaxItemCount = 50
Config.MaxPrice = 1000000
Config.AuctionHours = { [1] = true, [6] = true, [24] = true }
Config.MarketItems = {
    bread = true, water = true,
    egg_fishing_rod = true, egg_bait = true,
    egg_bream = true, egg_flathead = true, egg_snapper = true, egg_tuna = true,
    egg_scrap = true, egg_copper = true, egg_plastic = true, egg_steel = true,
    egg_timber = true, egg_toolkit = true, egg_mushroom = true, egg_gps = true
}
Config.ItemLabels = {
    bread = 'Sandwich', water = 'Bottled water',
    egg_fishing_rod = 'Fishing rod', egg_bait = 'Bait',
    egg_bream = 'Bream', egg_flathead = 'Flathead', egg_snapper = 'Snapper', egg_tuna = 'Tuna',
    egg_scrap = 'Scrap metal', egg_copper = 'Copper', egg_plastic = 'Plastic', egg_steel = 'Steel bar',
    egg_timber = 'Timber offcuts', egg_toolkit = 'Vehicle toolkit', egg_mushroom = 'Mushrooms', egg_gps = 'Street directory'
}
Config.JobLabels = {
    unemployed = 'Between jobs', police = 'Victoria Police', ambulance = 'Ambulance Victoria',
    mechanic = 'Workshop', taxi = 'Taxi service'
}
Config.AdvertPrice = 250
Config.AdvertHours = 24
Config.AdvertMaxLength = 180
Config.MaxOwnedRooms = 2
Config.RentalDays = 7
Config.MaxBusinessOwners = 1
Config.MaxCommission = 15

-- Use interiors supplied by GTA. These coordinates require no paid map assets.
-- Each room receives its own routing bucket; a motel tenant renews before expiry.
Config.Rooms = {
    { id = 'alta_01', name = 'Alta Street · Apartment 1', building = 'Alta Street Apartments', price = 95000, rent = false,
      door = { x = -270.62, y = -957.33, z = 31.22 },
      inside = { x = 266.08, y = -1007.54, z = -101.01, heading = 355.0 } },
    { id = 'alta_02', name = 'Alta Street · Apartment 2', building = 'Alta Street Apartments', price = 95000, rent = false,
      door = { x = -270.62, y = -957.33, z = 31.22 },
      inside = { x = 266.08, y = -1007.54, z = -101.01, heading = 355.0 } },
    { id = 'pinkcage_01', name = 'Pink Cage · Room 1', building = 'Pink Cage Motel', price = 1800, rent = true,
      door = { x = 324.16, y = -229.14, z = 54.22 },
      inside = { x = 151.36, y = -1007.82, z = -99.0, heading = 0.0 } },
    { id = 'pinkcage_02', name = 'Pink Cage · Room 2', building = 'Pink Cage Motel', price = 1800, rent = true,
      door = { x = 324.16, y = -229.14, z = 54.22 },
      inside = { x = 151.36, y = -1007.82, z = -99.0, heading = 0.0 } },
    { id = 'pinkcage_03', name = 'Pink Cage · Room 3', building = 'Pink Cage Motel', price = 1800, rent = true,
      door = { x = 324.16, y = -229.14, z = 54.22 },
      inside = { x = 151.36, y = -1007.82, z = -99.0, heading = 0.0 } },
    { id = 'sandy_01', name = 'Sandy Shores · Room 1', building = 'Sandy Shores Motel', price = 950, rent = true,
      door = { x = 1142.25, y = 2664.18, z = 38.16 },
      inside = { x = 151.36, y = -1007.82, z = -99.0, heading = 0.0 } }
}

-- An employer may only grant configured grades below their own grade.
-- Staff can grant any existing grade at the civic centre.
Config.Hiring = {
    police = { minimumGrade = 4 }, ambulance = { minimumGrade = 3 },
    mechanic = { minimumGrade = 3 }, taxi = { minimumGrade = 3 }
}

Config.Businesses = {
    { id = 'pier_cafe', name = 'Egg Pier Café', price = 65000, commission = 8,
      location = { x = -1183.91, y = -884.94, z = 13.80 },
      blip = { sprite = 93, colour = 46, scale = 0.65 },
      products = { { item = 'bread', label = 'Fresh sandwich', price = 35 }, { item = 'water', label = 'Bottled water', price = 18 } } },
    { id = 'sandy_general', name = '7-Eleven · Sandy Shores', price = 45000, commission = 8,
      location = { x = 1961.39, y = 3740.77, z = 32.34 },
      blip = { sprite = 52, colour = 2, scale = 0.65 },
      products = { { item = 'bread', label = 'Lunch roll', price = 30 }, { item = 'water', label = 'Bottled water', price = 15 } } },
    { id = 'city_lunch', name = 'Strawberry Lunch Bar', price = 55000, commission = 8,
      location = { x = 25.75, y = -1347.43, z = 29.50 },
      blip = { sprite = 52, colour = 46, scale = 0.65 },
      products = { { item = 'bread', label = 'Toastie', price = 32 }, { item = 'water', label = 'Bottled water', price = 16 } } },
    { id = 'bunnings', name = 'Bunnings Warehouse', price = 85000, commission = 8,
      location = { x = 2744.74, y = 3473.10, z = 55.67 },
      blip = { sprite = 566, colour = 25, scale = 0.70 },
      products = {
          { item = 'egg_fishing_rod', label = 'Fishing rod', price = 220 },
          { item = 'egg_bait', label = 'Fishing bait', price = 8 },
          { item = 'egg_toolkit', label = 'Vehicle toolkit', price = 500 }
      } }
}
