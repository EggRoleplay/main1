local ESX = exports['es_extended']:getSharedObject()
local Core = EggCore
local occupants = {}
local leaveRoom
local rooms, businesses = {}, {}
for index, room in ipairs(Config.Rooms) do room.bucket = Config.RoomBucketBase + index; rooms[room.id] = room end
for _, business in ipairs(Config.Businesses) do businesses[business.id] = business end

local function ok(values) values = values or {}; values.ok = true; return values end
local function fail(message) return { ok = false, error = message } end
local function integer(value, minimum, maximum)
    return type(value) == 'number' and value == math.floor(value) and value >= minimum and value <= maximum
end
local function nearHub(source) return Core:RequireNear(source, Config.Hub, 4.0) end
local function nearBusiness(source, business)
    return nearHub(source) or Core:RequireNear(source, business.location, 4.0)
end
local function identifier(source) return Core:Identifier(source) end
local function transaction(queries)
    local success, result = pcall(function() return MySQL.transaction.await(queries) end)
    if not success then print('[egg_city] Database transaction failed; check oxmysql logs.') end
    return success and result == true
end
local function payoutQuery(owner, amount)
    return { query = 'INSERT INTO egg_city_payouts (identifier, amount) VALUES (?, ?) ON DUPLICATE KEY UPDATE amount = amount + VALUES(amount)', values = { owner, amount } }
end
local function claimQuery(owner, listing)
    return { query = 'INSERT INTO egg_city_claims (identifier, listing_id, item, quantity) VALUES (?, ?, ?, ?)', values = { owner, listing.id, listing.item, listing.quantity } }
end
local function refund(source, amount, originalOwner)
    if not Core:Credit(source, amount, 'bank') then
        local owner = originalOwner or identifier(source)
        if not owner then error('Refund has no original character identifier') end
        MySQL.insert.await('INSERT INTO egg_city_payouts (identifier, amount) VALUES (?, ?) ON DUPLICATE KEY UPDATE amount = amount + VALUES(amount)', { owner, amount })
    end
end
local function validItem(item)
    if type(item) ~= 'string' or not Config.MarketItems[item] then return false end
    return ESX.GetItems()[item] ~= nil
end
local function settleAuctions()
    return Core:WithLock('city_market', function()
        local expired = MySQL.query.await("SELECT * FROM egg_city_listings WHERE status = 'open' AND expires_at <= ? ORDER BY id", { os.time() })
        for _, listing in ipairs(expired) do
            local owner = listing.seller
            local queries = { { query = "UPDATE egg_city_listings SET status = 'closed' WHERE id = ? AND status = 'open'", values = { listing.id } } }
            if listing.kind == 'auction' and listing.bidder and listing.bid > 0 then
                owner = listing.bidder
                queries[#queries + 1] = payoutQuery(listing.seller, listing.bid)
            end
            queries[#queries + 1] = claimQuery(owner, listing)
            if not transaction(queries) then break end
        end
        return ok()
    end)
end

Core:RegisterAction('city.status', { cooldown = 1200 }, function(source, xPlayer)
    settleAuctions()
    local owner = identifier(source)
    if not owner then return fail('Your character session has ended.') end
    local ownedRooms = MySQL.query.await('SELECT room_id, owner, expires_at FROM egg_city_rooms', {})
    local businessRows = MySQL.query.await('SELECT business_id, owner, balance FROM egg_city_businesses', {})
    for _, row in ipairs(businessRows) do
        row.owned = row.owner == owner
        if not row.owned then row.balance = nil end
        row.owner = nil
    end
    for _, row in ipairs(ownedRooms) do row.owned = row.owner == owner; row.owner = nil end
    local adverts = MySQL.query.await('SELECT business_id, text FROM egg_city_adverts WHERE expires_at > ? ORDER BY id DESC LIMIT 12', { os.time() })
    local due = MySQL.scalar.await('SELECT amount FROM egg_city_payouts WHERE identifier = ?', { owner }) or 0
    local claims = MySQL.query.await('SELECT id, item, quantity FROM egg_city_claims WHERE identifier = ? AND claimed = 0', { owner })
    return ok({ rooms = ownedRooms, businesses = businessRows, adverts = adverts, payout = due, claims = claims, now = os.time(), name = xPlayer.getName() })
end)

Core:RegisterAction('city.room.buy', { cooldown = 2000 }, function(source, _, data)
    local room = rooms[data.id]
    if not room or not nearHub(source) then return fail('Visit the civic centre to arrange a room.') end
    return Core:WithLock('city_rooms', function()
        local owner, now = identifier(source), os.time()
        if not owner then return fail('Your character session has ended.') end
        local row = MySQL.single.await('SELECT owner, expires_at FROM egg_city_rooms WHERE room_id = ?', { room.id })
        if row and row.owner ~= owner and (row.expires_at == 0 or row.expires_at > now) then return fail('This room is occupied.') end
        if row and row.owner == owner and not room.rent then return fail('You already own this home.') end
        if not row or row.owner ~= owner or (row.expires_at ~= 0 and row.expires_at <= now) then
            local count = MySQL.scalar.await('SELECT COUNT(*) FROM egg_city_rooms WHERE owner = ? AND (expires_at = 0 OR expires_at > ?)', { owner, now })
            if count >= Config.MaxOwnedRooms then return fail('You have reached the room limit.') end
        end
        if not Core:TryDebit(source, room.price, 'bank') then return fail('Your bank balance is too low.') end
        local expiry = 0
        if room.rent then
            local base = row and row.owner == owner and math.max(now, row.expires_at) or now
            expiry = base + Config.RentalDays * 86400
        end
        if not transaction({ { query = 'INSERT INTO egg_city_rooms (room_id, owner, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE owner = VALUES(owner), expires_at = VALUES(expires_at)', values = { room.id, owner, expiry } } }) then
            refund(source, room.price, owner); return fail('The room could not be booked. Your payment has been returned or is waiting at the civic centre.')
        end
        for occupant, session in pairs(occupants) do
            if session.room == room.id and session.identifier ~= owner then leaveRoom(occupant, true) end
        end
        Core:Log(source, 'housing', ('Booked %s for $%s'):format(room.id, room.price))
        return ok({ message = room.rent and 'Your seven-day tenancy is ready.' or 'Your keys are ready.', expires = expiry })
    end)
end)

Core:RegisterAction('city.room.enter', { cooldown = 2000 }, function(source, xPlayer, data)
    local room = rooms[data.id]
    if not room or not Core:RequireNear(source, room.door, 4.0) then return fail('Stand by your building entrance.') end
    if occupants[source] or GetPlayerRoutingBucket(source) ~= 0 then return fail('Finish your current session before entering.') end
    local owner = identifier(source)
    local row = MySQL.single.await('SELECT owner, expires_at FROM egg_city_rooms WHERE room_id = ?', { room.id })
    if not row or row.owner ~= owner or (row.expires_at ~= 0 and row.expires_at <= os.time()) then return fail('You need an active tenancy or the keys to this home.') end
    if not Core:SessionAlive() or not owner or identifier(source) ~= owner then return fail('Your character session has ended.') end
    if occupants[source] or GetPlayerRoutingBucket(source) ~= 0 or not Core:RequireNear(source, room.door, 4.0) then return fail('Finish your current session and stand by your building entrance.') end
    MySQL.update.await('INSERT INTO egg_city_room_returns (identifier, room_id, previous_bucket) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE room_id = VALUES(room_id), previous_bucket = VALUES(previous_bucket)', { owner, room.id, GetPlayerRoutingBucket(source) })
    if not Core:SessionAlive() or identifier(source) ~= owner then return fail('Your character session ended before entering.') end
    occupants[source] = { room = room.id, previousBucket = GetPlayerRoutingBucket(source), identifier = owner }
    SetRoutingBucketPopulationEnabled(room.bucket, false)
    SetPlayerRoutingBucket(source, room.bucket)
    local ped = GetPlayerPed(source)
    if ped ~= 0 then SetEntityCoords(ped, room.inside.x, room.inside.y, room.inside.z, false, false, false, false) end
    return ok({ position = room.inside, room = room.id })
end)

leaveRoom = function(source, force)
    local session = occupants[source]
    if not session then return fail('You are not inside a home.') end
    local room = rooms[session.room]
    if not force and not Core:RequireNear(source, room.inside, 5.0) then return fail('Use the door to leave.') end
    SetPlayerRoutingBucket(source, session.previousBucket)
    occupants[source] = nil
    local ped = GetPlayerPed(source)
    if ped ~= 0 then SetEntityCoords(ped, room.door.x, room.door.y, room.door.z, false, false, false, false) end
    MySQL.update('DELETE FROM egg_city_room_returns WHERE identifier = ?', { session.identifier })
    if force then
        TriggerClientEvent('egg_city:roomEnded', source, room.door)
    end
    return ok({ position = room.door })
end
Core:RegisterAction('city.room.leave', { cooldown = 1000 }, function(source) return leaveRoom(source, false) end)

local function recoverRoom(source)
    local owner = identifier(source)
    if not owner or occupants[source] then return end
    local row = MySQL.single.await('SELECT room_id, previous_bucket FROM egg_city_room_returns WHERE identifier = ?', { owner })
    if not row or identifier(source) ~= owner or occupants[source] then return end
    local ped = GetPlayerPed(source)
    if ped == 0 or not DoesEntityExist(ped) then return end
    local room = rooms[row.room_id]
    local door = room and room.door or Config.Hub
    SetPlayerRoutingBucket(source, tonumber(row.previous_bucket) or 0)
    SetEntityCoords(ped, door.x, door.y, door.z, false, false, false, false)
    TriggerClientEvent('egg_city:roomEnded', source, door)
    MySQL.update('DELETE FROM egg_city_room_returns WHERE identifier = ?', { owner })
end

AddEventHandler('esx:playerLoaded', function(playerId)
    local id = tonumber(playerId)
    if not id then return end
    CreateThread(function()
        local owner = identifier(id)
        for _ = 1, 20 do
            if identifier(id) ~= owner then return end
            if GetPlayerPed(id) ~= 0 then recoverRoom(id); return end
            Wait(250)
        end
    end)
end)
CreateThread(function()
    Wait(2000)
    for _, id in ipairs(GetPlayers()) do recoverRoom(tonumber(id)) end
end)

Core:RegisterAction('city.jobs', { cooldown = 1200 }, function(source, xPlayer)
    if not nearHub(source) then return fail('Job records are available at the civic centre.') end
    local owner = identifier(source)
    if not owner then return fail('Your character session has ended.') end
    return Core:WithLock('city_jobs:' .. owner, function()
        if not Core:SessionAlive() then return fail('Your character session has ended.') end
        local current = ESX.GetPlayerFromId(source)
        if not current or current.identifier ~= owner then return fail('Your character session has ended.') end
        local job = current.getJob()
        MySQL.insert.await('INSERT INTO egg_city_jobs (identifier, job_name, grade) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE grade = VALUES(grade)', { owner, job.name, job.grade })
        return ok({ jobs = MySQL.query.await('SELECT job_name, grade FROM egg_city_jobs WHERE identifier = ? ORDER BY job_name', { owner }) })
    end)
end)

Core:RegisterAction('city.job.switch', { cooldown = 5000 }, function(source, xPlayer, data)
    if not nearHub(source) or type(data.job) ~= 'string' then return fail('Visit the civic centre to change jobs.') end
    local owner = identifier(source)
    if not owner then return fail('Your character session has ended.') end
    return Core:WithLock('city_jobs:' .. owner, function()
        local row = MySQL.single.await('SELECT grade FROM egg_city_jobs WHERE identifier = ? AND job_name = ?', { owner, data.job })
        if not row or not ESX.DoesJobExist(data.job, row.grade) then return fail('You are not employed in that role.') end
        local current = xPlayer.getJob()
        if current.name == data.job then row.grade = current.grade end
        MySQL.insert.await('INSERT INTO egg_city_jobs (identifier, job_name, grade) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE grade = VALUES(grade)', { owner, current.name, current.grade })
        if not Core:SessionAlive() or identifier(source) ~= owner then return fail('Your character session has ended.') end
        local currentPlayer = ESX.GetPlayerFromId(source)
        if not currentPlayer or currentPlayer.identifier ~= owner then return fail('Your character session has ended.') end
        currentPlayer.setJob(data.job, row.grade)
        Core:Log(source, 'employment', 'Switched job to ' .. data.job)
        return ok({ message = 'Your active job has changed.' })
    end)
end)

local function canHire(source, xPlayer, jobName, grade)
    if not Core:SessionAlive() then return false end
    if Core:IsStaff(source) then return true end
    local job, policy = xPlayer.getJob(), Config.Hiring[jobName]
    return policy and job.name == jobName and job.grade >= policy.minimumGrade and grade < job.grade
end
Core:RegisterAction('city.job.hire', { cooldown = 2000 }, function(source, xPlayer, data)
    if not nearHub(source) or not integer(data.target, 1, 65535) or not integer(data.grade, 0, 50) or type(data.job) ~= 'string' then return fail('Check the employee, job and grade at the civic centre.') end
    if data.target == source then return fail('Another authorised employer must hire you.') end
    if not ESX.DoesJobExist(data.job, data.grade) or not canHire(source, xPlayer, data.job, data.grade) then return fail('Your rank cannot grant this job or grade.') end
    local target = ESX.GetPlayerFromId(data.target)
    if not target or not nearHub(data.target) then return fail('The employee must be at the civic centre.') end
    local employee = identifier(data.target)
    if not employee then return fail('The employee or employer session has ended.') end
    return Core:WithLock('city_jobs:' .. employee, function()
        local manager = ESX.GetPlayerFromId(source)
        if not manager or not canHire(source, manager, data.job, data.grade) then return fail('The employer session or hiring authority has changed.') end
        MySQL.insert.await('INSERT INTO egg_city_jobs (identifier, job_name, grade) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE grade = VALUES(grade)', { employee, data.job, data.grade })
        local currentTarget = ESX.GetPlayerFromId(data.target)
        if Core:SessionAlive() and currentTarget and currentTarget.identifier == employee then
            if currentTarget.getJob().name == data.job then currentTarget.setJob(data.job, data.grade) end
            Core:Notify(data.target, 'An employer has updated your ' .. data.job .. ' role. Activate it at the civic centre.')
        end
        Core:Log(source, 'employment', ('Hired player %s into %s grade %s'):format(data.target, data.job, data.grade))
        return ok({ message = 'Employment record saved.' })
    end)
end)

Core:RegisterAction('city.job.revoke', { cooldown = 2000 }, function(source, xPlayer, data)
    if not nearHub(source) or not integer(data.target, 1, 65535) or type(data.job) ~= 'string' then return fail('Use the employment desk.') end
    local target = ESX.GetPlayerFromId(data.target)
    if not target or not nearHub(data.target) or data.target == source then return fail('The employee must be at the civic centre.') end
    local employee = identifier(data.target)
    if not employee then return fail('The employee or employer session has ended.') end
    return Core:WithLock('city_jobs:' .. employee, function()
        local row = MySQL.single.await('SELECT grade FROM egg_city_jobs WHERE identifier = ? AND job_name = ?', { employee, data.job })
        if not row or not canHire(source, xPlayer, data.job, row.grade) then return fail('Your rank cannot remove this role.') end
        MySQL.update.await('DELETE FROM egg_city_jobs WHERE identifier = ? AND job_name = ?', { employee, data.job })
        local currentTarget = ESX.GetPlayerFromId(data.target)
        if Core:SessionAlive() and currentTarget and currentTarget.identifier == employee then
            if currentTarget.getJob().name == data.job and ESX.DoesJobExist('unemployed', 0) then currentTarget.setJob('unemployed', 0) end
            Core:Notify(data.target, 'Your ' .. data.job .. ' employment has ended.')
        end
        return ok({ message = 'Employment record removed.' })
    end)
end)

Core:RegisterAction('city.business.buy', { cooldown = 2000 }, function(source, _, data)
    local business = businesses[data.id]
    if not business or not nearHub(source) then return fail('Business leases are handled at the civic centre.') end
    return Core:WithLock('city_business', function()
        local owner = identifier(source)
        if not owner then return fail('Your character session has ended.') end
        if MySQL.scalar.await('SELECT owner FROM egg_city_businesses WHERE business_id = ?', { business.id }) then return fail('This business has an owner.') end
        local count = MySQL.scalar.await('SELECT COUNT(*) FROM egg_city_businesses WHERE owner = ?', { owner })
        if count >= Config.MaxBusinessOwners then return fail('You have reached the business ownership limit.') end
        if not Core:TryDebit(source, business.price, 'bank') then return fail('Your bank balance is too low.') end
        if not transaction({ { query = 'INSERT INTO egg_city_businesses (business_id, owner) VALUES (?, ?)', values = { business.id, owner } } }) then
            refund(source, business.price, owner); return fail('The lease could not be saved. Payment returned or waiting at the civic centre.')
        end
        Core:Log(source, 'business', 'Purchased ' .. business.id)
        return ok({ message = 'Your business lease is ready.' })
    end)
end)

local function businessOwner(source, business)
    local owner = identifier(source)
    if not owner then return false end
    local recordedOwner = MySQL.scalar.await('SELECT owner FROM egg_city_businesses WHERE business_id = ?', { business.id })
    return recordedOwner == owner and identifier(source) == owner
end
Core:RegisterAction('city.business.bank', { cooldown = 1200 }, function(source, _, data)
    local owner = identifier(source)
    local business = businesses[data.id]
    if not business or not nearBusiness(source, business) or not integer(data.amount, 1, Config.MaxPrice) then return fail('Enter a valid amount at your business or the civic centre.') end
    if data.direction ~= 'deposit' and data.direction ~= 'withdraw' then return fail('Choose deposit or withdraw.') end
    return Core:WithLock('city_business', function()
        if not businessOwner(source, business) then return fail('Only the business owner can use its bank.') end
        if data.direction == 'deposit' then
            if not Core:TryDebit(source, data.amount, 'bank') then return fail('Your bank balance is too low.') end
            if not transaction({ { query = 'UPDATE egg_city_businesses SET balance = balance + ? WHERE business_id = ?', values = { data.amount, business.id } } }) then
                refund(source, data.amount, owner); return fail('Deposit failed. Payment returned or waiting at the civic centre.')
            end
        else
            local changed = MySQL.update.await('UPDATE egg_city_businesses SET balance = balance - ? WHERE business_id = ? AND balance >= ?', { data.amount, business.id, data.amount })
            if changed ~= 1 then return fail('The business balance is too low.') end
            if not Core:Credit(source, data.amount, 'bank') then
                MySQL.update.await('UPDATE egg_city_businesses SET balance = balance + ? WHERE business_id = ?', { data.amount, business.id })
                return fail('Your bank could not accept this withdrawal.')
            end
        end
        return ok({ message = 'Business bank updated.' })
    end)
end)

Core:RegisterAction('city.business.employee', { cooldown = 1500 }, function(source, _, data)
    local business = businesses[data.id]
    if not business or not nearBusiness(source, business) or not integer(data.target, 1, 65535) then return fail('Meet the employee at your business or civic centre.') end
    if data.remove ~= true and not integer(data.commission, 0, Config.MaxCommission) then return fail('Choose a commission between 0 and ' .. Config.MaxCommission .. ' percent.') end
    return Core:WithLock('city_business', function()
        if not businessOwner(source, business) then return fail('Only the owner can manage employees.') end
        local target = ESX.GetPlayerFromId(data.target)
        if not target or not nearBusiness(data.target, business) then return fail('The employee must be here.') end
        local employee = identifier(data.target)
        if not employee then return fail('The employee or employer session has ended.') end
        if data.remove == true then
            MySQL.update.await('DELETE FROM egg_city_employees WHERE business_id = ? AND identifier = ?', { business.id, employee })
        else
            MySQL.insert.await('INSERT INTO egg_city_employees (business_id, identifier, commission) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE commission = VALUES(commission)', { business.id, employee, data.commission })
        end
        Core:Notify(data.target, data.remove and 'Your business employment has ended.' or 'Your business employment and sales commission are recorded.')
        return ok({ message = 'Employee record updated.' })
    end)
end)

Core:RegisterAction('city.business.advert', { cooldown = 5000 }, function(source, _, data)
    local business = businesses[data.id]
    if not business or not nearBusiness(source, business) or type(data.text) ~= 'string' then return fail('Write your notice at the business hub.') end
    local text = data.text:gsub('[%c<>]', ''):match('^%s*(.-)%s*$')
    if #text < 4 or #text > Config.AdvertMaxLength then return fail('Use between 4 and ' .. Config.AdvertMaxLength .. ' characters.') end
    return Core:WithLock('city_business', function()
        if not businessOwner(source, business) then return fail('Only the owner can post business notices.') end
        local changed = MySQL.update.await('UPDATE egg_city_businesses SET balance = balance - ? WHERE business_id = ? AND balance >= ?', { Config.AdvertPrice, business.id, Config.AdvertPrice })
        if changed ~= 1 then return fail('The business needs $' .. Config.AdvertPrice .. ' in its bank.') end
        if not transaction({
            { query = 'DELETE FROM egg_city_adverts WHERE business_id = ?', values = { business.id } },
            { query = 'INSERT INTO egg_city_adverts (business_id, text, expires_at) VALUES (?, ?, ?)', values = { business.id, text, os.time() + Config.AdvertHours * 3600 } }
        }) then
            MySQL.update.await('UPDATE egg_city_businesses SET balance = balance + ? WHERE business_id = ?', { Config.AdvertPrice, business.id })
            return fail('The notice could not be posted. Business payment returned.')
        end
        return ok({ message = 'Your notice is on the community board for 24 hours.' })
    end)
end)

Core:RegisterAction('city.business.sale', { cooldown = 1200 }, function(source, _, data)
    local owner = identifier(source)
    if not owner then return fail('Your character session has ended.') end
    local business = businesses[data.id]
    if not business or not Core:RequireNear(source, business.location, 4.0) or not integer(data.product, 1, #business.products) then return fail('Order at the shop counter.') end
    return Core:WithLock('city_business', function()
        if not MySQL.scalar.await('SELECT owner FROM egg_city_businesses WHERE business_id = ?', { business.id }) then return fail('This shop is awaiting a business owner.') end
        local product = business.products[data.product]
        if not ESX.GetItems()[product.item] then return fail('This product has not been registered in the inventory.') end
        local commission, employee = 0, nil
        if data.employee ~= nil then
            if not integer(data.employee, 1, 65535) or data.employee == source then return fail('Choose the staff member serving you.') end
            local target = ESX.GetPlayerFromId(data.employee)
            if not target or not Core:RequireNear(data.employee, business.location, 4.0) then return fail('The staff member must be at the counter.') end
            employee = identifier(data.employee)
            if not employee then return fail('The staff member or buyer session has ended.') end
            local rate = MySQL.scalar.await('SELECT commission FROM egg_city_employees WHERE business_id = ? AND identifier = ?', { business.id, employee })
            if not rate then return fail('This player is not employed here.') end
            commission = math.floor(product.price * rate / 100)
        end
        local function completeSale()
            if not Core:TryDebit(source, product.price, 'bank') then return fail('Your bank balance is too low.') end
            local revenue = product.price - commission
            local queries = { { query = 'UPDATE egg_city_businesses SET balance = balance + ? WHERE business_id = ?', values = { revenue, business.id } } }
            if commission > 0 then queries[#queries + 1] = payoutQuery(employee, commission) end
            if not transaction(queries) then
                refund(source, product.price, owner)
                return fail('The sale failed. Payment returned or waiting at the civic centre.')
            end
            if Core:AddItem(source, product.item, 1) then return ok({ message = 'Thanks for shopping local.' }) end
            -- The business lock prevents withdrawal, and the employee payout
            -- lock prevents collection, until delivery or compensation finishes.
            local reversal = { { query = 'UPDATE egg_city_businesses SET balance = balance - ? WHERE business_id = ? AND balance >= ?', values = { revenue, business.id, revenue } } }
            if commission > 0 then
                reversal[#reversal + 1] = { query = 'UPDATE egg_city_payouts SET amount = amount - ? WHERE identifier = ? AND amount >= ?', values = { commission, employee, commission } }
            end
            if not transaction(reversal) then
                Core:Log(source, 'business_recovery', ('Delivery failed for %s: %s at %s, $%s; revenue reversal failed'):format(owner, product.item, business.id, product.price))
                return fail('The purchase needs staff recovery. Your payment is recorded in the server audit.')
            end
            refund(source, product.price, owner)
            return fail('Delivery failed. Make inventory space; your payment was returned or is waiting at the civic centre.')
        end
        if commission > 0 then return Core:WithLock('city_payout:' .. employee, completeSale) end
        return completeSale()
    end)
end)

Core:RegisterAction('city.market', { cooldown = 1200 }, function(source)
    if not nearHub(source) then return fail('Visit the civic centre marketplace.') end
    settleAuctions()
    local listings = MySQL.query.await("SELECT id, seller, item, quantity, kind, price, bid, expires_at FROM egg_city_listings WHERE status = 'open' ORDER BY id DESC LIMIT 100", {})
    for _, listing in ipairs(listings) do listing.owned = listing.seller == identifier(source); listing.seller = nil end
    return ok({ listings = listings, now = os.time() })
end)

Core:RegisterAction('city.market.list', { cooldown = 2000 }, function(source, _, data)
    if not nearHub(source) or not validItem(data.item) or not integer(data.quantity, 1, Config.MaxItemCount) or not integer(data.price, 1, Config.MaxPrice) then return fail('Check the permitted item, quantity and price at the marketplace.') end
    if data.kind ~= 'fixed' and data.kind ~= 'auction' then return fail('Choose a fixed sale or auction.') end
    if data.kind == 'auction' and not Config.AuctionHours[data.hours] then return fail('Choose a 1, 6 or 24 hour auction.') end
    return Core:WithLock('city_market', function()
        local owner = identifier(source)
        if not owner then return fail('Your character session has ended.') end
        local count = MySQL.scalar.await("SELECT COUNT(*) FROM egg_city_listings WHERE seller = ? AND status = 'open'", { owner })
        if count >= Config.MaxListings then return fail('You have reached the active listing limit.') end
        if not Core:RemoveItem(source, data.item, data.quantity) then return fail('You do not have that quantity to place in escrow.') end
        local expiry = os.time() + (data.kind == 'auction' and data.hours or 168) * 3600
        if not transaction({ { query = 'INSERT INTO egg_city_listings (seller, item, quantity, kind, price, expires_at) VALUES (?, ?, ?, ?, ?, ?)', values = { owner, data.item, data.quantity, data.kind, data.price, expiry } } }) then
            if not Core:AddItem(source, data.item, data.quantity) then
                Core:Log(source, 'market_recovery', ('Failed inventory return for %s: %sx %s after listing database error'):format(owner, data.quantity, data.item))
                return fail('The listing failed and your inventory could not accept the return. Ask staff to check the recovery log.')
            end
            return fail('The listing could not be saved. Items returned.')
        end
        Core:Log(source, 'market', ('Escrowed %sx %s'):format(data.quantity, data.item))
        return ok({ message = 'Your listing is live. The total price covers the whole bundle.' })
    end)
end)

Core:RegisterAction('city.market.buy', { cooldown = 1500 }, function(source, _, data)
    if not nearHub(source) or not integer(data.id, 1, 2147483647) then return fail('Use the marketplace counter.') end
    return Core:WithLock('city_market', function()
        local listing = MySQL.single.await('SELECT * FROM egg_city_listings WHERE id = ?', { data.id })
        if not listing or listing.status ~= 'open' or listing.kind ~= 'fixed' or listing.expires_at <= os.time() then return fail('This listing is no longer available.') end
        local owner = identifier(source)
        if not owner then return fail('Your character session has ended.') end
        if owner == listing.seller then return fail('You cannot buy your own listing.') end
        if not Core:TryDebit(source, listing.price, 'bank') then return fail('Your bank balance is too low.') end
        if not transaction({
            { query = "UPDATE egg_city_listings SET status = 'closed' WHERE id = ? AND status = 'open'", values = { listing.id } },
            payoutQuery(listing.seller, listing.price), claimQuery(owner, listing)
        }) then refund(source, listing.price, owner); return fail('The purchase failed. Payment returned or waiting at the civic centre.') end
        return ok({ message = 'Purchased. Collect your parcel at the civic centre.' })
    end)
end)

Core:RegisterAction('city.market.bid', { cooldown = 1500 }, function(source, _, data)
    if not nearHub(source) or not integer(data.id, 1, 2147483647) or not integer(data.amount, 1, Config.MaxPrice) then return fail('Enter a valid bid at the marketplace.') end
    return Core:WithLock('city_market', function()
        local listing = MySQL.single.await('SELECT * FROM egg_city_listings WHERE id = ?', { data.id })
        if not listing or listing.status ~= 'open' or listing.kind ~= 'auction' or listing.expires_at <= os.time() then return fail('This auction is closed.') end
        local owner = identifier(source)
        if not owner then return fail('Your character session has ended.') end
        if owner == listing.seller then return fail('You cannot bid on your own auction.') end
        if data.amount < listing.price or data.amount <= listing.bid then return fail('Your bid must meet the reserve and exceed the current bid.') end
        local payment = data.amount
        if listing.bidder == owner then payment = data.amount - listing.bid end
        if not Core:TryDebit(source, payment, 'bank') then return fail('Your bank balance is too low.') end
        local queries = { { query = "UPDATE egg_city_listings SET bidder = ?, bid = ? WHERE id = ? AND status = 'open' AND bid = ?", values = { owner, data.amount, listing.id, listing.bid } } }
        if listing.bidder and listing.bidder ~= owner then queries[#queries + 1] = payoutQuery(listing.bidder, listing.bid) end
        if not transaction(queries) then refund(source, payment, owner); return fail('The bid could not be saved. Payment returned or waiting at the civic centre.') end
        return ok({ message = 'Your bid is held in escrow. Outbid refunds are collected at the civic centre.' })
    end)
end)

Core:RegisterAction('city.market.cancel', { cooldown = 1500 }, function(source, _, data)
    if not nearHub(source) or not integer(data.id, 1, 2147483647) then return fail('Use the marketplace counter.') end
    return Core:WithLock('city_market', function()
        local listing = MySQL.single.await('SELECT * FROM egg_city_listings WHERE id = ?', { data.id })
        if not listing or listing.status ~= 'open' or listing.seller ~= identifier(source) then return fail('You do not own an open listing with this number.') end
        if listing.bidder then return fail('An auction with bids cannot be cancelled.') end
        if not transaction({
            { query = "UPDATE egg_city_listings SET status = 'cancelled' WHERE id = ? AND status = 'open'", values = { listing.id } },
            claimQuery(listing.seller, listing)
        }) then return fail('The listing could not be cancelled.') end
        return ok({ message = 'Listing cancelled. Collect the returned parcel.' })
    end)
end)

Core:RegisterAction('city.collect.money', { cooldown = 1500 }, function(source)
    if not nearHub(source) then return fail('Collect refunds and sale proceeds at the civic centre.') end
    local owner = identifier(source)
    if not owner then return fail('Your character session has ended.') end
    return Core:WithLock('city_payout:' .. owner, function()
        if identifier(source) ~= owner then return fail('Your character session has ended.') end
        local amount = math.min(MySQL.scalar.await('SELECT amount FROM egg_city_payouts WHERE identifier = ?', { owner }) or 0, Config.MaxPrice)
        if amount <= 0 then return fail('There are no payments waiting.') end
        local changed = MySQL.update.await('UPDATE egg_city_payouts SET amount = amount - ? WHERE identifier = ? AND amount >= ?', { amount, owner, amount })
        if changed ~= 1 then return fail('The payment changed. Please try again.') end
        if not Core:Credit(source, amount, 'bank') then
            MySQL.update.await('UPDATE egg_city_payouts SET amount = amount + ? WHERE identifier = ?', { amount, owner })
            return fail('Your bank could not accept the payment.')
        end
        return ok({ message = ('$%s transferred to your bank.'):format(amount) })
    end)
end)

Core:RegisterAction('city.collect.item', { cooldown = 1000 }, function(source, _, data)
    if not nearHub(source) or not integer(data.id, 1, 2147483647) then return fail('Collect parcels at the civic centre.') end
    return Core:WithLock('city_claim:' .. data.id, function()
        local owner = identifier(source)
        if not owner then return fail('Your character session has ended.') end
        local claim = MySQL.single.await('SELECT * FROM egg_city_claims WHERE id = ? AND identifier = ? AND claimed = 0', { data.id, owner })
        if not claim then return fail('This parcel has already been collected or belongs to someone else.') end
        local changed = MySQL.update.await('UPDATE egg_city_claims SET claimed = 1 WHERE id = ? AND identifier = ? AND claimed = 0', { claim.id, owner })
        if changed ~= 1 then return fail('The parcel has already been collected.') end
        if not Core:AddItem(source, claim.item, claim.quantity) then
            MySQL.update.await('UPDATE egg_city_claims SET claimed = 0 WHERE id = ?', { claim.id })
            return fail('Make space in your inventory and return for this parcel.')
        end
        return ok({ message = 'Parcel collected.' })
    end)
end)

CreateThread(function()
    while true do
        Wait(60000)
        local success = pcall(settleAuctions)
        if not success then print('[egg_city] Settlement waiting for database availability.') end
        for source, session in pairs(occupants) do
            local success, row = pcall(function() return MySQL.single.await('SELECT owner, expires_at FROM egg_city_rooms WHERE room_id = ?', { session.room }) end)
            if success and occupants[source] == session and identifier(source) == session.identifier and (not row or row.owner ~= session.identifier or (row.expires_at ~= 0 and row.expires_at <= os.time())) then
                leaveRoom(source, true)
                Core:Notify(source, 'Your tenancy has ended. Renew it at the civic centre.')
            end
        end
    end
end)

AddEventHandler('playerDropped', function()
    local player = source
    if occupants[player] then SetPlayerRoutingBucket(player, occupants[player].previousBucket); occupants[player] = nil end
end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for source in pairs(occupants) do leaveRoom(source, true) end
end)

exports('IsBusinessOwner', function(source, businessId)
    return businesses[businessId] ~= nil and businessOwner(source, businesses[businessId])
end)
exports('GetBusinesses', function() return Config.Businesses end)
exports('GetOwnedSpawnPoint', function(source)
    if not integer(source, 1, 65535) then return nil end
    local owner = identifier(source)
    if not owner then return nil end
    local rows = MySQL.query.await('SELECT room_id, expires_at FROM egg_city_rooms WHERE owner = ? AND (expires_at = 0 OR expires_at > ?)', { owner, os.time() })
    if identifier(source) ~= owner then return nil end
    local owned = {}
    for _, row in ipairs(rows) do
        if row.expires_at == 0 or row.expires_at > os.time() then owned[row.room_id] = true end
    end
    for _, room in ipairs(Config.Rooms) do
        if owned[room.id] then
            return { label = room.name, roomId = room.id,
                coords = { x = room.door.x, y = room.door.y, z = room.door.z, h = room.door.heading or 0.0 } }
        end
    end
    return nil
end)
