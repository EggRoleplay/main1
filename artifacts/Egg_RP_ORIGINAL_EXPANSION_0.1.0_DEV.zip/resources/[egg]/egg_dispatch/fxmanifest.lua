fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Egg Roleplay'
description 'Service-scoped emergency dispatch and 000 requests'
version '0.1.0'
shared_script 'config.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', '@egg_core/server_api.lua', 'server.lua' }
client_script 'client.lua'
ui_page 'web/index.html'
files { 'web/index.html', 'web/style.css', 'web/app.js' }
dependencies { 'egg_core', 'es_extended', 'oxmysql' }
