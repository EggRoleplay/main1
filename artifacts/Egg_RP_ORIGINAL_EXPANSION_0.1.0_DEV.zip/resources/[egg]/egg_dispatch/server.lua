local ESX = exports.es_extended:getSharedObject()
local Core = EggCore
local requests = {}
local allJobs = {}
for _, service in pairs(Config.Services) do for job in pairs(service.jobs) do allJobs[job] = true end end
local publicColumns = 'id, service, caller_name, message, postcode, x, y, z, routing_bucket, status, accepted_name, accepted_at, created_at, closed_at, close_reason'
local function failure(message) return { ok = false, error = message } end
local function clean(value, limit)
    if type(value) ~= 'string' then return nil end
    local text = value:gsub('[%c]', ' '):match('^%s*(.-)%s*$')
    if text == '' or #text > limit then return nil end
    return text
end
local function owner(player) return player.identifier or player.getIdentifier() end
local function displayName(player) return clean(player.getName(), 100) or 'Caller' end
local function samePlayer(source, player)
    local current = ESX.GetPlayerFromId(source)
    return Core:SessionAlive() and current ~= nil and owner(current) == owner(player)
end
local function positive(value)
    local number = tonumber(value)
    if not number or number ~= number or number % 1 ~= 0 or number < 1 or number > 2147483647 then return nil end
    return number
end
local function serviceFor(player)
    if not player then return nil end
    for key, service in pairs(Config.Services) do
        if player.job and service.jobs[player.job.name] then return key end
    end
end
local function currentService(source) return serviceFor(ESX.GetPlayerFromId(source)) end
local function nearestPostal(point)
    if GetResourceState('egg_work') ~= 'started' then return '—' end
    local result = exports.egg_work:NearestPostal(point)
    return result and result.code or '—'
end
local function publicCall(row)
    return { id = row.id, service = row.service, caller_name = row.caller_name, message = row.message,
        postcode = row.postcode, x = row.x, y = row.y, z = row.z, routing_bucket = row.routing_bucket,
        status = row.status, accepted_name = row.accepted_name, accepted_at = row.accepted_at,
        created_at = row.created_at, closed_at = row.closed_at, close_reason = row.close_reason,
        serviceLabel = Config.Services[row.service].label, colour = Config.Services[row.service].colour }
end
local function audit(source, event, data) Core:Log(source, event, json.encode(data)) end
local function sendUpdate(row)
    for _, player in pairs(ESX.GetExtendedPlayers()) do
        if serviceFor(player) == row.service then
            local call = publicCall(row)
            call.mine = row.accepted_identifier ~= nil and row.accepted_identifier == owner(player)
            TriggerClientEvent('egg_dispatch:call', player.source, call)
        end
        if owner(player) == row.caller_identifier then
            TriggerClientEvent('egg_dispatch:ownUpdate', player.source, { id = row.id, status = row.status, accepted_name = row.accepted_name })
        end
    end
end
local function fetchCall(id)
    return MySQL.single.await('SELECT * FROM egg_dispatch_calls WHERE id = ?', { id })
end
local function create(source, player, message, service, trusted, scene)
    if not Config.Services[service] or not message then return failure('Select an emergency service and describe what happened.') end
    local actor = owner(player)
    return Core:WithLock('dispatch:caller:' .. actor, function()
        if not samePlayer(source, player) then return failure('Your connection changed. Reopen dispatch.') end
        if not trusted and requests[actor] and os.time() - requests[actor] < Config.CitizenCooldown then return failure('Wait a minute before making another emergency request.') end
        local active = tonumber(MySQL.scalar.await("SELECT COUNT(*) FROM egg_dispatch_calls WHERE caller_identifier = ? AND status IN ('open', 'accepted')", { actor })) or 0
        if active >= Config.MaxActiveCallsPerCaller then return failure('You already have active calls. Review them with /000.') end
        if not samePlayer(source, player) then return failure('Your connection changed. Reopen dispatch.') end
        local ped = GetPlayerPed(source)
        if ped == 0 or not DoesEntityExist(ped) then return failure('Your player position is unavailable.') end
        local point, bucket = GetEntityCoords(ped), GetPlayerRoutingBucket(source)
        if trusted and type(scene) == 'table' and type(scene.x) == 'number' and type(scene.y) == 'number' and type(scene.z) == 'number'
            and scene.x == scene.x and scene.y == scene.y and scene.z == scene.z and math.abs(scene.x) < 10000 and math.abs(scene.y) < 10000 and math.abs(scene.z) < 2000 then
            point, bucket = scene, 0 -- trusted server resource passes an outdoor incident location
        end
        local id = MySQL.insert.await('INSERT INTO egg_dispatch_calls (service, caller_identifier, caller_name, message, postcode, x, y, z, routing_bucket) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', { service, actor, displayName(player), message, nearestPostal(point), point.x, point.y, point.z, bucket })
        if not id then return failure('The call could not be stored. Try again.') end
        requests[actor] = os.time()
        local row = fetchCall(id)
        if row then sendUpdate(row) end
        audit(source, 'dispatch.created', { call = id, service = service, trusted = trusted == true })
        return { ok = true, id = id, message = 'Call #' .. id .. ' sent to ' .. Config.Services[service].label .. '.' }
    end)
end
exports('Dispatch', function(source, message, service, scene)
    local player = ESX.GetPlayerFromId(source)
    if not player then return false end
    local result = create(source, player, clean(message, 600), service or 'police', true, scene)
    return result.ok, result.id
end)

Core:RegisterAction('dispatch:create', { cooldown = 1500 }, function(source, player, data)
    return create(source, player, clean(data.message, 600), clean(data.service, 16), false)
end)
Core:RegisterAction('dispatch:own', { cooldown = 500 }, function(source, player)
    local rows = MySQL.query.await('SELECT ' .. publicColumns .. ' FROM egg_dispatch_calls WHERE caller_identifier = ? ORDER BY id DESC LIMIT 20', { owner(player) })
    if not samePlayer(source, player) then return failure('Your connection changed.') end
    return { ok = true, calls = rows, services = Config.Services }
end)
Core:RegisterAction('dispatch:queue', { job = allJobs, cooldown = 500 }, function(source, player)
    local service = serviceFor(player)
    if not service then return failure('You are not assigned to an emergency service.') end
    local rows = MySQL.query.await('SELECT ' .. publicColumns .. ", accepted_identifier FROM egg_dispatch_calls WHERE service = ? AND status IN ('open', 'accepted') ORDER BY (status = 'accepted' AND accepted_identifier = ?) DESC, id DESC LIMIT " .. Config.QueueLimit, { service, owner(player) })
    if not samePlayer(source, player) or currentService(source) ~= service then return failure('Your service assignment changed.') end
    local calls = {}
    for _, row in ipairs(rows or {}) do local call = publicCall(row) call.mine = row.accepted_identifier == owner(player) calls[#calls + 1] = call end
    return { ok = true, calls = calls, service = service, label = Config.Services[service].label }
end)
Core:RegisterAction('dispatch:history', { job = allJobs, cooldown = 800 }, function(source, player)
    local service = serviceFor(player)
    if not service then return failure('You are not assigned to an emergency service.') end
    local rows = MySQL.query.await('SELECT ' .. publicColumns .. ', accepted_identifier FROM egg_dispatch_calls WHERE service = ? ORDER BY id DESC LIMIT ' .. Config.HistoryLimit, { service })
    if not samePlayer(source, player) or currentService(source) ~= service then return failure('Your service assignment changed.') end
    local calls = {}
    for _, row in ipairs(rows or {}) do
        local call = publicCall(row)
        call.mine = row.accepted_identifier == owner(player)
        calls[#calls + 1] = call
    end
    return { ok = true, calls = calls, service = service, label = Config.Services[service].label }
end)
Core:RegisterAction('dispatch:accept', { job = allJobs, cooldown = 1000 }, function(source, player, data)
    local id = positive(data.id)
    if not id then return failure('Choose a valid call.') end
    local actor, service = owner(player), serviceFor(player)
    return Core:WithLock('dispatch:call:' .. id, function()
        local row = fetchCall(id)
        if not samePlayer(source, player) or currentService(source) ~= service then return failure('Your service assignment changed.') end
        if not row or row.service ~= service then return failure('That call belongs to another service or is unavailable.') end
        if row.status ~= 'open' then return failure('That call has already been accepted or closed.') end
        local changed = MySQL.update.await("UPDATE egg_dispatch_calls SET status = 'accepted', accepted_identifier = ?, accepted_name = ?, accepted_at = CURRENT_TIMESTAMP WHERE id = ? AND service = ? AND status = 'open'", { actor, displayName(player), id, service })
        if changed ~= 1 then return failure('Another unit accepted that call.') end
        local updated = fetchCall(id)
        if updated then sendUpdate(updated) end
        audit(source, 'dispatch.accepted', { call = id, service = service })
        return { ok = true, call = updated and publicCall(updated), mine = true, message = 'You accepted call #' .. id .. '.' }
    end)
end)
Core:RegisterAction('dispatch:cancel', { cooldown = 1000 }, function(source, player, data)
    local id, reason = positive(data.id), clean(data.reason, 180)
    if not id or not reason then return failure('Select a call and give a short reason.') end
    local actor, service = owner(player), serviceFor(player)
    return Core:WithLock('dispatch:call:' .. id, function()
        local row = fetchCall(id)
        if not samePlayer(source, player) then return failure('Your connection changed.') end
        if not row or (row.status ~= 'open' and row.status ~= 'accepted') then return failure('That call is already closed or unavailable.') end
        local caller = row.caller_identifier == actor
        local assigned = row.accepted_identifier == actor and row.service == service and currentService(source) == service
        if not caller and not assigned then return failure('Only the caller or the assigned unit can close this call.') end
        local status = caller and 'cancelled' or 'closed'
        local changed = MySQL.update.await('UPDATE egg_dispatch_calls SET status = ?, closed_by = ?, closed_at = CURRENT_TIMESTAMP, close_reason = ? WHERE id = ? AND status IN (\'open\', \'accepted\')', { status, actor, reason, id })
        if changed ~= 1 then return failure('Call status changed. Refresh dispatch.') end
        local updated = fetchCall(id)
        if updated then sendUpdate(updated) end
        audit(source, 'dispatch.closed', { call = id, status = status, reason = reason })
        return { ok = true, message = 'Call #' .. id .. ' ' .. status .. '.' }
    end)
end)

CreateThread(function()
    while true do
        Wait(60000)
        -- Close only unclaimed stale requests; an active response never expires here.
        local ok = pcall(function()
            MySQL.update.await("UPDATE egg_dispatch_calls SET status = 'closed', closed_at = CURRENT_TIMESTAMP, close_reason = 'Unclaimed request expired' WHERE status = 'open' AND created_at < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL ? MINUTE)", { Config.OpenCallLifetime })
        end)
        if not ok then print('[egg_dispatch] Call expiry storage unavailable; retrying next minute.') end
        for identifier, timestamp in pairs(requests) do if os.time() - timestamp > Config.CitizenCooldown * 2 then requests[identifier] = nil end end
    end
end)
