Config = {}
Config.Services = {
    police = { label = 'Egg Police', colour = '#86acc7', jobs = { police = true, sheriff = true } },
    ambulance = { label = 'Ambulance Victoria', colour = '#df776c', jobs = { ambulance = true } },
    fire = { label = 'Fire Rescue', colour = '#d6a071', jobs = { fire = true, firefighter = true } }
}
Config.CitizenCooldown = 60
Config.MaxActiveCallsPerCaller = 2
Config.QueueLimit = 12
Config.HistoryLimit = 40
Config.OpenCallLifetime = 30 -- unclaimed calls expire after this many minutes
Config.EnableDefaultBindings = true -- configurable command mappings; no game control hijacking
Config.AlertDuration = 45 -- seconds; queue/history always remains available
-- The same original directory powers /postal, the HUD and dispatch: egg_work.Config.Postals.
