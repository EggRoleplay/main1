'use strict';
const terminal = document.getElementById('terminal');
const content = document.getElementById('content');
const alertPanel = document.getElementById('alert');
const feedback = document.getElementById('feedback');
const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'egg_dispatch';
const state = { mode: null, payload: null };
function esc(value) { return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
function list(value) { return Array.isArray(value) ? value : Object.values(value || {}); }
function time(value) {
  const date = new Date(typeof value === 'number' && value < 100000000000 ? value * 1000 : value);
  return Number.isNaN(date.getTime()) ? 'Time unavailable' : date.toLocaleString('en-AU', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
}
async function send(endpoint, payload = {}) {
  const response = await fetch(`https://${resource}/${endpoint}`, { method: 'POST', headers: { 'Content-Type': 'application/json; charset=UTF-8' }, body: JSON.stringify(payload) });
  return response.json();
}
async function action(name, payload = {}) {
  try {
    const result = await send('action', { action: name, payload });
    feedback.textContent = result.message || result.error || 'Records updated';
    feedback.style.color = result.ok ? '' : '#e5ae9f';
    return result;
  } catch (_) { feedback.textContent = 'Dispatch connection unavailable.'; return { ok: false }; }
}
async function refresh() {
  if (!state.mode) return;
  const result = await action(state.mode === 'citizen' ? 'own' : 'history');
  if (result.ok) { state.payload = result; render(); }
}
function form(id, callback) {
  const element = document.getElementById(id);
  if (!element) return;
  element.addEventListener('submit', async event => {
    event.preventDefault();
    const button = element.querySelector('button[type="submit"]');
    if (button.disabled) return;
    button.disabled = true;
    try { await callback(Object.fromEntries(new FormData(element))); } finally { if (button.isConnected) button.disabled = false; }
  });
}
function render() {
  const citizen = state.mode === 'citizen';
  document.getElementById('terminal-title').textContent = citizen ? '000 / Emergency request' : `${state.payload.label} / Dispatch history`;
  document.getElementById('terminal-subtitle').textContent = citizen ? 'Tell the operator what happened. Your current location is sent with the request.' : 'Calls for your service · latest 40';
  const calls = list(state.payload.calls);
  content.innerHTML = (citizen ? `<h1>Which service do you need?</h1><p class="muted">Choose the service you need and give a clear description of the emergency.</p><form id="create-call"><label>Service<select name="service" required>${Object.entries(state.payload.services || {}).map(([key, service]) => `<option value="${esc(key)}">${esc(service.label)}</option>`).join('')}</select></label><label>What has happened?<textarea name="message" maxlength="600" required placeholder="What happened, how many people are involved, any immediate danger"></textarea></label><button type="submit">Send emergency request</button></form><h2 style="margin-top:28px">Your recent calls</h2>` : `<div class="row"><h1>Call history</h1><button id="refresh" class="quiet" style="margin-left:auto">Refresh</button></div><p class="muted">Accept an open call to assign yourself and set a waypoint. Only the assigned unit or caller can close it.</p>`) + (calls.length ? calls.map(call => {
    const active = call.status === 'open' || call.status === 'accepted';
    return `<article class="card"><div class="card-heading"><h2>#${esc(call.id)} / ${esc(call.postcode)} · ${esc(call.serviceLabel || state.payload.services?.[call.service]?.label || call.service)}</h2><span class="tag">${esc(call.status)}</span></div><p>${esc(call.message)}</p><p class="details">${esc(call.caller_name)} · ${esc(time(call.created_at))}<br>Coordinates ${Number(call.x).toFixed(1)}, ${Number(call.y).toFixed(1)}, ${Number(call.z).toFixed(1)}${Number(call.routing_bucket) !== 0 ? ` · interior instance ${esc(call.routing_bucket)}` : ''}${call.accepted_name ? `<br>Assigned: ${esc(call.accepted_name)}${call.mine ? ' (you)' : ''}` : ''}${call.close_reason ? `<br>Closed: ${esc(call.close_reason)}` : ''}</p><div class="row">${!citizen && call.status === 'open' ? `<button data-accept="${call.id}">Accept call</button>` : ''}${active && (citizen || call.mine) ? `<button data-close="${call.id}" class="quiet">${citizen ? 'Cancel request' : 'Close assigned call'}</button>` : ''}</div><div data-reason="${call.id}"></div></article>`;
  }).join('') : '<p class="empty">No calls recorded.</p>');
  document.getElementById('refresh')?.addEventListener('click', refresh);
  form('create-call', async payload => { const result = await action('create', payload); if (result.ok) await refresh(); });
  content.querySelectorAll('[data-accept]').forEach(button => button.addEventListener('click', async () => {
    button.disabled = true;
    const result = await action('accept', { id: Number(button.dataset.accept) });
    if (result.ok) await refresh(); else button.disabled = false;
  }));
  content.querySelectorAll('[data-close]').forEach(button => button.addEventListener('click', () => {
    const id = Number(button.dataset.close);
    content.querySelector(`[data-reason="${id}"]`).innerHTML = `<form id="close-${id}"><label>${citizen ? 'Reason for cancellation' : 'Response outcome'}<textarea name="reason" maxlength="180" required></textarea></label><button type="submit" class="danger">${citizen ? 'Confirm cancellation' : 'Close call'}</button></form>`;
    form(`close-${id}`, async payload => { const result = await action('cancel', { ...payload, id }); if (result.ok) await refresh(); });
  }));
}
function showAlert(call) {
  alertPanel.hidden = !call;
  if (!call) return;
  alertPanel.style.setProperty('--service', /^#[a-f\d]{6}$/i.test(call.colour || '') ? call.colour : '#df776c');
  document.getElementById('service').textContent = call.serviceLabel;
  document.getElementById('postcode').textContent = `Postcode ${call.postcode}`;
  document.getElementById('call-ref').textContent = `[call #${call.id}]`;
  document.getElementById('call-message').textContent = call.message;
  document.getElementById('coordinates').textContent = `${Number(call.x).toFixed(1)}, ${Number(call.y).toFixed(1)}, ${Number(call.z).toFixed(1)}`;
  document.getElementById('received').textContent = time(call.created_at);
  document.getElementById('unit').textContent = call.accepted_name || 'Unassigned';
  document.getElementById('accept-label').textContent = call.mine ? 'Route' : 'Accept';
}
function close() { send('close').catch(() => {}); }
document.getElementById('close').addEventListener('click', close);
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !terminal.hidden) close(); });
window.addEventListener('message', event => {
  const message = event.data;
  if (!message || typeof message !== 'object') return;
  if (message.type === 'alert') showAlert(message.call);
  if (message.type === 'open') { state.mode = message.view; state.payload = message.payload; terminal.hidden = false; feedback.textContent = 'Connected'; render(); }
  if (message.type === 'close') { state.mode = null; terminal.hidden = true; }
  if (message.type === 'refreshOwn' && state.mode === 'citizen') refresh();
});
