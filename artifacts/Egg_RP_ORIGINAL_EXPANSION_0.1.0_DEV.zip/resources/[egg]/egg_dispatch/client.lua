local ESX = exports.es_extended:getSharedObject()
local Core = exports.egg_core
local calls, dismissed, active = {}, {}, nil
local fullScreen = false
local function servicesJob(job)
    if not job then return false end
    for _, service in pairs(Config.Services) do if service.jobs[job.name] then return true end end
    return false
end
local function render()
    active = nil
    for _, call in pairs(calls) do
        if (call.status == 'open' or call.mine) and not dismissed[call.id] then
            if not active or (call.mine and not active.mine) or (call.mine == active.mine and call.id > active.id) then active = call end
        end
    end
    SendNUIMessage({ type = 'alert', call = active })
end
local function refresh()
    if not servicesJob(ESX.GetPlayerData().job) then calls, active = {}, nil render() return end
    Core:Action('dispatch:queue', {}, function(result)
        if not result.ok then return end
        calls = {}
        for _, call in pairs(result.calls or {}) do calls[call.id] = call end
        render()
    end)
end
local function open(view)
    Core:Action(view == 'citizen' and 'dispatch:own' or 'dispatch:history', {}, function(result)
        if not result.ok then ESX.ShowNotification(result.error or 'Dispatch is unavailable.') return end
        fullScreen = true
        SetNuiFocus(true, true)
        SendNUIMessage({ type = 'open', view = view, payload = result })
    end)
end
local function close()
    fullScreen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ type = 'close' })
end
local function accept()
    if not active then return end
    if active.mine then SetNewWaypoint(active.x + 0.0, active.y + 0.0) return end
    Core:Action('dispatch:accept', { id = active.id }, function(result)
        if not result.ok then ESX.ShowNotification(result.error or 'Call unavailable.') refresh() return end
        if result.call then SetNewWaypoint(result.call.x + 0.0, result.call.y + 0.0) end
        refresh()
    end)
end
local function cancel()
    if not active then return end
    if not active.mine then dismissed[active.id] = true render() return end
    -- Closing an assigned call requires an explicit reason in the history terminal.
    open('history')
end
RegisterCommand('000', function() open('citizen') end, false)
RegisterCommand('dispatch', function() refresh() open('history') end, false)
RegisterCommand('dispatchaccept', accept, false)
RegisterCommand('dispatchcancel', cancel, false)
RegisterCommand('dispatchhistory', function() open('history') end, false)
if Config.EnableDefaultBindings then
    RegisterKeyMapping('dispatchaccept', 'Dispatch: accept current call', 'keyboard', '7')
    RegisterKeyMapping('dispatchcancel', 'Dispatch: dismiss or close current call', 'keyboard', '8')
    RegisterKeyMapping('dispatchhistory', 'Dispatch: service call history', 'keyboard', '9')
end
RegisterNetEvent('egg_dispatch:call', function(call)
    if not servicesJob(ESX.GetPlayerData().job) then return end
    if call.status == 'open' or call.status == 'accepted' then calls[call.id] = call else calls[call.id], dismissed[call.id] = nil, nil end
    if call.mine then dismissed[call.id] = nil end
    render()
    local id = call.id
    if call.status == 'open' then SetTimeout(Config.AlertDuration * 1000, function() if calls[id] and not calls[id].mine then dismissed[id] = true render() end end) end
end)
RegisterNetEvent('egg_dispatch:ownUpdate', function(update)
    ESX.ShowNotification(('Call #%s: %s%s.'):format(update.id, update.status, update.accepted_name and (' — ' .. update.accepted_name) or ''))
    if fullScreen then SendNUIMessage({ type = 'refreshOwn' }) end
end)
RegisterNetEvent('esx:setJob', function(job)
    calls, dismissed, active = {}, {}, nil
    render()
    if fullScreen then close() end
    if servicesJob(job) then SetTimeout(1000, refresh) end
end)
RegisterNUICallback('close', function(_, callback) close() callback({ ok = true }) end)
local allowed = { create = true, own = true, history = true, queue = true, accept = true, cancel = true }
RegisterNUICallback('action', function(data, callback)
    if not fullScreen or not allowed[data.action] then callback({ ok = false, error = 'Action unavailable.' }) return end
    Core:Action('dispatch:' .. data.action, type(data.payload) == 'table' and data.payload or {}, function(result)
        if data.action == 'accept' and result.ok and result.call then SetNewWaypoint(result.call.x + 0.0, result.call.y + 0.0) refresh() end
        if data.action == 'cancel' and result.ok then refresh() end
        callback(result)
    end)
end)
CreateThread(function()
    Wait(5000)
    while true do refresh() Wait(25000) end
end)
AddEventHandler('onResourceStop', function(resource) if resource == GetCurrentResourceName() then SetNuiFocus(false, false) end end)
