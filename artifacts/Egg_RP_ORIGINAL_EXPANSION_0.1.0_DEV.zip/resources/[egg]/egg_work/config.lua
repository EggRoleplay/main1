Config = {}

Config.InteractionDistance = 2.0
Config.ValidationDistance = 5.0
Config.SessionGrace = 60
Config.CancelDistance = 8.0
Config.MarkerDistance = 25.0
Config.PaymentAccount = 'bank'
Config.MaxTradeCount = 20

-- Stock GTA coordinates. Move these points to suit your chosen map assets.
Config.Stations = {
    { id = 'pier_fishing', label = 'Del Perro fishing jetty', type = 'fishing', x = -1849.21, y = -1249.61, z = 8.62, tier = 1 },
    { id = 'lake_fishing', label = 'Alamo fishing spot', type = 'fishing', x = 1302.35, y = 4225.15, z = 33.92, tier = 2 },
    { id = 'paleto_fishing', label = 'Paleto fishing spot', type = 'fishing', x = -1598.58, y = 5271.24, z = 2.03, tier = 3 },
    { id = 'supplies', label = 'Jetty tackle counter', type = 'shop', x = -1819.20, y = -1220.40, z = 13.02 },
    { id = 'fishmonger', label = 'Catch of the Day', type = 'sell', stock = 'fish', x = -1816.21, y = -1193.71, z = 14.30 },
    { id = 'recycle_collect', label = 'Cypress recycling drop', type = 'collect', x = -429.20, y = -1728.10, z = 19.78 },
    { id = 'recycle_sort', label = 'Cypress sorting bench', type = 'sort', x = -425.30, y = -1720.55, z = 19.11 },
    { id = 'smelter', label = 'La Mesa metalworks', type = 'smelt', x = 1078.40, y = -1976.20, z = 31.47 },
    { id = 'workshop', label = 'Davis community workshop', type = 'craft', x = 915.24, y = -1268.08, z = 25.53 },
    { id = 'pawn', label = 'Davis Pawn & Trade', type = 'sell', stock = 'pawn', x = 412.04, y = -807.58, z = 29.31 },
    { id = 'produce', label = 'Grapeseed produce stall', type = 'sell', stock = 'produce', x = 1700.78, y = 4939.70, z = 42.08 },
    { id = 'forage_1', label = 'Grapeseed mushroom patch', type = 'forage', x = 2389.15, y = 5026.84, z = 46.18 },
    { id = 'forage_2', label = 'Grapeseed mushroom patch', type = 'forage', x = 2402.26, y = 5040.39, z = 46.69 },
    { id = 'forage_3', label = 'Grapeseed mushroom patch', type = 'forage', x = 2414.61, y = 5014.02, z = 46.19 }
}

Config.Fish = {
    { id = 'bream', item = 'egg_bream', label = 'Bream', level = 1, tier = 1, weight = 70, minGrams = 200, maxGrams = 1500, sell = 45 },
    { id = 'flathead', item = 'egg_flathead', label = 'Flathead', level = 1, tier = 1, weight = 30, minGrams = 450, maxGrams = 2800, sell = 70 },
    { id = 'snapper', item = 'egg_snapper', label = 'Snapper', level = 3, tier = 2, weight = 30, minGrams = 1000, maxGrams = 6000, sell = 110 },
    { id = 'tuna', item = 'egg_tuna', label = 'Tuna', level = 6, tier = 3, weight = 12, minGrams = 3500, maxGrams = 12000, sell = 175 }
}
Config.Fishing = { duration = 18, xp = 18, rod = 'egg_fishing_rod', bait = 'egg_bait' }
Config.Collection = { duration = 12, cooldown = 30, output = 'egg_recyclables', count = 1, xp = 5 }
Config.Sorting = { duration = 14, input = 'egg_recyclables', xp = 14 }
Config.Foraging = { duration = 10, cooldown = 180, item = 'egg_mushroom', xp = 12 }

Config.Smelting = {
    { id = 'steel', label = 'Steel bar', level = 1, duration = 18, xp = 16,
      inputs = { egg_scrap = 3 }, outputs = { egg_steel = 1 } }
}

Config.Recipes = {
    { id = 'rod', label = 'Fishing rod', blueprint = 'egg_blueprint_rod', level = 1, duration = 20, xp = 20,
      inputs = { egg_timber = 2, egg_steel = 1, egg_plastic = 2 }, outputs = { egg_fishing_rod = 1 } },
    { id = 'lockpick', label = 'Lockpick', blueprint = 'egg_blueprint_lockpick', level = 3, duration = 25, xp = 28,
      inputs = { egg_steel = 2, egg_copper = 1 }, outputs = { egg_lockpick = 1 } },
    { id = 'toolkit', label = 'Vehicle toolkit', blueprint = 'egg_blueprint_toolkit', level = 5, duration = 35, xp = 40,
      inputs = { egg_steel = 5, egg_plastic = 3, egg_copper = 2 }, outputs = { egg_toolkit = 1 } }
}

Config.Shop = {
    { item = 'egg_fishing_rod', label = 'Fishing rod', price = 220 },
    { item = 'egg_bait', label = 'Bait', price = 8 },
    { item = 'egg_timber', label = 'Timber offcut', price = 15 },
    { item = 'egg_gps', label = 'Street directory', price = 65 },
    { item = 'egg_blueprint_rod', label = 'Rod making notes', price = 120 },
    { item = 'egg_blueprint_lockpick', label = 'Lockpick pattern', price = 250 },
    { item = 'egg_blueprint_toolkit', label = 'Toolkit plans', price = 450 }
}
Config.SellStock = {
    fish = { egg_bream = 45, egg_flathead = 70, egg_snapper = 110, egg_tuna = 175 },
    pawn = { egg_scrap = 8, egg_plastic = 6, egg_copper = 15, egg_steel = 25, egg_toolkit = 170 },
    produce = { egg_mushroom = 18 }
}
Config.Labels = {
    egg_bream = 'Bream', egg_flathead = 'Flathead', egg_snapper = 'Snapper', egg_tuna = 'Tuna',
    egg_scrap = 'Scrap metal', egg_plastic = 'Plastic', egg_copper = 'Copper', egg_steel = 'Steel bar',
    egg_mushroom = 'Mushrooms', egg_toolkit = 'Vehicle toolkit', egg_timber = 'Timber offcut',
    egg_recyclables = 'Recycling bag', egg_fishing_rod = 'Fishing rod', egg_lockpick = 'Lockpick'
}

-- This is an original, short directory of named public waypoints, not a copied postal grid.
Config.Postals = {
    { code = '101', label = 'City centre / Legion Square', x = 215.76, y = -810.12 },
    { code = '102', label = 'Pillbox medical precinct', x = 298.42, y = -584.49 },
    { code = '103', label = 'Mission Row station', x = 425.08, y = -979.56 },
    { code = '104', label = 'Mirror Park shops', x = 1155.87, y = -329.57 },
    { code = '105', label = 'Davis workshop', x = 915.24, y = -1268.08 },
    { code = '106', label = 'Davis pawn counter', x = 412.04, y = -807.58 },
    { code = '107', label = 'Cypress recycling', x = -429.20, y = -1728.10 },
    { code = '108', label = 'La Mesa metalworks', x = 1078.40, y = -1976.20 },
    { code = '201', label = 'Del Perro jetty', x = -1849.21, y = -1249.61 },
    { code = '202', label = 'Tackle counter', x = -1819.20, y = -1220.40 },
    { code = '203', label = 'Vespucci canal precinct', x = -1116.61, y = -1507.12 },
    { code = '301', label = 'Sandy township', x = 1856.40, y = 3682.32 },
    { code = '302', label = 'Alamo fishing spot', x = 1302.35, y = 4225.15 },
    { code = '303', label = 'Grapeseed produce stall', x = 1700.78, y = 4939.70 },
    { code = '304', label = 'Grapeseed foraging track', x = 2389.15, y = 5026.84 },
    { code = '401', label = 'Paleto township', x = -104.19, y = 6467.56 },
    { code = '402', label = 'Paleto fishing spot', x = -1598.58, y = 5271.24 }
}
