local ESX = exports['es_extended']:getSharedObject()
local active, menuOpen = nil, false

exports('NearestPostal', function(point)
    local best, square
    for _, postal in ipairs(Config.Postals) do
        local distance = (point.x - postal.x)^2 + (point.y - postal.y)^2
        if not square or distance < square then best, square = postal, distance end
    end
    if not best then return nil end
    return { code = best.code, label = best.label, x = best.x, y = best.y, distance = math.sqrt(square) }
end)

local function notify(message)
    ESX.ShowNotification(message)
end

local function action(name, data, callback)
    exports.egg_core:Action(name, data, function(result)
        if not result or not result.ok then
            notify(result and result.error or 'The counter is unavailable. Try again in a moment.')
            if callback then callback(nil) end
            return
        end
        if result.message then notify(result.message) end
        if callback then callback(result) end
    end)
end

local function distance(coords, station)
    return #(coords - vector3(station.x, station.y, station.z))
end

local function drawText(text, y, scale)
    SetTextFont(0)
    SetTextScale(scale or 0.35, scale or 0.35)
    SetTextColour(255, 255, 255, 255)
    SetTextCentre(true)
    SetTextOutline()
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(0.5, y)
end

local function cancelWork(message)
    if not active then return end
    local token = active.token
    active = nil
    TriggerEvent('egg_hud:progressStop')
    ClearPedTasks(PlayerPedId())
    if token then action('work:cancel', { token = token }) end
    if message then notify(message) end
end

local scenarios = {
    fishing = 'WORLD_HUMAN_STAND_FISHING', collect = 'WORLD_HUMAN_GARDENER_PLANT',
    forage = 'WORLD_HUMAN_GARDENER_PLANT', sort = 'PROP_HUMAN_BUM_BIN',
    craft = 'WORLD_HUMAN_HAMMERING', smelt = 'WORLD_HUMAN_HAMMERING'
}

local function startWork(station, recipe)
    if active then notify('Finish or cancel your current job first.') return end
    ESX.UI.Menu.CloseAll()
    menuOpen = false
    active = { pending = true, station = station }
    action('work:begin', { station = station.id, recipe = recipe }, function(result)
        if not result then active = nil return end
        -- Leaving before the reply arrives still cancels the server session.
        if not active then action('work:cancel', { token = result.token }) return end
        active = { token = result.token, station = station, label = result.label,
                   started = GetGameTimer(), duration = result.duration * 1000 + 250 }
        if GetResourceState('egg_hud') == 'started' then TriggerEvent('egg_hud:progress', { label = result.label, duration = result.duration * 1000 }) end
        if scenarios[result.mode] then TaskStartScenarioInPlace(PlayerPedId(), scenarios[result.mode], 0, true) end
    end)
end

local function openMenu(name, title, entries, callback)
    menuOpen = true
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), name,
        { title = title, align = 'top-left', elements = entries },
        function(data, menu) callback(data.current, menu) end,
        function(_, menu) menu.close() menuOpen = false end)
end

local function showLogbook(status)
    local entries = {}
    for _, fish in ipairs(Config.Fish) do
        local record
        for _, row in ipairs(status.logbook or {}) do if row.species == fish.id then record = row break end end
        local count = record and tonumber(record.catches) or 0
        local largest = record and tonumber(record.largest_grams) or 0
        entries[#entries + 1] = {
            label = ('%s — %d caught / best %.2f kg'):format(fish.label, count, largest / 1000), value = fish.id
        }
    end
    openMenu('logbook', 'Fishing logbook', entries, function() end)
end

local function showSkills(status)
    local labels = { fishing = 'Fishing', crafting = 'Workshop', recycling = 'Recycling', foraging = 'Foraging' }
    local entries = {}
    for _, name in ipairs({ 'fishing', 'crafting', 'recycling', 'foraging' }) do
        local progression = status.skills[name]
        entries[#entries + 1] = { label = ('%s — level %d / %d XP'):format(labels[name], progression.level, progression.xp), value = name }
    end
    openMenu('skills', 'Work skills', entries, function() end)
end

local function ingredients(recipe)
    local parts = {}
    for item, count in pairs(recipe.inputs) do parts[#parts + 1] = ('%d %s'):format(count, Config.Labels[item] or item) end
    table.sort(parts)
    return table.concat(parts, ', ')
end

local function chooseAmount(station, item, label, price, selling)
    local entries = {}
    for _, count in ipairs({ 1, 5, 10, 20 }) do
        if count <= Config.MaxTradeCount then
            entries[#entries + 1] = { label = ('%s %d — $%d'):format(selling and 'Sell' or 'Buy', count, price * count), count = count }
        end
    end
    openMenu('amount', label, entries, function(entry, menu)
        action('work:trade', { station = station.id, item = item, count = entry.count }, function(result)
            if result then menu.close() menuOpen = false end
        end)
    end)
end

local function stationMenu(station)
    if active then return end
    if station.type == 'shop' then
        local entries = {}
        for _, stock in ipairs(Config.Shop) do
            entries[#entries + 1] = { label = stock.label .. ' — $' .. stock.price, stock = stock }
        end
        openMenu('shop', station.label, entries, function(entry, menu)
            menu.close()
            chooseAmount(station, entry.stock.item, entry.stock.label, entry.stock.price, false)
        end)
    elseif station.type == 'sell' then
        local entries = {}
        for item, price in pairs(Config.SellStock[station.stock]) do
            entries[#entries + 1] = { label = (Config.Labels[item] or item) .. ' — $' .. price .. ' each', item = item, price = price }
        end
        table.sort(entries, function(a, b) return a.label < b.label end)
        openMenu('selling', station.label, entries, function(entry, menu)
            menu.close()
            chooseAmount(station, entry.item, Config.Labels[entry.item] or entry.item, entry.price, true)
        end)
    elseif station.type == 'craft' or station.type == 'smelt' then
        action('work:status', {}, function(status)
            if not status then return end
            local entries, recipes = {}, station.type == 'craft' and Config.Recipes or Config.Smelting
            for _, recipe in ipairs(recipes) do
                local unlocked = station.type == 'smelt' or status.blueprints[recipe.id]
                entries[#entries + 1] = {
                    label = ('%s — level %d%s'):format(recipe.label, recipe.level, unlocked and '' or ' / blueprint needed'),
                    recipe = recipe
                }
            end
            entries[#entries + 1] = { label = 'Work skills', skills = true }
            openMenu('recipes', station.label, entries, function(entry, menu)
                menu.close()
                if entry.skills then showSkills(status) return end
                openMenu('recipe', entry.recipe.label, {
                    { label = 'Materials: ' .. ingredients(entry.recipe), info = true },
                    { label = 'Start work', start = true }
                }, function(choice)
                    if choice.start then startWork(station, entry.recipe.id) end
                end)
            end)
        end)
    elseif station.type == 'fishing' then
        openMenu('fishing', station.label, {
            { label = 'Cast a line', value = 'fish' }, { label = 'Fishing logbook', value = 'logbook' },
            { label = 'Work skills', value = 'skills' }
        }, function(entry, menu)
            if entry.value == 'fish' then startWork(station) return end
            menu.close()
            action('work:status', {}, function(status)
                if not status then return end
                if entry.value == 'logbook' then showLogbook(status) else showSkills(status) end
            end)
        end)
    else
        openMenu('work', station.label, {
            { label = 'Start work', value = 'start' }, { label = 'Work skills', value = 'skills' }
        }, function(entry, menu)
            if entry.value == 'start' then startWork(station) return end
            menu.close()
            action('work:status', {}, function(status) if status then showSkills(status) end end)
        end)
    end
end

RegisterNetEvent('egg_work:directory', function()
    local entries = {}
    for _, postal in ipairs(Config.Postals) do
        entries[#entries + 1] = { label = postal.code .. ' · ' .. postal.label, postal = postal }
    end
    openMenu('directory', 'Street directory', entries, function(entry, menu)
        SetNewWaypoint(entry.postal.x, entry.postal.y)
        notify('Route set to ' .. entry.postal.code .. ' — ' .. entry.postal.label .. '.')
        menu.close()
        menuOpen = false
    end)
end)

RegisterCommand('postal', function(_, args)
    action('work:postal', { code = args[1] }, function(result)
        if not result then return end
        if result.postal then
            SetNewWaypoint(result.postal.x, result.postal.y)
            notify('Route set to ' .. result.postal.label .. '.')
        else
            TriggerEvent('egg_work:directory')
        end
    end)
end, false)
RegisterCommand('fishlog', function()
    action('work:status', {}, function(status) if status then showLogbook(status) end end)
end, false)
RegisterCommand('workskills', function()
    action('work:status', {}, function(status) if status then showSkills(status) end end)
end, false)

CreateThread(function()
    local icons = { fishing = 68, shop = 68, sell = 52, collect = 365, sort = 365, smelt = 566, craft = 566, forage = 469 }
    local seenForage = false
    for _, station in ipairs(Config.Stations) do
        if station.type ~= 'forage' or not seenForage then
            local blip = AddBlipForCoord(station.x, station.y, station.z)
            SetBlipSprite(blip, icons[station.type] or 1)
            SetBlipColour(blip, 25)
            SetBlipScale(blip, 0.65)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(station.label)
            EndTextCommandSetBlipName(blip)
        end
        if station.type == 'forage' then seenForage = true end
    end
end)

CreateThread(function()
    while true do
        local sleep = 1000
        local ped, coords = PlayerPedId(), GetEntityCoords(PlayerPedId())
        if active and not active.pending then
            sleep = 0
            local elapsed = GetGameTimer() - active.started
            if IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) or distance(coords, active.station) > Config.CancelDistance then
                cancelWork('Job cancelled. You left the work spot.')
            elseif IsControlJustReleased(0, 73) then
                cancelWork('Job cancelled.')
            elseif elapsed >= active.duration then
                local token = active.token
                active = nil
                TriggerEvent('egg_hud:progressStop')
                ClearPedTasks(ped)
                action('work:finish', { token = token })
            else
                DisableControlAction(0, 24, true)
                DisableControlAction(0, 25, true)
                DisableControlAction(0, 37, true)
                if GetResourceState('egg_hud') ~= 'started' then
                    DrawRect(0.5, 0.9, 0.26, 0.018, 25, 28, 29, 220)
                    local width = 0.256 * math.min(1, elapsed / active.duration)
                    DrawRect(0.372 + width / 2, 0.9, width, 0.012, 30, 150, 52, 255)
                    drawText(active.label .. ' · X to cancel', 0.855)
                end
            end
        elseif not active then
            local nearest, nearestDistance
            for _, station in ipairs(Config.Stations) do
                local metres = distance(coords, station)
                if metres < Config.MarkerDistance then
                    sleep = 0
                    DrawMarker(2, station.x, station.y, station.z + 0.15, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0,
                        0.2, 0.2, 0.2, 218, 171, 87, 165, false, true, 2, false, nil, nil, false)
                end
                if metres < Config.InteractionDistance and (not nearestDistance or metres < nearestDistance) then
                    nearest, nearestDistance = station, metres
                end
            end
            if nearest and not menuOpen and not IsPedInAnyVehicle(ped, false) and not IsEntityDead(ped) then
                ESX.ShowHelpNotification('Press ~INPUT_CONTEXT~ for ' .. nearest.label .. '.')
                if IsControlJustReleased(0, 38) then stationMenu(nearest) end
            end
        end
        Wait(sleep)
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        if active then ClearPedTasks(PlayerPedId()) end
        ESX.UI.Menu.CloseAll()
    end
end)
