local ESX = exports['es_extended']:getSharedObject()
local core = EggCore
exports('NearestPostal', function(point)
    if type(point) ~= 'table' and type(point) ~= 'vector3' then return nil end
    local x, y = tonumber(point.x), tonumber(point.y)
    if not x or not y or x ~= x or y ~= y then return nil end
    local best, square
    for _, postal in ipairs(Config.Postals) do
        local distance = (x - postal.x)^2 + (y - postal.y)^2
        if not square or distance < square then best, square = postal, distance end
    end
    if not best then return nil end
    return { code = best.code, label = best.label, x = best.x, y = best.y, distance = math.sqrt(square) }
end)
local sessions, nodeCooldowns = {}, {}

local function errorResult(message)
    return { ok = false, error = message }
end

local function find(list, key, value)
    for _, entry in ipairs(list) do
        if entry[key] == value then return entry end
    end
end

local function skill(source, name)
    local result = core:GetSkill(source, name)
    return { xp = tonumber(result.xp) or 0, level = math.max(1, tonumber(result.level) or 1) }
end

local function stationFor(source, id)
    if type(id) ~= 'string' then return end
    local station = find(Config.Stations, 'id', id)
    if station and core:RequireNear(source, station, Config.ValidationDistance) then return station end
end

local function activePlayer(source)
    local ped = GetPlayerPed(source)
    return ped ~= 0 and GetEntityHealth(ped) > 0 and GetVehiclePedIsIn(ped, false) == 0
end

local function hasInputs(source, inputs)
    for item, count in pairs(inputs) do
        if not core:HasItem(source, item, count) then return false end
    end
    return true
end

-- Everything passes through the same rollback path, including mixed material recipes.
local function exchange(source, inputs, outputs, identifier)
    if identifier and core:Identifier(source) ~= identifier then return false, 'Your character has changed. Try again.' end
    local owner = identifier or core:Identifier(source)
    local removed, granted = {}, {}
    local function restore()
        if core:Identifier(source) ~= owner then core:Log(source, 'work', 'Character disconnected during rollback; staff must reconcile.') return end
        for item, count in pairs(granted) do core:RemoveItem(source, item, count) end
        for item, count in pairs(removed) do
            if not core:AddItem(source, item, count) then
                core:Log(source, 'work', 'Inventory rollback failed for ' .. item .. '; staff follow-up required.')
            end
        end
    end
    if not hasInputs(source, inputs) then return false, 'You are missing the materials.' end
    for item, count in pairs(inputs) do
        if not core:RemoveItem(source, item, count) then
            restore()
            return false, 'The materials could not be taken. Try again.'
        end
        removed[item] = count
    end
    for item, count in pairs(outputs) do
        if not core:AddItem(source, item, count) then
            restore()
            return false, 'Make some room in your inventory first.'
        end
        granted[item] = count
    end
    return true
end

local function locked(source, fn)
    local identifier = core:Identifier(source)
    if not identifier then return errorResult('Your character is not ready.') end
    return core:WithLock('egg_work:' .. identifier, function()
        if core:Identifier(source) ~= identifier then return errorResult('Your character has changed. Try again.') end
        return fn()
    end)
end

local function knownBlueprint(source, recipe)
    return MySQL.scalar.await(
        'SELECT 1 FROM egg_work_blueprints WHERE identifier = ? AND recipe = ? LIMIT 1',
        { core:Identifier(source), recipe.id }
    ) ~= nil
end

local function chooseFish(source, station)
    local level = skill(source, 'fishing').level
    local eligible, total = {}, 0
    for _, fish in ipairs(Config.Fish) do
        if level >= fish.level and station.tier >= fish.tier then
            eligible[#eligible + 1] = fish
            total = total + fish.weight
        end
    end
    if total <= 0 then return end
    local roll = math.random(1, total)
    for _, fish in ipairs(eligible) do
        roll = roll - fish.weight
        if roll <= 0 then return fish end
    end
end

core:RegisterAction('work:status', { cooldown = 1500 }, function(source)
    local identifier = core:Identifier(source)
    local blueprints = MySQL.query.await('SELECT recipe FROM egg_work_blueprints WHERE identifier = ?', { identifier })
    local unlocked = {}
    for _, row in ipairs(blueprints) do unlocked[row.recipe] = true end
    return { ok = true,
        skills = { fishing = skill(source, 'fishing'), crafting = skill(source, 'crafting'),
                   recycling = skill(source, 'recycling'), foraging = skill(source, 'foraging') },
        blueprints = unlocked,
        logbook = MySQL.query.await(
            'SELECT species, catches, total_grams, largest_grams FROM egg_work_fishing WHERE identifier = ? ORDER BY species',
            { identifier }
        )
    }
end)

core:RegisterAction('work:begin', { cooldown = 1000 }, function(source, _, data)
    return locked(source, function()
        local station = stationFor(source, data.station)
        if not station or not activePlayer(source) then return errorResult('Walk up to the work spot first.') end
        local identifier = core:Identifier(source)
        local current = sessions[source]
        if current and os.time() <= current.expires then return errorResult('Finish or cancel your current job first.') end

        local mode, duration, label, recipe = station.type
        local inputs = {}
        if mode == 'fishing' then
            if not core:HasItem(source, Config.Fishing.rod, 1) or not core:HasItem(source, Config.Fishing.bait, 1) then
                return errorResult('Bring a fishing rod and some bait.')
            end
            if not chooseFish(source, station) then return errorResult('Build up your fishing skill at another spot.') end
            duration, label = Config.Fishing.duration, 'Waiting for a bite'
            inputs[Config.Fishing.bait] = 1
        elseif mode == 'collect' then
            duration, label = Config.Collection.duration, 'Collecting recycling'
        elseif mode == 'sort' then
            duration, label = Config.Sorting.duration, 'Sorting the recycling'
            inputs[Config.Sorting.input] = 1
        elseif mode == 'forage' then
            duration, label = Config.Foraging.duration, 'Picking mushrooms'
        elseif mode == 'smelt' then
            recipe = find(Config.Smelting, 'id', data.recipe)
            if not recipe then return errorResult('Choose a metalworking job.') end
            if skill(source, 'recycling').level < recipe.level then return errorResult('You need more recycling experience.') end
            inputs, duration, label = recipe.inputs, recipe.duration, 'Smelting ' .. recipe.label:lower()
        elseif mode == 'craft' then
            recipe = find(Config.Recipes, 'id', data.recipe)
            if not recipe then return errorResult('Choose a workshop plan.') end
            if skill(source, 'crafting').level < recipe.level then return errorResult('You need more workshop experience.') end
            if not knownBlueprint(source, recipe) then return errorResult('Read the blueprint from your inventory first.') end
            inputs, duration, label = recipe.inputs, recipe.duration, 'Making ' .. recipe.label:lower()
        else
            return errorResult('This counter does not offer that work.')
        end

        if not hasInputs(source, inputs) then return errorResult('You are missing the materials.') end
        if core:Identifier(source) ~= identifier then return errorResult('Your character has changed. Try again.') end
        local cooldownKey = identifier .. ':' .. station.id
        if (nodeCooldowns[cooldownKey] or 0) > os.time() then return errorResult('Give this spot a moment to recover.') end
        local token = ('%s:%s:%s'):format(source, os.time(), math.random(100000, 999999))
        if core:Identifier(source) ~= identifier then return errorResult('Your character has changed. Try again.') end
        sessions[source] = {
            token = token, identifier = core:Identifier(source), station = station, mode = mode,
            recipe = recipe, inputs = inputs, ready = os.time() + duration,
            expires = os.time() + duration + Config.SessionGrace
        }
        return { ok = true, token = token, duration = duration, label = label, mode = mode }
    end)
end)

core:RegisterAction('work:finish', { cooldown = 500 }, function(source, _, data)
    return locked(source, function()
        local session = sessions[source]
        if not session or type(data.token) ~= 'string' or data.token ~= session.token then
            return errorResult('That job has ended. Start again at the work spot.')
        end
        if session.identifier ~= core:Identifier(source) or os.time() > session.expires then
            sessions[source] = nil
            return errorResult('That job has expired.')
        end
        if os.time() < session.ready then return errorResult('The job is still running.') end
        if not activePlayer(source) or not core:RequireNear(source, session.station, Config.ValidationDistance) then
            sessions[source] = nil
            return errorResult('You left the work spot. Start again when you are ready.')
        end
        if session.mode == 'fishing' and not core:HasItem(source, Config.Fishing.rod, 1) then
            sessions[source] = nil
            return errorResult('You no longer have your fishing rod.')
        end
        sessions[source] = nil -- Claim once, before the first inventory or database mutation.
        local outputs, xp, skillName, message, fish, grams = {}, 0, nil, nil
        if session.mode == 'fishing' then
            fish = chooseFish(source, session.station)
            if not fish then return errorResult('No catch is available at this spot.') end
            grams = math.random(fish.minGrams, fish.maxGrams)
            outputs[fish.item] = 1
            xp, skillName = Config.Fishing.xp, 'fishing'
            message = ('Caught a %s — %.2f kg.'):format(fish.label:lower(), grams / 1000)
        elseif session.mode == 'collect' then
            outputs[Config.Collection.output] = Config.Collection.count
            xp, skillName, message = Config.Collection.xp, 'recycling', 'Recycling collected. Take it to the sorting bench.'
        elseif session.mode == 'sort' then
            outputs = { egg_scrap = math.random(2, 4), egg_plastic = math.random(1, 3) }
            if math.random(1, 100) <= 35 then outputs.egg_copper = 1 end
            xp, skillName, message = Config.Sorting.xp, 'recycling', 'Sorted. The usable materials are in your bag.'
        elseif session.mode == 'forage' then
            outputs[Config.Foraging.item] = math.random(1, 3)
            xp, skillName, message = Config.Foraging.xp, 'foraging', 'Mushrooms picked. The produce stall will buy them.'
        else
            outputs, xp = session.recipe.outputs, session.recipe.xp
            skillName = session.mode == 'craft' and 'crafting' or 'recycling'
            message = session.recipe.label .. ' ready.'
        end

        local success, why = exchange(source, session.inputs, outputs, session.identifier)
        if not success then return errorResult(why) end
        if session.mode == 'collect' or session.mode == 'forage' then
            local seconds = session.mode == 'collect' and Config.Collection.cooldown or Config.Foraging.cooldown
            nodeCooldowns[session.identifier .. ':' .. session.station.id] = os.time() + seconds
        end
        core:AddXP(source, skillName, xp)
        if fish then
            local saved = pcall(function()
                MySQL.update.await([[
                    INSERT INTO egg_work_fishing (identifier, species, catches, total_grams, largest_grams)
                    VALUES (?, ?, 1, ?, ?)
                    ON DUPLICATE KEY UPDATE catches = catches + 1, total_grams = total_grams + VALUES(total_grams),
                    largest_grams = GREATEST(largest_grams, VALUES(largest_grams))
                ]], { session.identifier, fish.id, grams, grams })
            end)
            if not saved then
                core:Log(source, 'work', 'Fishing catch granted but logbook write failed; check database migration.')
                message = message .. ' The logbook is unavailable; let staff know.'
            end
        end
        return { ok = true, message = message, skill = skillName, progression = skill(source, skillName) }
    end)
end)

core:RegisterAction('work:cancel', { cooldown = 200 }, function(source, _, data)
    if sessions[source] and sessions[source].token == data.token then sessions[source] = nil end
    return { ok = true }
end)

core:RegisterAction('work:postal', { cooldown = 1000 }, function(source, _, data)
    if not core:HasItem(source, 'egg_gps', 1) then return errorResult('You need a street directory in your inventory.') end
    if data.code == nil or data.code == '' then return { ok = true } end
    if type(data.code) ~= 'string' then return errorResult('Use a directory code, for example /postal 101.') end
    local postal = find(Config.Postals, 'code', data.code)
    if not postal then return errorResult('That code is not in this street directory.') end
    return { ok = true, postal = postal }
end)

core:RegisterAction('work:trade', { cooldown = 750 }, function(source, _, data)
    return locked(source, function()
        local station = stationFor(source, data.station)
        local count = tonumber(data.count)
        if not station or not count or count ~= math.floor(count) or count < 1 or count > Config.MaxTradeCount then
            return errorResult('Choose a valid amount at the counter.')
        end
        if station.type == 'shop' then
            local stock = find(Config.Shop, 'item', data.item)
            if not stock then return errorResult('That item is not stocked here.') end
            local cost = stock.price * count
            if not core:TryDebit(source, cost, Config.PaymentAccount) then return errorResult('There is not enough in your bank account.') end
            if not core:AddItem(source, stock.item, count) then
                if not core:Credit(source, cost, Config.PaymentAccount) then
                    core:Log(source, 'work', 'Shop refund failed; staff must reconcile $' .. cost .. '.')
                end
                return errorResult('Make some room in your inventory first.')
            end
            return { ok = true, message = ('Bought %s × %d for $%d.'):format(stock.label, count, cost) }
        elseif station.type == 'sell' then
            local prices = Config.SellStock[station.stock]
            local price = prices and prices[data.item]
            if not price then return errorResult('We do not buy that here.') end
            if not core:RemoveItem(source, data.item, count) then return errorResult('You do not have that many to sell.') end
            local total = price * count
            if not core:Credit(source, total, Config.PaymentAccount) then
                if not core:AddItem(source, data.item, count) then core:Log(source, 'work', 'Sale rollback failed for ' .. data.item) end
                return errorResult('The payment could not be completed.')
            end
            core:Log(source, 'work', ('Sold %d %s for $%d.'):format(count, data.item, total))
            return { ok = true, message = ('Sold %d for $%d. Paid into your bank.'):format(count, total) }
        end
        return errorResult('Use the shop or a trade counter.')
    end)
end)

for _, recipe in ipairs(Config.Recipes) do
    ESX.RegisterUsableItem(recipe.blueprint, function(source)
        locked(source, function()
            local identifier = core:Identifier(source)
            if knownBlueprint(source, recipe) then
                core:Notify(source, 'You already know the ' .. recipe.label:lower() .. ' plan.')
                return
            end
            if core:Identifier(source) ~= identifier then return end
            if not core:RemoveItem(source, recipe.blueprint, 1) then return end
            local saved = pcall(function()
                MySQL.insert.await('INSERT INTO egg_work_blueprints (identifier, recipe) VALUES (?, ?)',
                    { identifier, recipe.id })
            end)
            if not saved then
                if core:Identifier(source) ~= identifier or not core:AddItem(source, recipe.blueprint, 1) then core:Log(source, 'work', 'Blueprint refund failed for ' .. recipe.id) end
                if core:Identifier(source) == identifier then core:Notify(source, 'The plan could not be saved. Let staff know.') end
                return
            end
            if core:Identifier(source) == identifier then core:Notify(source, 'You learned the ' .. recipe.label:lower() .. ' plan. Use it at the community workshop.') end
        end)
    end)
end

ESX.RegisterUsableItem('egg_gps', function(source)
    if core:HasItem(source, 'egg_gps', 1) then TriggerClientEvent('egg_work:directory', source) end
end)

AddEventHandler('playerDropped', function() sessions[source] = nil end)
CreateThread(function()
    while true do
        Wait(60000)
        local now = os.time()
        for player, session in pairs(sessions) do if now > session.expires then sessions[player] = nil end end
        for key, expires in pairs(nodeCooldowns) do if now > expires then nodeCooldowns[key] = nil end end
    end
end)
