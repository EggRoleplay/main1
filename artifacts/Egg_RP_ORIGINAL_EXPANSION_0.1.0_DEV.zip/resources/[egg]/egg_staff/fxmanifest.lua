fx_version 'cerulean'
game 'gta5'
lua54 'yes'
name 'Egg RP | staff desk'
version '0.1.0'
shared_script 'config.lua'
client_script 'client.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', '@egg_core/server_api.lua', 'server.lua' }
dependencies { 'egg_core', 'esx_menu_default', 'esx_menu_dialog' }
