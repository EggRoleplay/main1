local ESX = exports.es_extended:getSharedObject()
local core, duty = EggCore, {}

local function permission(source, action)
    local player = ESX.GetPlayerFromId(source)
    if not player then return false end
    if IsPlayerAceAllowed(source, 'egg.staff.' .. action) then return true end
    local rank = Config.Ranks[player.getGroup()]
    return rank and rank.permissions[action] == true or false
end

local function webhook(title, text)
    local url = GetConvar('egg_discord_webhook', '')
    -- Never log the webhook URL. Configure it server-side, never in a shared file.
    if not url:match('^https://discord%.com/api/webhooks/') then return end
    PerformHttpRequest(url, function(status)
        if status ~= 204 and status ~= 200 then print(('[Egg Staff] Discord delivery returned %s'):format(status)) end
    end, 'POST', json.encode({ username = 'Egg Staff', embeds = {{ title = title, description = text:sub(1, 1900), color = 13467458 }} }), { ['Content-Type'] = 'application/json' })
end

local function off(source, reason)
    local clock = duty[source]
    if not clock then return end
    duty[source] = nil
    MySQL.update.await('UPDATE egg_staff_duty SET ended_at = NOW(), end_reason = ? WHERE id = ? AND ended_at IS NULL', { reason, clock.id })
    core:Log(source, 'staff_duty', ('Duty ended: %s (%ds)'):format(reason, os.time() - clock.started))
    TriggerClientEvent('egg_staff:duty', source, false, 0)
    webhook('Duty ended', ('%s · %s'):format(clock.name, reason))
end

exports('IsOnDuty', function(source) return duty[tonumber(source)] ~= nil end)
exports('HasPermission', permission)

core:RegisterAction('staff:desk', { cooldown = 750 }, function(source, player)
    if not permission(source, 'desk') then return { ok = false, error = 'Staff access required.' } end
    local reports = MySQL.query.await('SELECT id, reporter_name, message, status, assigned_to, created_at FROM egg_reports WHERE status <> ? ORDER BY id DESC LIMIT 50', { 'closed' })
    local players = {}
    for _, id in ipairs(GetPlayers()) do
        players[#players + 1] = { id = tonumber(id), name = GetPlayerName(id) }
    end
    local rank = Config.Ranks[player.getGroup()]
    return { ok = true, rank = rank and rank.label or 'Staff', duty = duty[source] ~= nil,
        remaining = duty[source] and math.max(0, Config.DutySeconds - (os.time() - duty[source].started)) or 0,
        reports = reports, players = players, permissions = {
            reports = permission(source, 'reports'), teleport = permission(source, 'teleport'), kick = permission(source, 'kick') } }
end)

core:RegisterAction('staff:duty', { cooldown = 2000 }, function(source, player)
    if not permission(source, 'desk') then return { ok = false, error = 'Staff access required.' } end
    if duty[source] then off(source, 'clocked off'); return { ok = true, duty = false } end
    local owner = core:Identifier(source)
    local id = MySQL.insert.await('INSERT INTO egg_staff_duty (identifier, staff_name) VALUES (?, ?)', { owner, GetPlayerName(source) })
    if not core:SessionAlive() or core:Identifier(source) ~= owner then
        MySQL.update.await('UPDATE egg_staff_duty SET ended_at = NOW(), end_reason = ? WHERE id = ?', { 'character disconnected before duty began', id })
        return { ok = false, error = 'Your character changed. Clock on again.' }
    end
    duty[source] = { id = id, started = os.time(), name = GetPlayerName(source), warned = false }
    TriggerClientEvent('egg_staff:duty', source, true, Config.DutySeconds)
    core:Log(source, 'staff_duty', 'Clocked on')
    webhook('Duty started', GetPlayerName(source))
    return { ok = true, duty = true }
end)

core:RegisterAction('staff:report', { cooldown = Config.ReportCooldown }, function(source, player, data)
    local text = type(data.message) == 'string' and data.message:match('^%s*(.-)%s*$') or ''
    if #text < 8 or #text > Config.ReportLimit then return { ok = false, error = 'Write a short description (8–1200 characters).' } end
    local owner = core:Identifier(source)
    local open = MySQL.scalar.await('SELECT COUNT(*) FROM egg_reports WHERE reporter = ? AND status <> ?', { owner, 'closed' })
    if open >= 3 then return { ok = false, error = 'You already have three open reports.' } end
    local id = MySQL.insert.await('INSERT INTO egg_reports (reporter, reporter_name, message) VALUES (?, ?, ?)', { owner, GetPlayerName(source), text })
    for staffSource in pairs(duty) do core:Notify(staffSource, ('New report #%d. Open /staff.'):format(id)) end
    core:Log(source, 'report', ('Created report #%d'):format(id))
    webhook('New report #' .. id, GetPlayerName(source) .. ': ' .. text)
    return { ok = true, id = id }
end)

core:RegisterAction('staff:ticket', { cooldown = 800 }, function(source, player, data)
    if not permission(source, 'reports') or not duty[source] then return { ok = false, error = 'Clock on to handle reports.' } end
    local id = tonumber(data.id)
    if not id or id % 1 ~= 0 then return { ok = false, error = 'Invalid report.' } end
    local owner = core:Identifier(source)
    return core:WithLock('report:' .. id, function()
        local ticket = MySQL.single.await('SELECT * FROM egg_reports WHERE id = ?', { id })
        if not ticket or ticket.status == 'closed' then return { ok = false, error = 'That report is closed.' } end
        if ticket.assigned_to and ticket.assigned_to ~= owner then return { ok = false, error = 'Another staff member is handling that report.' } end
        if data.action == 'claim' then
            MySQL.update.await('UPDATE egg_reports SET assigned_to = ?, status = ? WHERE id = ?', { owner, 'claimed', id })
        elseif data.action == 'reply' then
            local text = type(data.message) == 'string' and data.message or ''
            if #text < 1 or #text > 1200 then return { ok = false, error = 'Reply must be 1–1200 characters.' } end
            MySQL.insert.await('INSERT INTO egg_report_messages (report_id, author, message) VALUES (?, ?, ?)', { id, owner, text })
            for _, online in pairs(ESX.GetExtendedPlayers()) do
                if online.identifier == ticket.reporter then core:Notify(online.source, ('Report #%d · Staff: %s'):format(id, text)) end
            end
        elseif data.action == 'close' then
            MySQL.update.await('UPDATE egg_reports SET status = ?, closed_at = NOW() WHERE id = ?', { 'closed', id })
        else return { ok = false, error = 'Invalid report action.' } end
        core:Log(source, 'report', ('%s report #%d'):format(data.action, id))
        return { ok = true }
    end)
end)

core:RegisterAction('staff:player', { cooldown = 2000 }, function(source, player, data)
    local target = tonumber(data.target)
    if not target or target % 1 ~= 0 or target == source or not ESX.GetPlayerFromId(target) then return { ok = false, error = 'Player is unavailable.' } end
    if not duty[source] then return { ok = false, error = 'Clock on first.' } end
    if data.action == 'goto' and permission(source, 'teleport') then
        local ped, targetPed = GetPlayerPed(source), GetPlayerPed(target)
        if ped == 0 or targetPed == 0 then return { ok = false, error = 'Player has not spawned.' } end
        SetPlayerRoutingBucket(source, GetPlayerRoutingBucket(target))
        local point = GetEntityCoords(targetPed)
        SetEntityCoords(ped, point.x + 1.0, point.y, point.z, false, false, false, false)
    elseif data.action == 'kick' and permission(source, 'kick') then
        if permission(target, 'kick') then return { ok = false, error = 'Use the owner process for staff disciplinary action.' } end
        local reason = type(data.reason) == 'string' and data.reason or ''
        if #reason < 5 or #reason > 200 then return { ok = false, error = 'Give a reason (5–200 characters).' } end
        DropPlayer(target, 'Egg RP: ' .. reason)
    else return { ok = false, error = 'You do not have permission for that action.' } end
    core:Log(source, 'staff_action', ('%s player %d'):format(data.action, target))
    return { ok = true }
end)

CreateThread(function()
    while true do
        Wait(10000)
        for source, clock in pairs(duty) do
            local elapsed = os.time() - clock.started
            if elapsed >= Config.DutySeconds then off(source, 'two-hour shift complete'); core:Notify(source, 'Your two-hour staff shift is complete. You have clocked off.')
            elseif elapsed >= Config.DutySeconds - 300 and not clock.warned then clock.warned = true; core:Notify(source, 'Five minutes left on your staff shift.') end
        end
    end
end)

AddEventHandler('playerDropped', function() off(source, 'disconnected') end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    -- Non-awaiting writes because a stopping resource cannot wait on its own coroutine.
    for _, clock in pairs(duty) do MySQL.update('UPDATE egg_staff_duty SET ended_at = NOW(), end_reason = ? WHERE id = ? AND ended_at IS NULL', { 'resource stopped', clock.id }) end
end)

MySQL.ready(function()
    MySQL.update('UPDATE egg_staff_duty SET ended_at = NOW(), end_reason = ? WHERE ended_at IS NULL', { 'server restarted' })
end)
