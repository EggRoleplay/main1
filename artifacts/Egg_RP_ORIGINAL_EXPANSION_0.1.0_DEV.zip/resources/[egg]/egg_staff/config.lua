Config = {}
Config.DutySeconds = 7200
Config.ReportLimit = 1200
Config.ReportCooldown = 60000
Config.Ranks = {
    helper = { label = 'Support', permissions = { desk = true, reports = true } },
    mod = { label = 'Moderator', permissions = { desk = true, reports = true, teleport = true, kick = true } },
    admin = { label = 'Administrator', permissions = { desk = true, reports = true, teleport = true, kick = true } },
    superadmin = { label = 'Owner', permissions = { desk = true, reports = true, teleport = true, kick = true } }
}
