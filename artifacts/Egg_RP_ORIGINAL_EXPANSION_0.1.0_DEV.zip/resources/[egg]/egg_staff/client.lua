local ESX = exports.es_extended:getSharedObject()
local function request(action, payload, cb)
    exports.egg_core:Action('staff:' .. action, payload or {}, function(result)
        if not result.ok then ESX.ShowNotification(result.error); return end
        if cb then cb(result) end
    end)
end

local function dialog(title, callback)
    ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'staff_input', { title = title }, function(data, menu)
        menu.close(); if data.value and data.value ~= '' then callback(data.value) end
    end, function(_, menu) menu.close() end)
end

local open
open = function()
    request('desk', {}, function(result)
        ESX.UI.Menu.CloseAll()
        local elements = {
            { label = result.duty and ('Clock off · %d min left'):format(math.ceil(result.remaining / 60)) or 'Clock on · two-hour shift', value = 'duty' },
            { label = ('Reports · %d open'):format(#result.reports), value = 'reports' },
            { label = 'Players online', value = 'players' }
        }
        ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'staff', { title = 'Egg Staff · ' .. result.rank, align = 'top-left', elements = elements }, function(data, menu)
            if data.current.value == 'duty' then menu.close(); request('duty', {}, open)
            elseif data.current.value == 'reports' then
                local rows = {}
                for _, report in ipairs(result.reports) do rows[#rows + 1] = { label = ('#%d · %s · %s'):format(report.id, report.reporter_name, report.status), report = report } end
                ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'reports', { title = 'Reports', align = 'top-left', elements = rows }, function(selected)
                    local report = selected.current.report
                    ESX.ShowNotification(report.message)
                    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'ticket', { title = 'Report #' .. report.id, align = 'top-left', elements = {
                        { label = 'Take report', action = 'claim' }, { label = 'Reply', action = 'reply' }, { label = 'Close report', action = 'close' }
                    } }, function(choice, ticketMenu)
                        if choice.current.action == 'reply' then
                            dialog('Reply to report #' .. report.id, function(text) request('ticket', { id = report.id, action = 'reply', message = text }, function() ESX.ShowNotification('Reply sent.') end) end)
                        else ticketMenu.close(); request('ticket', { id = report.id, action = choice.current.action }, open) end
                    end, function(_, ticketMenu) ticketMenu.close() end)
                end, function(_, reportsMenu) reportsMenu.close() end)
            elseif data.current.value == 'players' then
                local rows = {}
                for _, player in ipairs(result.players) do rows[#rows + 1] = { label = ('[%d] %s'):format(player.id, player.name), target = player.id } end
                ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'players', { title = 'Players online', align = 'top-left', elements = rows }, function(selected)
                    local target = selected.current.target
                    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'player', { title = 'Player ' .. target, align = 'top-left', elements = {
                        { label = 'Go to player', action = 'goto' }, { label = 'Kick with reason', action = 'kick' }
                    } }, function(choice)
                        if choice.current.action == 'kick' then dialog('Kick reason', function(reason) request('player', { target = target, action = 'kick', reason = reason }) end)
                        else request('player', { target = target, action = 'goto' }) end
                    end, function(_, playerMenu) playerMenu.close() end)
                end, function(_, playersMenu) playersMenu.close() end)
            end
        end, function(_, menu) menu.close() end)
    end)
end

RegisterNetEvent('egg_staff:open', open)
RegisterCommand('report', function(_, args)
    local message = table.concat(args, ' ')
    local send = function(text) request('report', { message = text }, function(result) ESX.ShowNotification(('Report #%d sent.'):format(result.id)) end) end
    if message == '' then dialog('What happened?', send) else send(message) end
end, false)
RegisterNetEvent('egg_staff:duty', function(on) ESX.ShowNotification(on and 'Staff duty started.' or 'Staff duty ended.') end)
