Config = {}
Config.PoliceJobs = { police = true, sheriff = true }
Config.RewardAccount = 'black_money'
Config.Dispatch = true
Config.MarkerDistance = 25.0
Config.InteractDistance = 2.0
Config.SessionLifetime = 25 * 60
Config.CancelOnDeath = true
Config.RequireArmedStore = true
Config.MaxVehicleSpeed = 2.0 -- m/s at delivery or rope connection
Config.CrimeDesk = { x = 1181.69, y = -1271.59, z = 34.92 }
Config.ChopDesk = { x = 2344.53, y = 3126.61, z = 48.21 }
Config.GangDesk = { x = -1566.51, y = -403.69, z = 41.99 }
Config.MissionBlip = { sprite = 1, colour = 5 }
Config.Rope = { pullDistance = 12.0, maxDistance = 60.0, model = 'prop_atm_01', vehicleClasses = { [0]=true, [1]=true, [2]=true, [3]=true, [4]=true, [9]=true, [10]=true, [11]=true, [12]=true } }
Config.Locations = {
    mail = {
        { id = 'vespucci_mail', label = 'Vespucci post boxes', coords = { x = -1124.05, y = -1560.46, z = 4.39 }, police = 0, seconds = 18, cooldown = 600, minPay = 40, maxPay = 110, xp = 3 },
        { id = 'mirror_mail', label = 'Mirror Park post boxes', coords = { x = 1261.66, y = -429.06, z = 69.81 }, police = 0, seconds = 18, cooldown = 600, minPay = 40, maxPay = 110, xp = 3 }
    },
    store = {
        { id = 'grove_store', label = 'Davis convenience store', coords = { x = 28.29, y = -1339.28, z = 29.50 }, police = 2, seconds = 70, cooldown = 1500, minPay = 600, maxPay = 950, xp = 18 },
        { id = 'sandy_store', label = 'Sandy convenience store', coords = { x = 1960.67, y = 3748.25, z = 32.34 }, police = 2, seconds = 70, cooldown = 1500, minPay = 600, maxPay = 950, xp = 18 }
    },
    house = {
        { id = 'mirror_house', label = 'Mirror Park burglary', coords = { x = 1269.02, y = -423.49, z = 69.81 }, police = 2, seconds = 95, cooldown = 1800, minPay = 800, maxPay = 1300, xp = 25 },
        { id = 'sandy_house', label = 'Sandy Shores burglary', coords = { x = 1436.77, y = 3657.52, z = 34.36 }, police = 2, seconds = 95, cooldown = 1800, minPay = 800, maxPay = 1300, xp = 25 }
    },
    atm = {
        { id = 'vespucci_atm', label = 'Vespucci ATM', coords = { x = -1305.39, y = -706.34, z = 25.32 }, police = 3, seconds = 25, cooldown = 2400, minPay = 1000, maxPay = 1800, xp = 30 },
        { id = 'sandy_atm', label = 'Sandy Shores ATM', coords = { x = 1968.12, y = 3743.57, z = 32.34 }, police = 3, seconds = 25, cooldown = 2400, minPay = 1000, maxPay = 1800, xp = 30 }
    },
    heist = {
        { id = 'fleeca', label = 'Fleeca cashroom', coords = { x = 310.79, y = -283.44, z = 54.17 }, police = 3, seconds = 180, cooldown = 5400, minPay = 4500, maxPay = 6500, xp = 65, level = 2, stages = { 'Bypass the terminal', 'Open the cashroom', 'Bag the cash' } },
        { id = 'bobcat', label = 'Bobcat depot consignment', coords = { x = 914.96, y = -2117.57, z = 30.47 }, police = 4, seconds = 210, cooldown = 7200, minPay = 8000, maxPay = 12000, xp = 100, level = 4, requires = 'fleeca', stages = { 'Disarm the depot alarm', 'Open the freight lock', 'Load the consignment' } },
        { id = 'pacific', label = 'Pacific cashroom', coords = { x = 253.47, y = 228.39, z = 101.68 }, police = 5, seconds = 240, cooldown = 10800, minPay = 15000, maxPay = 21000, xp = 150, level = 6, requires = 'bobcat', stages = { 'Bypass the security circuit', 'Open the cashroom', 'Bag the reserve' } }
    }
}
Config.Boost = {
    classes = {
        D = { level=1, model='blista', police=0, fee=100, minPay=700, maxPay=1000, xp=20 },
        C = { level=2, model='sultan', police=1, fee=250, minPay=1400, maxPay=1900, xp=35 },
        B = { level=3, model='buffalo', police=2, fee=500, minPay=2500, maxPay=3300, xp=50 },
        A = { level=5, model='elegy', police=3, fee=1000, minPay=4200, maxPay=5500, xp=75 },
        S = { level=8, model='comet2', police=4, fee=1800, minPay=7000, maxPay=9000, xp=100 }
    },
    spawns = {
        { x=1544.13, y=3752.59, z=34.05, heading=210.0 },
        { x=1733.51, y=3309.28, z=41.22, heading=190.0 },
        { x=-1149.61, y=-2033.68, z=13.16, heading=135.0 }
    },
    delivery = { x=2342.19, y=3132.12, z=48.21 },
    cooldown = 900,
    unlockSeconds = 30
}
Config.Chop = { seconds=75, cooldown=600, model='emperor', minPay=650, maxPay=1050, xp=15, spawns=Config.Boost.spawns, delivery=Config.Boost.delivery }
Config.Events = {
    interval = 45 * 60, lifetime = 15 * 60, seconds = 60, police = 1, minPay = 1500, maxPay = 2600, xp = 35,
    sites = {
        { x=2351.02, y=2524.25, z=46.67 },
        { x=1718.18, y=4791.56, z=41.94 },
        { x=-1046.11, y=4916.90, z=213.0 }
    }
}
Config.Gangs = {
    allowed = { 'ballas', 'families', 'vagos', 'lost', 'triads' },
    captureSeconds = 180, captureCooldown = 3600, missionCooldown = 1800, missionSeconds = 40, treasuryPay = 1000, playerPay = 500,
    turf = {
        { id='davis', label='Davis', coords={x=105.55,y=-1940.36,z=20.80}, radius=70.0 },
        { id='rancho', label='Rancho', coords={x=480.40,y=-1866.71,z=26.69}, radius=75.0 },
        { id='east_vinewood', label='East Vinewood', coords={x=895.49,y=-130.18,z=76.80}, radius=65.0 },
        { id='stab_city', label='Stab City', coords={x=72.23,y=3704.14,z=39.75}, radius=80.0 }
    },
    missionPickup = { x=1392.92,y=3607.28,z=34.98 },
    missionDelivery = { x=-1566.51,y=-403.69,z=41.99 }
}
-- Furnished GTA apartment. No shell or custom map resource is needed.
Config.House = {
    bucketBase = 400000,
    entry = { x=266.06, y=-1007.40, z=-101.00, heading=357.0 },
    exit = { x=266.06, y=-1007.40, z=-101.00 },
    roomRadius = 24.0,
    searchRadius = 2.0,
    searchSeconds = 35,
    searchesPerJob = 3,
    searchPoints = {
        { label='Kitchen cupboards', coords={x=265.60,y=-995.80,z=-101.00} },
        { label='Bedroom drawers', coords={x=261.50,y=-1002.65,z=-101.00} },
        { label='Lounge cabinet', coords={x=262.55,y=-998.10,z=-101.00} },
        { label='Wardrobe', coords={x=259.80,y=-1004.15,z=-101.00} }
    }
}
