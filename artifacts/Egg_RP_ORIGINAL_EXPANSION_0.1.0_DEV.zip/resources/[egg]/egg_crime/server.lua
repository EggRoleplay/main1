local ESX = exports.es_extended:getSharedObject()
local Core = EggCore
local Sessions, Busy, Members, Turf, Cooldowns, Complete = {}, {}, {}, {}, {}, {}
local Event, serial, ready = nil, 0, false
local HouseReturns = {}
local function fail(message) return { ok=false, error=message } end
local function player(src) return ESX.GetPlayerFromId(src) end
local function notify(src, message) Core:Notify(src, message) end
local function identifier(src) return Core:Identifier(src) end
local function near(src, pos, radius) return Core:RequireNear(src, pos, radius or 4.0) end
local function countPolice()
    local count=0
    for _, id in ipairs(GetPlayers()) do
        local p=player(tonumber(id))
        if p and p.job and Config.PoliceJobs[p.job.name] then count=count+1 end
    end
    return count
end
local function policeOK(n) return countPolice() >= (n or 0) end
local function dispatch(src, label, pos)
    if not Config.Dispatch then return end
    if GetResourceState('egg_dispatch') == 'started' then exports.egg_dispatch:Dispatch(src, label, 'police', pos)
    else print('[egg_crime] Emergency dispatch is not running; check egg.cfg.') end
    Core:Log(src, 'crime', label)
end
local function allowedGang(gang)
    for _, name in ipairs(Config.Gangs.allowed) do if name==gang then return true end end
    return false
end
local function cooldown(key, seconds)
    if (Cooldowns[key] or 0)>os.time() then return false, Cooldowns[key]-os.time() end
    local expires=os.time()+seconds
    MySQL.update.await('INSERT INTO egg_crime_cooldowns (cooldown_key, expires) VALUES (?, ?) ON DUPLICATE KEY UPDATE expires=VALUES(expires)', {key, expires})
    Cooldowns[key]=expires
    if not Core:SessionAlive() then return false end
    return true
end
local function definition(kind, id)
    for _, row in ipairs(Config.Locations[kind] or {}) do if row.id==id then return row end end
end
local function restoreHouse(src, session, dropping)
    local saved=session and session.house or HouseReturns[src]
    if not saved then return end
    HouseReturns[src]=nil
    local ped=GetPlayerPed(src)
    -- On a disconnect ESX may already have saved the interior position. Keep the
    -- recovery row until this identifier loads again, regardless of event ordering.
    if Core:SessionAlive() and identifier(src)==saved.identifier and ped and ped~=0 and DoesEntityExist(ped) then
        SetPlayerRoutingBucket(src,saved.previousBucket)
        SetEntityCoords(ped,saved.returnCoords.x,saved.returnCoords.y,saved.returnCoords.z,false,false,false,false)
        SetEntityHeading(ped,saved.returnCoords.heading or 0.0)
        if not dropping then TriggerClientEvent('egg_crime:houseExit',src,saved.returnCoords) end
    end
    if not dropping and identifier(src)==saved.identifier then
        MySQL.update('DELETE FROM egg_crime_house_returns WHERE identifier=?',{saved.identifier})
    end
end
local function recoverHouse(src)
    local id=identifier(src)
    if not id then return end
    local row=MySQL.single.await('SELECT return_coords, previous_bucket FROM egg_crime_house_returns WHERE identifier=?',{id})
    if not row then return end
    if identifier(src)~=id then return end
    local saved=json.decode(row.return_coords)
    if type(saved)~='table' or type(saved.x)~='number' or type(saved.y)~='number' or type(saved.z)~='number' then return end
    -- Recovery positions originate from the validated server door entry, never a client payload.
    HouseReturns[src]={identifier=id,returnCoords=saved,previousBucket=tonumber(row.previous_bucket) or 0}
    restoreHouse(src,nil,false)
end
local function destroySession(src,dropping,expectedSession)
    if expectedSession and Sessions[src] ~= expectedSession then return false end
    local s=Sessions[src]
    if not s then return end
    Sessions[src]=nil
    if s.key then Busy[s.key]=nil end
    if s.vehicle and DoesEntityExist(s.vehicle) then DeleteEntity(s.vehicle) end
    if s.house then restoreHouse(src,s,dropping) end
    TriggerClientEvent('egg_crime:ended', src)
end
local function setSession(src, kind, def, key)
    serial=serial+1
    local s={ id=tostring(os.time())..':'..serial, kind=kind, def=def, key=key, created=os.time(), stage=1, stageReady=os.time()+def.seconds, coords=def.coords, identifier=identifier(src), working=true }
    Sessions[src]=s
    if key then Busy[key]=src end
    return s
end
local function publicSession(s)
    return { id=s.id, kind=s.kind, label=s.def.label or s.kind, coords=s.coords, stage=s.stage, seconds=math.max(0,s.stageReady-os.time()), stageLabel=s.def.stages and s.def.stages[s.stage] or nil, netId=s.vehicle and NetworkGetNetworkIdFromEntity(s.vehicle) or nil, gang=s.gang, working=s.working, houseExit=s.house and Config.House.exit or nil, searchLabel=s.house and s.searches[s.stage].label or nil, searches=s.house and #s.searches or nil }
end
local function current(src, data)
    if not Core:SessionAlive() then return nil end
    if type(data)~='table' then return nil end
    local s=Sessions[src]
    if not s or type(data.id)~='string' or data.id~=s.id then return nil end
    if s.identifier~=identifier(src) then destroySession(src); return nil end
    if os.time()-s.created>Config.SessionLifetime then destroySession(src); return nil end
    local ped=GetPlayerPed(src)
    if not ped or ped==0 or (Config.CancelOnDeath and GetEntityHealth(ped)<=0) then destroySession(src); return nil end
    return s
end
local function pay(src, s)
    if not Core:SessionAlive() or identifier(src)~=s.identifier or Sessions[src]~=s then return fail('Your character changed during that job.') end
    destroySession(src) -- consume before any account or inventory operation; replay cannot pay again
    local amount=math.random(s.def.minPay or 0,s.def.maxPay or 0)
    if amount>0 then Core:Credit(src, amount, Config.RewardAccount) end
    Core:AddXP(src, s.kind=='boost' and 'boosting' or 'crime', s.def.xp or 5)
    if s.kind=='mail' then Core:AddItem(src,'egg_stolen_mail',1)
    elseif s.kind=='house' then Core:AddItem(src,'egg_stolen_goods',1)
    elseif s.kind=='chop' then
        Core:AddItem(src,'egg_scrap',math.random(3,6))
        Core:AddItem(src,'egg_copper',math.random(1,3))
    end
    Core:Log(src,'crime',('%s completed; cash %d'):format(s.kind,amount))
    return { ok=true, completed=true, message=('Job complete. $%s paid.'):format(amount) }
end
local function spawnContract(src, kind, class)
    local def
    if kind=='boost' then
        def=Config.Boost.classes[class]
        if not def then return fail('Choose a valid boost class.') end
        local skill=Core:GetSkill(src,'boosting')
        if (skill.level or 1)<def.level then return fail(('Boosting level %d required.'):format(def.level)) end
    else def=Config.Chop end
    if not policeOK(def.police or 0) then return fail('There are not enough police in the city.') end
    local accepted=cooldown(identifier(src)..':'..kind,kind=='boost' and Config.Boost.cooldown or Config.Chop.cooldown)
    if not accepted then return fail('Your contact is still arranging the next vehicle.') end
    if def.fee and not Core:TryDebit(src,def.fee,'bank') then
        Cooldowns[identifier(src)..':'..kind]=0
        MySQL.update.await('DELETE FROM egg_crime_cooldowns WHERE cooldown_key=?',{identifier(src)..':'..kind})
        return fail('You cannot cover the contract deposit.')
    end
    local spawns=kind=='boost' and Config.Boost.spawns or Config.Chop.spawns
    local pos=spawns[math.random(#spawns)]
    local vehicle=CreateVehicleServerSetter(joaat(def.model),'automobile',pos.x,pos.y,pos.z,pos.heading)
    if not vehicle or vehicle==0 or not DoesEntityExist(vehicle) then
        if def.fee then Core:Credit(src,def.fee,'bank') end
        Cooldowns[identifier(src)..':'..kind]=0
        MySQL.update.await('DELETE FROM egg_crime_cooldowns WHERE cooldown_key=?',{identifier(src)..':'..kind})
        return fail('The contact could not source a vehicle. Your deposit was returned.')
    end
    local jobDef={ label=kind=='boost' and ('Class '..class..' vehicle contract') or 'Public salvage contract', seconds=kind=='boost' and Config.Boost.unlockSeconds or 15, coords={x=pos.x,y=pos.y,z=pos.z}, minPay=def.minPay,maxPay=def.maxPay,xp=def.xp,police=def.police or 0 }
    if not Core:SessionAlive() then DeleteEntity(vehicle); return fail('Your character changed before the vehicle arrived.') end
    local s=setSession(src,kind,jobDef)
    s.vehicle=vehicle
    s.working=false
    s.pickup=s.coords
    s.delivery=kind=='boost' and Config.Boost.delivery or Config.Chop.delivery
    local plate=('EGG%05d'):format(serial%100000)
    SetVehicleNumberPlateText(vehicle,plate)
    s.plate=plate
    Entity(vehicle).state:set('eggCrimeContract',s.id,true)
    Entity(vehicle).state:set('eggCrimeOwner',src,true)
    Entity(vehicle).state:set('eggCrimeLocked',true,true)
    return { ok=true, session=publicSession(s), message='A marked target is on your GPS. The deposit is a contract fee.' }
end
local function turfById(id)
    for _, row in ipairs(Config.Gangs.turf) do if row.id==id then return row end end
end
local function enemyNear(src, s)
    for _, id in ipairs(GetPlayers()) do
        local other=tonumber(id)
        local gang=Members[identifier(other)]
        if gang and gang~=s.gang and near(other,s.coords,s.def.radius) then return true end
    end
    return false
end

MySQL.ready(function()
    for _, row in ipairs(MySQL.query.await('SELECT cooldown_key, expires FROM egg_crime_cooldowns WHERE expires>?',{os.time()})) do Cooldowns[row.cooldown_key]=tonumber(row.expires) end
    for _, row in ipairs(MySQL.query.await('SELECT identifier, gang FROM egg_gang_members')) do Members[row.identifier]=row.gang end
    for _, row in ipairs(MySQL.query.await('SELECT turf_id, gang FROM egg_gang_turf')) do Turf[row.turf_id]=row.gang end
    for _, row in ipairs(MySQL.query.await('SELECT identifier, heist FROM egg_heist_progress')) do Complete[row.identifier]=Complete[row.identifier] or {}; Complete[row.identifier][row.heist]=true end
    ready=true
end)

Core:RegisterAction('crime:status',{cooldown=1000},function(src)
    if not ready then return fail('Crime records are still loading. Import sql/40_crime.sql if this continues.') end
    local gang=Members[identifier(src)]
    local treasury=gang and MySQL.scalar.await('SELECT balance FROM egg_gang_treasury WHERE gang=?',{gang}) or 0
    return { ok=true, session=Sessions[src] and publicSession(Sessions[src]) or nil, gang=gang, turf=Turf, event=Event, treasury=tonumber(treasury) or 0, crimeLevel=Core:GetSkill(src,'crime').level, boostLevel=Core:GetSkill(src,'boosting').level }
end)
Core:RegisterAction('crime:start',{cooldown=1000},function(src,xPlayer,data)
    if not ready then return fail('Crime records are still loading.') end
    if type(data)~='table' or type(data.kind)~='string' then return fail('Invalid request.') end
    return Core:WithLock('crime:player:'..identifier(src),function()
        if Sessions[src] then return fail('Finish or cancel your current job first.') end
        local kind=data.kind
        if kind=='boost' or kind=='chop' then
            if not near(src,kind=='boost' and Config.CrimeDesk or Config.ChopDesk,4.0) then return fail('Visit the contact to accept a contract.') end
            return spawnContract(src,kind,data.class)
        elseif kind=='gangmission' then
            local gang=Members[identifier(src)]
            if not gang then return fail('You are not a registered gang member.') end
            if not near(src,Config.GangDesk,4.0) then return fail('Speak to the gang contact.') end
            if not cooldown(identifier(src)..':gangmission',Config.Gangs.missionCooldown) then return fail('The contact has no new work yet.') end
            local s=setSession(src,kind,{label='Collect the consignment',coords=Config.Gangs.missionPickup,seconds=Config.Gangs.missionSeconds})
            s.gang=gang; s.working=false
            return {ok=true,session=publicSession(s)}
        elseif kind=='turf' then
            local zone=turfById(data.location)
            local gang=Members[identifier(src)]
            if not zone or not gang then return fail('Only a registered gang can claim turf.') end
            if not near(src,zone.coords,zone.radius) then return fail('Enter the turf before claiming it.') end
            if Turf[zone.id]==gang then return fail('Your gang already controls this turf.') end
            return Core:WithLock('crime:turf:'..zone.id,function()
                if Busy['turf:'..zone.id] then return fail('This turf is being contested.') end
                if not cooldown('turf:'..zone.id,Config.Gangs.captureCooldown) then return fail('This turf is recovering from the last fight.') end
                local def={label='Claim '..zone.label,coords=zone.coords,seconds=Config.Gangs.captureSeconds,radius=zone.radius,id=zone.id}
                local s=setSession(src,kind,def,'turf:'..zone.id)
                s.gang=gang
                TriggerClientEvent('egg_crime:gangAlert',-1,gang..' is contesting '..zone.label)
                return {ok=true,session=publicSession(s)}
            end)
        elseif kind=='event' then
            if not Event or Event.expires<=os.time() then return fail('There is no active supply event.') end
            if not near(src,Event.coords,4.0) then return fail('Get closer to the supply crate.') end
            return Core:WithLock('crime:event',function()
                if Busy.event then return fail('Someone is opening the consignment.') end
                if not policeOK(Config.Events.police) then return fail('There are not enough police in the city.') end
                local def={label=Event.label,coords=Event.coords,seconds=Config.Events.seconds,minPay=Config.Events.minPay,maxPay=Config.Events.maxPay,xp=Config.Events.xp,police=Config.Events.police}
                local s=setSession(src,kind,def,'event'); s.eventId=Event.id
                dispatch(src,Event.label,Event.coords)
                return {ok=true,session=publicSession(s)}
            end)
        end
        local def=definition(kind,data.location)
        if not def then return fail('Unknown job location.') end
        if not near(src,def.coords,4.0) then return fail('Get closer to the target.') end
        if not policeOK(def.police) then return fail('There are not enough police in the city.') end
        if kind=='house' and GetVehiclePedIsIn(GetPlayerPed(src),false)~=0 then return fail('Leave your vehicle before entering a house.') end
        if kind=='store' and Config.RequireArmedStore and GetSelectedPedWeapon(GetPlayerPed(src))==joaat('WEAPON_UNARMED') then return fail('The clerk will not open the till without a threat.') end
        if def.level and (Core:GetSkill(src,'crime').level or 1)<def.level then return fail(('Crime level %d required.'):format(def.level)) end
        if def.requires and not (Complete[identifier(src)] or {})[def.requires] then return fail('Complete '..def.requires..' first.') end
        if kind=='house' or kind=='heist' or kind=='atm' then
            if not Core:HasItem(src,'egg_lockpick',1) then return fail('You need a lockpick.') end
        end
        return Core:WithLock('crime:location:'..def.id,function()
            if Busy[def.id] then return fail('Someone is already working this target.') end
            if not cooldown(def.id,def.cooldown) then return fail('This target was hit recently. Try another location.') end
            if kind=='house' or kind=='heist' or kind=='atm' then
                if not Core:RemoveItem(src,'egg_lockpick',1) then return fail('You need a lockpick.') end
            end
            local s=setSession(src,kind,def,def.id)
            if kind=='house' then
                local ped=GetPlayerPed(src)
                local position=GetEntityCoords(ped)
                local saved={identifier=s.identifier,previousBucket=GetPlayerRoutingBucket(src),bucket=Config.House.bucketBase+src,returnCoords={x=position.x,y=position.y,z=position.z,heading=GetEntityHeading(ped)}}
                s.house=saved; s.entering=true; HouseReturns[src]=saved
                local pool={}
                for _,point in ipairs(Config.House.searchPoints) do pool[#pool+1]=point end
                s.searches={}
                for i=1,math.min(Config.House.searchesPerJob,#pool) do
                    local chosen=math.random(#pool); s.searches[#s.searches+1]=table.remove(pool,chosen)
                end
                s.coords=s.searches[1].coords; s.working=false; s.stageReady=0
                MySQL.update.await('INSERT INTO egg_crime_house_returns (identifier, return_coords, previous_bucket) VALUES (?,?,?) ON DUPLICATE KEY UPDATE return_coords=VALUES(return_coords),previous_bucket=VALUES(previous_bucket)',{s.identifier,json.encode(saved.returnCoords),saved.previousBucket})
                if not Core:SessionAlive() or Sessions[src]~=s or identifier(src)~=s.identifier then return fail('The burglary could not be entered.') end
                SetRoutingBucketEntityLockdownMode(saved.bucket,'strict')
                SetRoutingBucketPopulationEnabled(saved.bucket,false)
                SetPlayerRoutingBucket(src,saved.bucket)
                SetEntityCoords(ped,Config.House.entry.x,Config.House.entry.y,Config.House.entry.z,false,false,false,false)
                SetEntityHeading(ped,Config.House.entry.heading)
                TriggerClientEvent('egg_crime:houseEnter',src,Config.House.entry)
                s.entering=false
            end
            if kind=='atm' then s.stageReady=os.time()+8; s.def={label=def.label,coords=def.coords,seconds=def.seconds,minPay=def.minPay,maxPay=def.maxPay,xp=def.xp,police=def.police} end
            if kind~='mail' then dispatch(src,def.label,def.coords) end
            return {ok=true,session=publicSession(s)}
        end)
    end)
end)

Core:RegisterAction('crime:work',{cooldown=1000},function(src,xPlayer,data)
    local s=current(src,data)
    if not s or s.working then return fail('There is no task ready to start.') end
    if not near(src,s.coords,5.0) then return fail('Get closer to the target.') end
    if s.kind~='gangmission' and s.kind~='house' and not ((s.kind=='boost' or s.kind=='chop') and s.stage==1) then return fail('This task does not need a work phase.') end
    if s.kind=='house' and (not s.house or GetPlayerRoutingBucket(src)~=s.house.bucket or not near(src,s.coords,Config.House.searchRadius)) then return fail('Stand beside the marked furniture inside the assigned house.') end
    s.working=true; s.stageReady=os.time()+(s.kind=='house' and Config.House.searchSeconds or s.def.seconds)
    return {ok=true,session=publicSession(s)}
end)
Core:RegisterAction('crime:rope',{cooldown=1000},function(src,xPlayer,data)
    local s=current(src,data)
    if not s or s.kind~='atm' or s.stage~=1 then return fail('You have no ATM job ready for a rope.') end
    if not near(src,s.coords,5.0) or os.time()<s.stageReady then return fail('Stay by the ATM while the casing is opened.') end
    local netId=tonumber(data.netId)
    if not netId or netId~=math.floor(netId) then return fail('Invalid tow vehicle.') end
    local vehicle=NetworkGetEntityFromNetworkId(netId)
    local ped=GetPlayerPed(src)
    if vehicle==0 or not DoesEntityExist(vehicle) or GetEntityType(vehicle)~=2 or GetPedInVehicleSeat(vehicle,-1)~=ped then return fail('Sit in the driver seat of your tow vehicle.') end
    local vpos=GetEntityCoords(vehicle)
    local distance=#(vpos-vector3(s.coords.x,s.coords.y,s.coords.z))
    if distance>8.0 or GetEntitySpeed(vehicle)>Config.MaxVehicleSpeed then return fail('Park your tow vehicle beside the ATM.') end
    local class=GetVehicleClass and GetVehicleClass(vehicle) or nil
    if class and not Config.Rope.vehicleClasses[class] then return fail('Use a road vehicle with a suitable tow point.') end
    s.tow=vehicle; s.towId=netId; s.stage=2; s.stageReady=os.time()+s.def.seconds; s.pullFrames=0
    return {ok=true,session=publicSession(s),rope=true,towId=netId,message='Rope attached. Pull slowly and keep the rope taut.'}
end)
Core:RegisterAction('crime:step',{cooldown=1000},function(src,xPlayer,data)
    return Core:WithLock('crime:step:'..src,function()
        local s=current(src,data)
        if not s then return fail('That job is no longer active.') end
        if not s.working or os.time()<s.stageReady then return fail('The work is not finished yet.') end
        if not policeOK(s.def.police or 0) then return fail('The job needs more police in the city.') end
        if s.kind=='house' then
            if not s.house or GetPlayerRoutingBucket(src)~=s.house.bucket or not near(src,s.coords,Config.House.searchRadius) then return fail('Finish the search at the marked furniture inside your assigned house.') end
            if s.stage<#s.searches then
                s.stage=s.stage+1; s.coords=s.searches[s.stage].coords; s.working=false; s.stageReady=0
                return {ok=true,session=publicSession(s),message='Search complete. Check the next marked cupboard.'}
            end
            return pay(src,s)
        elseif s.kind=='boost' or s.kind=='chop' then
            local v=s.vehicle
            if not v or not DoesEntityExist(v) or Entity(v).state.eggCrimeContract~=s.id or Entity(v).state.eggCrimeOwner~=src then destroySession(src); return fail('The contract vehicle is gone.') end
            local vehiclePos=GetEntityCoords(v)
            if s.stage==1 then
                if not near(src,s.pickup,5.0) or #(vehiclePos-vector3(s.pickup.x,s.pickup.y,s.pickup.z))>12.0 then return fail('Work on the marked vehicle at its pickup.') end
                s.stage=2; s.coords=s.delivery; s.stageReady=os.time()+10
                Entity(v).state:set('eggCrimeLocked',false,true)
                dispatch(src,'Stolen contract vehicle '..s.plate,s.pickup)
                return {ok=true,session=publicSession(s),message='The target is unlocked. Deliver it to the yard.'}
            end
            if not near(src,s.delivery,10.0) or #(vehiclePos-vector3(s.delivery.x,s.delivery.y,s.delivery.z))>8.0 then return fail('Bring the marked vehicle to the yard.') end
            if GetPedInVehicleSeat(v,-1)~=GetPlayerPed(src) or GetEntitySpeed(v)>Config.MaxVehicleSpeed then return fail('Stop in the yard while driving the contract vehicle.') end
            if s.kind=='chop' and s.stage==2 then
                s.stage=3; s.stageReady=os.time()+Config.Chop.seconds
                return {ok=true,session=publicSession(s),message='Salvage inspection started. Stay in the marked vehicle.'}
            end
            return pay(src,s)
        elseif s.kind=='atm' then
            if s.stage~=2 or not s.tow or not DoesEntityExist(s.tow) or GetPedInVehicleSeat(s.tow,-1)~=GetPlayerPed(src) then return fail('Return to your attached tow vehicle.') end
            local towDistance=#(GetEntityCoords(s.tow)-vector3(s.coords.x,s.coords.y,s.coords.z))
            if not near(src,s.coords,Config.Rope.maxDistance) or towDistance<Config.Rope.pullDistance or towDistance>Config.Rope.maxDistance or GetEntitySpeed(s.tow)>12.0 or (s.pullFrames or 0)<5 then return fail('Pull at least 12 metres slowly and hold tension on the rope.') end
            return pay(src,s)
        elseif s.kind=='turf' then
            if Members[identifier(src)]~=s.gang then destroySession(src); return fail('Your gang membership changed.') end
            if not near(src,s.coords,s.def.radius) or enemyNear(src,s) then return fail('Keep the turf clear of rival gangs until the claim finishes.') end
            MySQL.update.await('INSERT INTO egg_gang_turf (turf_id,gang,claimed_at) VALUES (?,?,?) ON DUPLICATE KEY UPDATE gang=VALUES(gang),claimed_at=VALUES(claimed_at)',{s.def.id,s.gang,os.time()})
            Turf[s.def.id]=s.gang
            MySQL.update.await('INSERT INTO egg_gang_treasury (gang,balance) VALUES (?,?) ON DUPLICATE KEY UPDATE balance=balance+VALUES(balance)',{s.gang,Config.Gangs.treasuryPay})
            destroySession(src,false,s); Core:AddXP(src,'crime',40)
            TriggerClientEvent('egg_crime:gangAlert',-1,s.gang..' now controls '..s.def.label:gsub('Claim ',''))
            return {ok=true,completed=true,message='Turf claimed. The payment went to your gang treasury.'}
        elseif s.kind=='gangmission' then
            if Members[identifier(src)]~=s.gang then destroySession(src); return fail('Your gang membership changed.') end
            if not near(src,s.coords,4.0) then return fail('Get closer to the consignment.') end
            if s.stage==1 then
                s.stage=2; s.coords=Config.Gangs.missionDelivery; s.stageReady=os.time()+Config.Gangs.missionSeconds; s.working=false
                return {ok=true,session=publicSession(s),message='Consignment collected. Take it to the contact.'}
            end
            MySQL.update.await('INSERT INTO egg_gang_treasury (gang,balance) VALUES (?,?) ON DUPLICATE KEY UPDATE balance=balance+VALUES(balance)',{s.gang,Config.Gangs.treasuryPay})
            destroySession(src,false,s); Core:Credit(src,Config.Gangs.playerPay,Config.RewardAccount); Core:AddXP(src,'crime',20)
            return {ok=true,completed=true,message='Delivery complete. Your gang treasury and your cut have been paid.'}
        end
        if not near(src,s.coords,4.0) then return fail('Stay close to the target to finish the job.') end
        if s.kind=='heist' and s.stage<#s.def.stages then
            s.stage=s.stage+1; s.stageReady=os.time()+s.def.seconds
            return {ok=true,session=publicSession(s)}
        end
        if s.kind=='heist' then
            MySQL.update.await('INSERT IGNORE INTO egg_heist_progress (identifier,heist) VALUES (?,?)',{s.identifier,s.def.id})
            Complete[s.identifier]=Complete[s.identifier] or {}; Complete[s.identifier][s.def.id]=true
        elseif s.kind=='event' then
            if not Event or Event.id~=s.eventId then destroySession(src); return fail('The supply event has ended.') end
            Event=nil; TriggerClientEvent('egg_crime:event',-1,nil)
        end
        return pay(src,s)
    end)
end)
Core:RegisterAction('crime:houseExit',{cooldown=1000},function(src)
    local s=Sessions[src]
    if not s or s.kind~='house' then return fail('You are not in a burglary house.') end
    destroySession(src)
    return {ok=true,completed=true,message='You left the house. Unfinished searches were abandoned.'}
end)
Core:RegisterAction('crime:cancel',{cooldown=1000},function(src) destroySession(src); return {ok=true,message='Job cancelled. Used equipment and contract fees are not returned.'} end)
Core:RegisterAction('crime:gangSet',{cooldown=1000,staff=true},function(src,xPlayer,data)
    if type(data)~='table' then return fail('Choose a player and gang.') end
    local target=tonumber(data.target)
    local gang=type(data.gang)=='string' and data.gang or ''
    if not target or not player(target) or (gang~='none' and not allowedGang(gang)) then return fail('Invalid player or gang.') end
    local id=identifier(target)
    if gang=='none' then MySQL.update.await('DELETE FROM egg_gang_members WHERE identifier=?',{id}); Members[id]=nil
    else MySQL.update.await('INSERT INTO egg_gang_members (identifier,gang) VALUES (?,?) ON DUPLICATE KEY UPDATE gang=VALUES(gang)',{id,gang}); Members[id]=gang end
    if not Core:SessionAlive() or identifier(target)~=id then return fail('That character left during the membership update.') end
    destroySession(target)
    Core:Log(src,'gang','Set player '..target..' gang to '..gang)
    notify(target,'Gang membership updated: '..gang)
    return {ok=true,message='Gang membership saved.'}
end)
RegisterCommand('eggsetgang',function(src,args)
    if src~=0 then notify(src,'Use the staff gang management menu or the server console.'); return end
    local target=tonumber(args[1]); local gang=args[2]
    if not target or not player(target) or (gang~='none' and not allowedGang(gang)) then print('Usage: eggsetgang <online player ID> <configured gang|none>'); return end
    local id=identifier(target)
    if gang=='none' then MySQL.update.await('DELETE FROM egg_gang_members WHERE identifier=?',{id}); Members[id]=nil
    else MySQL.update.await('INSERT INTO egg_gang_members (identifier,gang) VALUES (?,?) ON DUPLICATE KEY UPDATE gang=VALUES(gang)',{id,gang}); Members[id]=gang end
    if identifier(target)==id then destroySession(target); notify(target,'Gang membership updated: '..gang) end
end,true)
AddEventHandler('playerDropped',function() destroySession(source,true) end)
AddEventHandler('esx:playerLoaded',function(src)
    if not src then return end
    CreateThread(function()
        while not ready do Wait(100) end
        Wait(1000)
        recoverHouse(src)
    end)
end)
CreateThread(function()
    while not ready do Wait(100) end
    for _,id in ipairs(GetPlayers()) do recoverHouse(tonumber(id)) end
end)
AddEventHandler('onResourceStop',function(name)
    if name~=GetCurrentResourceName() then return end
    for src in pairs(Sessions) do destroySession(src) end
end)
CreateThread(function()
    while true do
        Wait(5000)
        for src,s in pairs(Sessions) do
            local ped=GetPlayerPed(src)
            if not player(src) or not ped or ped==0 or os.time()-s.created>Config.SessionLifetime or (Config.CancelOnDeath and GetEntityHealth(ped)<=0) then
                destroySession(src,not player(src))
            elseif s.kind=='house' and not s.entering then
                if not s.house or GetPlayerRoutingBucket(src)~=s.house.bucket or not near(src,Config.House.entry,Config.House.roomRadius) then
                    destroySession(src); notify(src,'You left the burglary interior.')
                elseif s.working and not near(src,s.coords,Config.House.searchRadius+0.5) then
                    s.working=false; s.stageReady=0
                    TriggerClientEvent('egg_crime:sessionUpdate',src,publicSession(s))
                    notify(src,'Search interrupted. Return to the marked furniture.')
                end
            elseif s.working and ((s.kind=='boost'  or s.kind=='chop') and s.stage==1 or s.kind=='gangmission') and not near(src,s.coords,12.0) then
                destroySession(src); notify(src,'Job abandoned because you left the work area.')
            elseif s.kind=='chop' and s.stage==3 and (not near(src,s.delivery,10.0) or not DoesEntityExist(s.vehicle) or GetPedInVehicleSeat(s.vehicle,-1)~=ped) then
                destroySession(src); notify(src,'Salvage inspection abandoned.')
            elseif s.kind=='turf' then
                if not near(src,s.coords,s.def.radius) then destroySession(src); notify(src,'Turf claim abandoned because you left the area.')
                elseif enemyNear(src,s) then
                    s.stageReady=s.stageReady+5
                    TriggerClientEvent('egg_crime:paused',src,math.max(0,s.stageReady-os.time()))
                end
            elseif s.kind=='atm' and s.stage==2 then
                if not s.tow or not DoesEntityExist(s.tow) or not near(src,s.coords,Config.Rope.maxDistance) then destroySession(src); notify(src,'The tow rope broke.')
                elseif GetPedInVehicleSeat(s.tow,-1)==ped then
                    local distance=#(GetEntityCoords(s.tow)-vector3(s.coords.x,s.coords.y,s.coords.z))
                    if distance>=Config.Rope.pullDistance and distance<=Config.Rope.maxDistance and GetEntitySpeed(s.tow)<=12.0 then s.pullFrames=(s.pullFrames or 0)+1 else s.pullFrames=0 end
                else s.pullFrames=0 end
            elseif (s.kind=='mail' or s.kind=='store' or s.kind=='heist' or s.kind=='event') and not near(src,s.coords,12.0) then
                destroySession(src); notify(src,'Job abandoned because you left the target.')
            end
        end
        if Event and Event.expires<=os.time() then
            if Busy.event then destroySession(Busy.event) end
            Event=nil; TriggerClientEvent('egg_crime:event',-1,nil)
        end
    end
end)
CreateThread(function()
    while not ready do Wait(1000) end
    while true do
        Wait(Config.Events.interval*1000)
        if #GetPlayers()>0 and not Event then
            local pos=Config.Events.sites[math.random(#Config.Events.sites)]
            Event={id=tostring(os.time()),kind=math.random(2)==1 and 'crash' or 'airdrop',coords=pos,expires=os.time()+Config.Events.lifetime}
            Event.label=Event.kind=='crash' and 'Downed cargo plane' or 'Unclaimed supply drop'
            TriggerClientEvent('egg_crime:event',-1,Event)
        end
    end
end)
