local ESX = exports.es_extended:getSharedObject()
local session, missionBlip, supply, eventBlip, wreck, crate, rope, atmProp = nil, nil, nil, nil, nil, nil, nil, nil
local requesting, deadline = false, 0
local function notify(message) ESX.ShowNotification(message) end
local function vector(pos) return vector3(pos.x,pos.y,pos.z) end
local function distance(pos) return #(GetEntityCoords(PlayerPedId())-vector(pos)) end
local function cleanupRope()
    if rope then DeleteRope(rope); rope=nil end
    if atmProp and DoesEntityExist(atmProp) then DeleteEntity(atmProp) end
    atmProp=nil
end
local function setSession(new)
    session=new
    if missionBlip then RemoveBlip(missionBlip); missionBlip=nil end
    if not new then cleanupRope(); ClearPedTasks(PlayerPedId()); return end
    ClearPedTasks(PlayerPedId())
    if new.working and new.kind~='turf' and new.kind~='atm' and not IsPedInAnyVehicle(PlayerPedId(),false) and distance(new.coords)<4.0 then
        TaskStartScenarioInPlace(PlayerPedId(),new.kind=='house' and 'PROP_HUMAN_BUM_BIN' or 'WORLD_HUMAN_WELDING',0,true)
    end
    deadline=GetGameTimer()+(new.seconds or 0)*1000
    missionBlip=AddBlipForCoord(new.coords.x,new.coords.y,new.coords.z)
    SetBlipSprite(missionBlip,Config.MissionBlip.sprite); SetBlipColour(missionBlip,Config.MissionBlip.colour)
    SetBlipRoute(missionBlip,new.kind~='house')
    BeginTextCommandSetBlipName('STRING'); AddTextComponentString(new.label); EndTextCommandSetBlipName(missionBlip)
end
local function action(name,data,callback)
    if requesting then return end
    requesting=true
    exports.egg_core:Action(name,data or {},function(result)
        requesting=false
        if not result.ok then notify(result.error or 'That action could not be completed.'); return end
        if result.session then setSession(result.session) end
        if result.completed then setSession(nil) end
        if result.message then notify(result.message) end
        if callback then callback(result) end
    end)
end
local function menu(name,title,elements,selected)
    if GetResourceState('esx_menu_default')~='started' then notify('The standard ESX menu resource is required for this menu.'); return end
    ESX.UI.Menu.CloseAll()
    ESX.UI.Menu.Open('default',GetCurrentResourceName(),name,{title=title,align='top-left',elements=elements},function(data,handle)
        handle.close(); selected(data.current)
    end,function(data,handle) handle.close() end)
end
local function classesMenu()
    local entries={}
    for _,class in ipairs({'D','C','B','A','S'}) do
        local def=Config.Boost.classes[class]
        entries[#entries+1]={label=('Class %s · level %d · $%s contract fee'):format(class,def.level,def.fee),value=class}
    end
    menu('boost','Vehicle contracts',entries,function(row) action('crime:start',{kind='boost',class=row.value}) end)
end
local function contactMenu()
    menu('contact','The contact',{
        {label='Vehicle boosting contracts',value='boost'},
        {label='View crime progression',value='progress'},
        {label='Cancel current job',value='cancel'}
    },function(row)
        if row.value=='boost' then classesMenu()
        elseif row.value=='cancel' then action('crime:cancel',{},function() setSession(nil) end)
        else action('crime:status',{},function(r) notify(('Crime level %s · boosting level %s'):format(r.crimeLevel,r.boostLevel)) end) end
    end)
end
local function gangMenu()
    action('crime:status',{},function(result)
        local rows={
            {label=('Gang: %s · treasury $%s'):format(result.gang or 'unaffiliated',result.treasury),value='info'},
            {label='Collect a consignment',value='gangmission'}
        }
        for _,zone in ipairs(Config.Gangs.turf) do
            rows[#rows+1]={label=('%s · %s'):format(zone.label,result.turf[zone.id] or 'unclaimed'),value='turf',zone=zone.id}
        end
        menu('gang','Gang business',rows,function(row)
            if row.value=='info' then return end
            action('crime:start',{kind=row.value,location=row.zone})
        end)
    end)
end
RegisterCommand('crime',function() contactMenu() end,false)
RegisterCommand('boost',classesMenu,false)
RegisterCommand('gang',gangMenu,false)
RegisterCommand('exitburglary',function() action('crime:houseExit') end,false)
RegisterCommand('cancelcrime',function() action('crime:cancel',{},function() setSession(nil) end) end,false)
RegisterCommand('gangstaff',function()
    local rows={}
    for _,id in ipairs(GetActivePlayers()) do rows[#rows+1]={label=('%s [%d]'):format(GetPlayerName(id),GetPlayerServerId(id)),value=GetPlayerServerId(id)} end
    menu('gang_player','Gang membership',rows,function(row)
        local target=row.value; local choices={{label='Remove membership',value='none'}}
        for _,gang in ipairs(Config.Gangs.allowed) do choices[#choices+1]={label=gang,value=gang} end
        menu('gang_choice','Set gang',choices,function(choice) action('crime:gangSet',{target=target,gang=choice.value}) end)
    end)
end,false)
RegisterNetEvent('egg_crime:ended',function() setSession(nil) end)
RegisterNetEvent('egg_crime:sessionUpdate',function(new) setSession(new) end)
local houseTransition=0
local function houseMove(coords)
    houseTransition=houseTransition+1
    local token=houseTransition
    local ped=PlayerPedId()
    ClearPedTasksImmediately(ped)
    FreezeEntityPosition(ped,true)
    DoScreenFadeOut(150)
    RequestCollisionAtCoord(coords.x,coords.y,coords.z)
    SetEntityCoords(ped,coords.x,coords.y,coords.z,false,false,false,false)
    SetEntityHeading(ped,coords.heading or 0.0)
    CreateThread(function()
        local expires=GetGameTimer()+7000
        while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer()<expires do
            RequestCollisionAtCoord(coords.x,coords.y,coords.z)
            Wait(25)
        end
        if token~=houseTransition then return end
        FreezeEntityPosition(ped,false)
        DoScreenFadeIn(250)
    end)
end
RegisterNetEvent('egg_crime:houseEnter',houseMove)
RegisterNetEvent('egg_crime:houseExit',houseMove)
RegisterNetEvent('egg_crime:paused',function(seconds)
    if session and session.kind=='turf' and type(seconds)=='number' then deadline=GetGameTimer()+seconds*1000 end
end)

RegisterNetEvent('egg_crime:gangAlert',function(message) notify(message) end)
local function loadModel(model)
    local hash=joaat(model)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local expires=GetGameTimer()+5000
    while not HasModelLoaded(hash) and GetGameTimer()<expires do Wait(20) end
    if not HasModelLoaded(hash) then return nil end
    return hash
end
local function clearEvent()
    if eventBlip then RemoveBlip(eventBlip); eventBlip=nil end
    if wreck and DoesEntityExist(wreck) then DeleteEntity(wreck) end
    if crate and DoesEntityExist(crate) then DeleteEntity(crate) end
    wreck=nil; crate=nil
end
RegisterNetEvent('egg_crime:event',function(event)
    clearEvent(); supply=event
    if not event then return end
    eventBlip=AddBlipForCoord(event.coords.x,event.coords.y,event.coords.z)
    SetBlipSprite(eventBlip,event.kind=='crash' and 307 or 478); SetBlipColour(eventBlip,5)
    BeginTextCommandSetBlipName('STRING'); AddTextComponentString(event.label); EndTextCommandSetBlipName(eventBlip)
    notify(event.label..' reported. Check your map.')
end)
local function createEventScene()
    if not supply or distance(supply.coords)>180.0 or crate then return end
    local model=loadModel('prop_box_wood02a_pu')
    if model then
        crate=CreateObject(model,supply.coords.x,supply.coords.y,supply.coords.z-1.0,false,false,false)
        PlaceObjectOnGroundProperly(crate); FreezeEntityPosition(crate,true); SetModelAsNoLongerNeeded(model)
    end
    if supply.kind=='crash' then
        local aircraft=loadModel('duster')
        if aircraft then
            wreck=CreateVehicle(aircraft,supply.coords.x+5.0,supply.coords.y+4.0,supply.coords.z,145.0,false,false)
            SetVehicleEngineHealth(wreck,-4000.0); SetVehicleBodyHealth(wreck,0.0)
            FreezeEntityPosition(wreck,true); SetVehicleUndriveable(wreck,true); SetModelAsNoLongerNeeded(aircraft)
        end
    end
end
local function attachRope(result)
    local s=session
    if not s or not result.towId then return end
    local vehicle=NetToVeh(result.towId)
    if vehicle==0 then notify('Tow vehicle is not streamed. The server still tracks the tow task.'); return end
    local model=loadModel(Config.Rope.model)
    if not model then notify('ATM model could not load. The server still tracks the tow task.'); return end
    cleanupRope()
    atmProp=CreateObject(model,s.coords.x,s.coords.y,s.coords.z-1.0,false,false,false)
    FreezeEntityPosition(atmProp,true); SetEntityCollision(atmProp,false,false); SetModelAsNoLongerNeeded(model)
    RopeLoadTextures()
    local expires=GetGameTimer()+3000
    while not RopeAreTexturesLoaded() and GetGameTimer()<expires do Wait(20) end
    if not RopeAreTexturesLoaded() then return end
    rope=AddRope(s.coords.x,s.coords.y,s.coords.z,0.0,0.0,0.0,Config.Rope.maxDistance,4,Config.Rope.maxDistance,1.0,1.0,false,false,false,1.0,true)
    if not rope then return end
    local tail=GetOffsetFromEntityInWorldCoords(vehicle,0.0,-2.4,0.4)
    AttachEntitiesToRope(rope,atmProp,vehicle,s.coords.x,s.coords.y,s.coords.z+0.4,tail.x,tail.y,tail.z,Config.Rope.maxDistance,false,false,nil,nil)
end
local function help(message) ESX.ShowHelpNotification(message) end
local function doWork()
    if not session then return end
    if not session.working then
        action('crime:work',{id=session.id})
    elseif session.kind=='atm' and session.stage==1 then
        local vehicle=GetVehiclePedIsIn(PlayerPedId(),false)
        if vehicle==0 then notify('Get in a parked road vehicle beside the ATM.'); return end
        if not Config.Rope.vehicleClasses[GetVehicleClass(vehicle)] then notify('Use a road vehicle with a suitable tow point.'); return end
        action('crime:rope',{id=session.id,netId=VehToNet(vehicle)},attachRope)
    else action('crime:step',{id=session.id}) end
end
CreateThread(function()
    Wait(3000)
    action('crime:status',{},function(result)
        if result.session then setSession(result.session) end
        if result.event then TriggerEvent('egg_crime:event',result.event) end
    end)
    while true do
        Wait(1000)
        createEventScene()
        if session and session.netId then
            local vehicle=NetToVeh(session.netId)
            if vehicle~=0 then
                local locked=Entity(vehicle).state.eggCrimeLocked
                SetVehicleDoorsLocked(vehicle,locked and 2 or 1)
            end
        end
    end
end)
CreateThread(function()
    while true do
        local sleep=800
        local closest,closestDistance=nil,Config.MarkerDistance
        local contacts={
            {coords=Config.CrimeDesk,label='Speak to the contact',open=contactMenu},
            {coords=Config.ChopDesk,label='Accept a salvage contract',open=function() action('crime:start',{kind='chop'}) end},
            {coords=Config.GangDesk,label='Gang business',open=gangMenu}
        }
        if session then
            local dist=distance(session.coords)
            if dist<80.0 or (session.kind=='turf' and dist<100.0) then
                sleep=0
                if session.houseExit then
                    DrawMarker(1,session.houseExit.x,session.houseExit.y,session.houseExit.z-1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.65,0.65,0.25,90,170,120,120,false,false,2,false,nil,nil,false)
                end
                DrawMarker(1,session.coords.x,session.coords.y,session.coords.z-1.0,0.0,0.0,0.0,0.0,0.0,0.0,1.0,1.0,0.35,230,179,65,120,false,false,2,false,nil,nil,false)
                if session.houseExit and distance(session.houseExit)<2.0 then
                    help('Press ~INPUT_CONTEXT~ to leave the house, or use /exitburglary.')
                    if IsControlJustReleased(0,38) then action('crime:houseExit') end
                end
                local limit=session.kind=='turf' and 80.0 or (session.kind=='atm' and session.stage==2) and Config.Rope.maxDistance or (session.kind=='boost' or session.kind=='chop' or session.kind=='atm') and 10.0 or 3.0
                if dist<limit and not (session.houseExit and distance(session.houseExit)<2.0) then
                    local seconds=math.max(0,math.ceil((deadline-GetGameTimer())/1000))
                    if not session.working then help(session.kind=='house' and ('Press ~INPUT_CONTEXT~ to search '..(session.searchLabel or 'the furniture')..'.') or 'Press ~INPUT_CONTEXT~ to start work at this target.')
                    elseif seconds>0 then help(('%s · %ss remaining. Stay in the area.'):format(session.searchLabel or session.stageLabel or session.label,seconds))
                    elseif session.kind=='atm' and session.stage==1 then help('Park beside the ATM and press ~INPUT_CONTEXT~ from the driver seat to attach a rope.')
                    else help('Press ~INPUT_CONTEXT~ to finish this stage. ~INPUT_DETONATE~ cancels the job.') end
                    if IsControlJustReleased(0,38) and (not session.working or seconds==0) then doWork() end
                    if IsControlJustReleased(0,47) then action('crime:cancel',{},function() setSession(nil) end) end
                end
            end
        else
            for _,contact in ipairs(contacts) do
                local dist=distance(contact.coords)
                if dist<closestDistance then closest=contact; closestDistance=dist end
            end
            for kind,locations in pairs(Config.Locations) do
                for _,location in ipairs(locations) do
                    local dist=distance(location.coords)
                    if dist<closestDistance then
                        local chosenKind,chosenId=kind,location.id
                        closest={coords=location.coords,label=location.label,open=function() action('crime:start',{kind=chosenKind,location=chosenId}) end}; closestDistance=dist
                    end
                end
            end
            for _,zone in ipairs(Config.Gangs.turf) do
                local dist=distance(zone.coords)
                if dist<closestDistance then local chosen=zone.id; closest={coords=zone.coords,label='Contest '..zone.label,open=function() action('crime:start',{kind='turf',location=chosen}) end}; closestDistance=dist end
            end
            if supply then
                local dist=distance(supply.coords)
                if dist<closestDistance then closest={coords=supply.coords,label='Open the supply crate',open=function() action('crime:start',{kind='event'}) end}; closestDistance=dist end
            end
            if closest then
                sleep=0
                DrawMarker(1,closest.coords.x,closest.coords.y,closest.coords.z-1.0,0.0,0.0,0.0,0.0,0.0,0.0,0.75,0.75,0.25,196,173,128,110,false,false,2,false,nil,nil,false)
                if closestDistance<Config.InteractDistance then
                    help('Press ~INPUT_CONTEXT~ · '..closest.label)
                    if IsControlJustReleased(0,38) then closest.open() end
                end
            end
        end
        Wait(sleep)
    end
end)
AddEventHandler('onResourceStop',function(name)
    if name~=GetCurrentResourceName() then return end
    houseTransition=houseTransition+1; FreezeEntityPosition(PlayerPedId(),false); DoScreenFadeIn(0)
    setSession(nil); clearEvent(); ESX.UI.Menu.CloseAll()
end)
