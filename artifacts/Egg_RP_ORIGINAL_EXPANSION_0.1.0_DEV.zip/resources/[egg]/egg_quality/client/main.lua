local ESX = exports.es_extended:getSharedObject()
local slingEnabled = Config.SlingDefault
local fpsEnabled = false
local sling, slingModel, lastWeapon, lastPed
local weaponModels, dice = {}, {}
local lastVoiceRefresh = -5000
for weapon, model in pairs(Config.SlingWeapons) do weaponModels[GetHashKey(weapon)] = GetHashKey(model) end

local function removeSling()
    if sling and DoesEntityExist(sling) then DeleteEntity(sling) end
    sling, slingModel = nil, nil
end

local function setFps(enabled)
    fpsEnabled = enabled
    SetReducePedModelBudget(enabled)
    SetReduceVehicleModelBudget(enabled)
end

RegisterCommand('sling', function()
    slingEnabled = not slingEnabled
    if not slingEnabled then removeSling() end
    SetResourceKvpInt('egg_sling', slingEnabled and 1 or 0)
    SetResourceKvpInt('egg_sling_saved', 1)
    ESX.ShowNotification(slingEnabled and 'Weapon sling on.' or 'Weapon sling off.')
end, false)

RegisterCommand('fps', function()
    setFps(not fpsEnabled)
    SetResourceKvpInt('egg_fps', fpsEnabled and 1 or 0)
    ESX.ShowNotification(fpsEnabled and 'Reduced visual detail on. Use /fps to switch it off.' or 'Normal visual detail restored.')
end, false)

RegisterCommand('resetvoice', function()
    if GetResourceState('pma-voice') ~= 'started' then
        ESX.ShowNotification('The voice helper needs pma-voice. Ask staff to check the voice resource.')
        return
    end
    if GetGameTimer() - lastVoiceRefresh < 5000 then return end
    lastVoiceRefresh = GetGameTimer()
    -- pma-voice has no public reconnect export. Its supported mute toggle
    -- resets local playback overrides; two toggles preserve the original mute.
    local refreshed = false
    for _, player in ipairs(GetActivePlayers()) do
        if player ~= PlayerId() then
            local serverId = GetPlayerServerId(player)
            local ok = pcall(function()
                exports['pma-voice']:toggleMutePlayer(serverId)
                exports['pma-voice']:toggleMutePlayer(serverId)
            end)
            refreshed = refreshed or ok
        end
    end
    -- Newer versions also provide getters for reapplying channel volume.
    local volumesOk = pcall(function()
        local radio = exports['pma-voice']:getRadioVolume()
        local call = exports['pma-voice']:getCallVolume()
        exports['pma-voice']:setRadioVolume(radio)
        exports['pma-voice']:setCallVolume(call)
    end)
    if refreshed or volumesOk then
        ESX.ShowNotification('Local voice playback refreshed. For microphone or connection trouble, reconnect.')
    else
        ESX.ShowNotification('Your pma-voice version does not support this helper. Ask staff to check it.')
    end
end, false)

RegisterCommand('staff', function() TriggerEvent('egg_staff:open') end, false)

CreateThread(function()
    if GetResourceKvpInt('egg_sling_saved') == 1 then slingEnabled = GetResourceKvpInt('egg_sling') == 1 end
    setFps(GetResourceKvpInt('egg_fps') == 1)
    while true do
        local ped = PlayerPedId()
        if ped ~= lastPed then removeSling(); lastWeapon, lastPed = nil, ped end
        local selected = GetSelectedPedWeapon(ped)
        if weaponModels[selected] then lastWeapon = selected end
        local shouldShow = slingEnabled and lastWeapon and selected ~= lastWeapon and HasPedGotWeapon(ped, lastWeapon, false) and not IsPedDeadOrDying(ped, true) and not IsPedInAnyVehicle(ped, false)
        if not shouldShow then
            removeSling()
        else
            local model = weaponModels[lastWeapon]
            if slingModel ~= model or not sling or not DoesEntityExist(sling) then
                removeSling()
                if IsModelInCdimage(model) and IsModelValid(model) then
                    RequestModel(model)
                    local deadline = GetGameTimer() + 3000
                    while not HasModelLoaded(model) and GetGameTimer() < deadline do Wait(50) end
                    if HasModelLoaded(model) then
                        local point = GetEntityCoords(ped)
                        -- A local cosmetic object cannot become an inventory weapon.
                        sling = CreateObject(model, point.x, point.y, point.z, false, false, false)
                        if sling ~= 0 then
                            slingModel = model
                            SetEntityCollision(sling, false, false)
                            local p, r = Config.SlingPosition, Config.SlingRotation
                            AttachEntityToEntity(sling, ped, GetPedBoneIndex(ped, Config.SlingBone), p.x, p.y, p.z, r.x, r.y, r.z, true, true, false, true, 1, true)
                        end
                        SetModelAsNoLongerNeeded(model)
                    end
                end
            end
        end
        Wait(slingEnabled and 350 or 1500)
    end
end)

CreateThread(function()
    while true do
        if fpsEnabled then
            SetLodScaleOverride(Config.FpsLodScale)
            SetDisableDecalRenderingThisFrame()
            Wait(0)
        else Wait(1500) end
    end
end)

RegisterNetEvent('egg_quality:roll', function(serverId, result, sides, message)
    if type(message) ~= 'string' or type(serverId) ~= 'number' or type(result) ~= 'number' or type(sides) ~= 'number' then return end
    ESX.ShowNotification(message)
    dice[serverId] = { result = result, sides = sides, expires = GetGameTimer() + 6000 }
end)

CreateThread(function()
    while true do
        local sleep, now = 800, GetGameTimer()
        for serverId, roll in pairs(dice) do
            if now >= roll.expires then dice[serverId] = nil
            else
                local player = GetPlayerFromServerId(serverId)
                if player ~= -1 then
                    local ped = GetPlayerPed(player)
                    local point = GetEntityCoords(ped)
                    local onScreen, x, y = World3dToScreen2d(point.x, point.y, point.z + 1.1)
                    if onScreen then
                        sleep = 0
                        SetTextScale(0.0, 0.30); SetTextFont(4); SetTextColour(242, 231, 199, 255); SetTextCentre(true); SetTextOutline()
                        BeginTextCommandDisplayText('STRING'); AddTextComponentSubstringPlayerName(('%d / %d'):format(roll.result, roll.sides)); EndTextCommandDisplayText(x, y)
                    end
                end
            end
        end
        Wait(sleep)
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    removeSling()
    setFps(false)
end)
