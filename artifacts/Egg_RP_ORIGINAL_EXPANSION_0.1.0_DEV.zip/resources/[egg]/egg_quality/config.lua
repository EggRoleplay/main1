Config = {}
Config.SlingDefault = true
Config.SlingBone = 24818
Config.SlingPosition = { x = 0.16, y = -0.18, z = -0.02 }
Config.SlingRotation = { x = 0.0, y = 160.0, z = 0.0 }
Config.SlingWeapons = {
    WEAPON_CARBINERIFLE = 'w_ar_carbinerifle',
    WEAPON_CARBINERIFLE_MK2 = 'w_ar_carbineriflemk2',
    WEAPON_ASSAULTRIFLE = 'w_ar_assaultrifle',
    WEAPON_ASSAULTRIFLE_MK2 = 'w_ar_assaultriflemk2',
    WEAPON_SPECIALCARBINE = 'w_ar_specialcarbine',
    WEAPON_PUMPSHOTGUN = 'w_sg_pumpshotgun',
    WEAPON_SMG = 'w_sb_smg',
}
Config.FpsLodScale = 0.65
Config.RollDistance = 15.0
Config.RollCooldown = 5000
Config.Afk = {
    enabled = true,
    sampleSeconds = 30,
    warningMinutes = 25,
    kickMinutes = 30,
    movementMetres = 2.0,
    -- ESX servers commonly represent off duty with a separate job name.
    -- If your duty system keeps the same name, expose job.onDuty explicitly.
    exemptJobs = { police = true, ambulance = true },
}
