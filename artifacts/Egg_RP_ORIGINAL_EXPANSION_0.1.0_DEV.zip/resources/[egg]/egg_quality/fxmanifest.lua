fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Egg RP sling, optional visual budget mode, voice helper and idle protection'
dependencies { 'es_extended', 'egg_core' }
shared_script 'config.lua'
client_script 'client/main.lua'
server_script 'server/main.lua'
