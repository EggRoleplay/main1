local ESX = exports.es_extended:getSharedObject()
local idle, rolls = {}, {}

local function exempt(source, player)
    if IsPlayerAceAllowed(source, 'egg.afk.bypass') or exports.egg_core:IsStaff(source) then return true end
    if GetResourceState('egg_staff') == 'started' then
        local ok, onDuty = pcall(function() return exports.egg_staff:IsOnDuty(source) end)
        if ok and onDuty then return true end
    end
    local job = player and player.job
    return job and Config.Afk.exemptJobs[job.name] == true and job.onDuty ~= false
end

CreateThread(function()
    if not Config.Afk.enabled then return end
    while true do
        Wait(math.max(5, Config.Afk.sampleSeconds) * 1000)
        local now = os.time()
        for _, rawSource in ipairs(GetPlayers()) do
            local source = tonumber(rawSource)
            local player, ped = ESX.GetPlayerFromId(source), GetPlayerPed(source)
            if not player or not ped or ped == 0 or not DoesEntityExist(ped) or exempt(source, player) then
                idle[source] = nil
            else
                local point = GetEntityCoords(ped)
                local state = idle[source]
                if not state or state.owner ~= player.identifier then
                    idle[source] = { x = point.x, y = point.y, z = point.z, lastMove = now, owner = player.identifier }
                else
                    local moved = (point.x - state.x)^2 + (point.y - state.y)^2 + (point.z - state.z)^2 >= Config.Afk.movementMetres^2
                    if moved then
                        state.x, state.y, state.z, state.lastMove, state.warned = point.x, point.y, point.z, now, false
                    elseif now - state.lastMove >= Config.Afk.kickMinutes * 60 then
                        exports.egg_core:Log(source, 'afk', 'Disconnected after idle movement timeout')
                        DropPlayer(source, ('You were idle for %d minutes. Reconnect when you’re ready to play.'):format(Config.Afk.kickMinutes))
                        idle[source] = nil
                    elseif not state.warned and now - state.lastMove >= Config.Afk.warningMinutes * 60 then
                        state.warned = true
                        exports.egg_core:Notify(source, ('You’ll be disconnected for inactivity in %d minutes. Move your character to stay connected.'):format(Config.Afk.kickMinutes - Config.Afk.warningMinutes))
                    end
                end
            end
        end
    end
end)

RegisterCommand('roll', function(source, args)
    if source == 0 then return end
    local player, ped = ESX.GetPlayerFromId(source), GetPlayerPed(source)
    if not player or ped == 0 or not DoesEntityExist(ped) then return end
    local now = GetGameTimer()
    if rolls[source] and now - rolls[source] < Config.RollCooldown then return end
    local sides = args[1] and tonumber(args[1]) or 6
    if not sides or sides % 1 ~= 0 or sides < 2 or sides > 100 then exports.egg_core:Notify(source, 'Use /roll or /roll 20. Dice can have 2–100 sides.'); return end
    rolls[source] = now
    local result = math.random(1, sides)
    local point = GetEntityCoords(ped)
    local name = (player.getName() or 'A local'):gsub('[%c<>]', ''):sub(1, 64)
    local message = ('%s rolled %d / %d'):format(name, result, sides)
    for _, rawTarget in ipairs(GetPlayers()) do
        local target = tonumber(rawTarget)
        if GetPlayerRoutingBucket(target) == GetPlayerRoutingBucket(source) and exports.egg_core:RequireNear(target, { x = point.x, y = point.y, z = point.z }, Config.RollDistance) then
            TriggerClientEvent('egg_quality:roll', target, source, result, sides, message)
        end
    end
end, false)

AddEventHandler('playerDropped', function() idle[source], rolls[source] = nil, nil end)
