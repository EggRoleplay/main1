'use strict';
const menu=document.getElementById('menu'), rows=document.getElementById('rows');
window.addEventListener('message', ({data})=>{
  if(!data || !['open','close'].includes(data.action)) return;
  menu.hidden=data.action==='close';
  if(menu.hidden) return;
  document.getElementById('title').textContent=String(data.title || '');
  const list=Array.isArray(data.rows)?data.rows:[];
  const index=Math.max(1,Math.min(list.length,Number(data.index)||1));
  document.getElementById('counter').textContent=list.length?`${index} / ${list.length}`:'0 / 0';
  const limit=Math.max(1,Math.min(14,Number(data.limit)||10));
  const start=Math.max(0,Math.min(index-Math.ceil(limit/2), list.length-limit));
  rows.replaceChildren();
  for(const item of list.slice(start,start+limit)){
    const row=document.createElement('div');
    row.className='row'; row.classList.toggle('selected',!!item.selected); row.classList.toggle('disabled',!!item.disabled);
    row.setAttribute('role','option'); row.setAttribute('aria-selected',String(!!item.selected));
    const label=document.createElement('span'); label.textContent=String(item.label||''); row.append(label);
    if(item.slider){const value=document.createElement('span');value.className='value';value.textContent=`‹ ${item.value??''} ›`;row.append(value);}
    rows.append(row);
  }
});
