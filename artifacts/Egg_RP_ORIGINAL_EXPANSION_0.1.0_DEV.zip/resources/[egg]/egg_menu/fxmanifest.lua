fx_version 'cerulean'
game 'gta5'
lua54 'yes'
name 'Egg RP | menu renderer'
version '0.1.0'
shared_script 'config.lua'
client_script 'client.lua'
ui_page 'web/index.html'
files { 'web/index.html', 'web/style.css', 'web/app.js' }
dependencies { 'es_extended', 'esx_menu_default' }
