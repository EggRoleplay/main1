local ESX = exports.es_extended:getSharedObject()
local previous, registered = nil, false
local menus, order = {}, {}
local function key(namespace, name) return namespace .. '\0' .. name end
local function callable(value)
    if type(value) == 'function' then return true end
    local meta = type(value) == 'table' and getmetatable(value) or nil
    return type(meta) == 'table' and type(meta.__call) == 'function'
end
local function title(value)
    return tostring(value or ''):gsub('<[^>]+>', ''):gsub('~[%w_]+~', ''):sub(1, 240)
end
local function current()
    return order[#order] and menus[order[#order]] or nil
end
local function selectable(element)
    return element and element.unselectable ~= true and element.usable ~= false
end
local function render()
    local menu = current()
    if not menu then SendNUIMessage({ action = 'close' }); return end
    local rows = {}
    for index, entry in ipairs(menu.elements) do
        local value
        if entry.type == 'slider' then
            value = entry.options and entry.options[(tonumber(entry.value) or 0) + 1] or entry.value
        end
        rows[index] = { label = title(entry.label), selected = index == menu.index,
            disabled = not selectable(entry), slider = entry.type == 'slider', value = value and title(value) or nil }
    end
    SendNUIMessage({ action = 'open', title = title(menu.title), rows = rows, index = menu.index, limit = Config.MaximumRows })
end
local function open(namespace, name, data)
    local id, selected = key(namespace, name), 1
    for index, entry in ipairs(data.elements or {}) do if entry.selected then selected = index; break end end
    local existing = menus[id]
    if existing then selected = math.min(existing.index, math.max(1, #(data.elements or {}))) end
    menus[id] = { namespace = namespace, name = name, title = data.title, elements = data.elements or {}, index = selected }
    for index = #order, 1, -1 do if order[index] == id then table.remove(order, index) end end
    order[#order + 1] = id
    render()
end
local function close(namespace, name)
    local id = key(namespace, name)
    menus[id] = nil
    for index = #order, 1, -1 do if order[index] == id then table.remove(order, index) end end
    render()
end
local function payload(menu)
    local opened = ESX.UI.Menu.GetOpened('default', menu.namespace, menu.name)
    if not opened then close(menu.namespace, menu.name); return nil end
    for index, entry in ipairs(menu.elements) do
        entry.selected = index == menu.index
        opened.setElement(index, 'selected', entry.selected)
        if entry.type == 'slider' then opened.setElement(index, 'value', entry.value) end
    end
    return { _namespace = menu.namespace, _name = menu.name, current = menu.elements[menu.index], elements = menu.elements }, opened
end
local function change(menu)
    local data, opened = payload(menu)
    if opened and callable(opened.change) then opened.change(data, opened) end
    render()
end
local function navigate(direction)
    local menu = current()
    if not menu or #menu.elements == 0 then return end
    for _ = 1, #menu.elements do
        menu.index = ((menu.index - 1 + direction) % #menu.elements) + 1
        if selectable(menu.elements[menu.index]) then break end
    end
    change(menu)
end
local function slide(direction)
    local menu = current()
    local entry = menu and menu.elements[menu.index]
    if not selectable(entry) or entry.type ~= 'slider' then return end
    local minimum, maximum = tonumber(entry.min) or 0, tonumber(entry.max) or 0
    if type(entry.options) == 'table' then minimum, maximum = 0, #entry.options - 1 end
    if maximum < minimum then return end
    entry.value = math.max(minimum, math.min(maximum, (tonumber(entry.value) or minimum) + direction))
    change(menu)
end
local function submit()
    local menu = current()
    if not menu or not selectable(menu.elements[menu.index]) then return end
    local data, opened = payload(menu)
    if opened and callable(opened.submit) then opened.submit(data, opened) end
end
local function cancel()
    local menu = current()
    if not menu then return end
    local opened = ESX.UI.Menu.GetOpened('default', menu.namespace, menu.name)
    if opened and callable(opened.cancel) then opened.cancel({ _namespace = menu.namespace, _name = menu.name }, opened)
    elseif opened then opened.close() else close(menu.namespace, menu.name) end
end

CreateThread(function()
    if not Config.Enabled then return end
    while GetResourceState('esx_menu_default') ~= 'started' do Wait(250) end
    ESX = exports.es_extended:getSharedObject()
    previous = ESX.UI.Menu.RegisteredTypes.default
    if not previous or not callable(previous.open) or not callable(previous.close) then
        print('[egg_menu] Standard ESX menu API missing. Original renderer retained.'); return
    end
    ESX.UI.Menu.CloseAll()
    ESX.UI.Menu.RegisterType('default', open, close)
    registered = true
    while true do
        if current() then
            DisableControlAction(0, 24, true); DisableControlAction(0, 25, true)
            for _, control in ipairs({ 172, 173, 174, 175, 176, 177 }) do DisableControlAction(0, control, true) end
            if IsDisabledControlJustReleased(0, 172) then navigate(-1) end
            if IsDisabledControlJustReleased(0, 173) then navigate(1) end
            if IsDisabledControlJustReleased(0, 174) then slide(-1) end
            if IsDisabledControlJustReleased(0, 175) then slide(1) end
            if IsDisabledControlJustReleased(0, 176) then submit() end
            if IsDisabledControlJustReleased(0, 177) then cancel() end
            Wait(0)
        else Wait(150) end
    end
end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    if registered and GetResourceState('esx_menu_default') == 'started' then
        ESX.UI.Menu.CloseAll()
        ESX.UI.Menu.RegisterType('default', previous.open, previous.close)
    end
    SendNUIMessage({ action = 'close' })
end)
