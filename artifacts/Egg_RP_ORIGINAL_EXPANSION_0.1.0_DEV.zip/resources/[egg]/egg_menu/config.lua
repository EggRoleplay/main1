Config = {}
-- Enable after testing the menus used by your existing scripts in staging.
Config.Enabled = false
Config.MaximumRows = 10
