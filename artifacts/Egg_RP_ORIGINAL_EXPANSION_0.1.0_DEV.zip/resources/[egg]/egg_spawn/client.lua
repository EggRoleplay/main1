local ESX = exports.es_extended:getSharedObject()
local active, waiting, generation = nil, false, 0
local cameras, currentCamera = {}, nil

local function notify(message) ESX.ShowNotification(message) end
local function stopCamera()
    RenderScriptCams(false, false, 0, true, true)
    for camera in pairs(cameras) do
        if DoesCamExist(camera) then DestroyCam(camera, false) end
    end
    cameras, currentCamera = {}, nil
    ClearFocus()
end
local function closeUi(reason)
    local previous = active
    active = nil
    SetNuiFocus(false, false)
    SendNUIMessage({ type = 'close' })
    stopCamera()
    if previous then
        if DoesEntityExist(previous.ped) then SetEntityVisible(previous.ped, true, false); FreezeEntityPosition(previous.ped, false) end
        DisplayRadar(not previous.radarWasHidden)
    end
    LocalPlayer.state:set('eggSpawnSelecting', false, false)
    TriggerEvent('egg_spawn:visibility', false)
    if reason == 'expired' then notify('Spawn selection closed. Your original login location has been kept.') end
end
local function preview(point)
    if not active or not point or not point.coords then return end
    local coords, offset = point.coords, Config.Camera
    RequestCollisionAtCoord(coords.x, coords.y, coords.z)
    SetFocusPosAndVel(coords.x, coords.y, coords.z, 0.0, 0.0, 0.0)
    local camera = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', coords.x + offset.x, coords.y + offset.y, coords.z + offset.z,
        0.0, 0.0, 0.0, offset.fov, true, 2)
    PointCamAtCoord(camera, coords.x, coords.y, coords.z + 1.0)
    cameras[camera] = true
    if currentCamera and DoesCamExist(currentCamera) then
        local old, token = currentCamera, active.token
        SetCamActiveWithInterp(camera, old, offset.moveMs, 1, 1)
        SetTimeout(offset.moveMs + 100, function()
            if active and active.token == token and cameras[old] and currentCamera ~= old then
                DestroyCam(old, false); cameras[old] = nil
            end
        end)
    else
        SetCamActive(camera, true)
        RenderScriptCams(true, false, 0, true, true)
    end
    currentCamera = camera
end
local function openUi(result)
    if type(result.token) ~= 'string' or type(result.choices) ~= 'table' or type(result.character) ~= 'table' then return false end
    local ped = PlayerPedId()
    if IsEntityDead(ped) then
        exports.egg_core:Action('spawn.cancel', { token = result.token }, function() end)
        return false
    end
    active = { token = result.token, choices = {}, ped = ped, busy = false, expires = GetGameTimer() + (tonumber(result.expiresIn) or 120) * 1000,
        radarWasHidden = IsRadarHidden() }
    local choices = {}
    for _, point in ipairs(result.choices) do
        active.choices[point.id] = point
        choices[#choices + 1] = { id = point.id, label = point.label, area = point.area, description = point.description, enabled = point.enabled == true }
    end
    local selected = active.choices[result.selected]
    if not selected or not selected.enabled then
        for _, point in ipairs(result.choices) do if point.enabled then selected = point; break end end
    end
    if not selected then
        closeUi()
        exports.egg_core:Action('spawn.cancel', { token = result.token }, function() end)
        return false
    end
    active.selected = selected.id
    FreezeEntityPosition(ped, true)
    SetEntityVisible(ped, false, false)
    DisplayRadar(false)
    LocalPlayer.state:set('eggSpawnSelecting', true, false)
    TriggerEvent('egg_spawn:visibility', true)
    preview(selected)
    SendNUIMessage({ type = 'open', character = result.character, choices = choices, selected = selected.id, canReselect = false })
    SetNuiFocus(true, true)
    SetCursorLocation(0.85, 0.52)
    return true
end
local function scheduleReady()
    if not Config.Enabled or waiting or active then return end
    waiting = true
    generation = generation + 1
    local attempt = generation
    CreateThread(function()
        Wait(Config.ReadyDelayMs)
        local deadline = GetGameTimer() + 20000
        while waiting and generation == attempt and GetGameTimer() < deadline do
            local ped = PlayerPedId()
            if DoesEntityExist(ped) and not IsEntityDead(ped) and IsPlayerPlaying(PlayerId()) then
                local response
                exports.egg_core:Action('spawn.ready', {}, function(result) response = result end)
                local responseDeadline = math.min(deadline, GetGameTimer() + 6000)
                while not response and waiting and generation == attempt and GetGameTimer() < responseDeadline do Wait(50) end
                if generation ~= attempt or not waiting then return end
                if response and response.ok then
                    waiting = false
                    openUi(response)
                    return
                end
            end
            Wait(Config.ReadyRetryMs)
        end
        if generation == attempt then waiting = false end
    end)
end

RegisterNetEvent('egg_spawn:eligible', scheduleReady)
AddEventHandler('esx:playerLoaded', scheduleReady)
RegisterNetEvent('egg_spawn:close', function(token, reason)
    if active and active.token == token then closeUi(reason) end
end)
AddEventHandler('esx:onPlayerLogout', function()
    generation = generation + 1
    waiting = false
    closeUi()
end)

RegisterNUICallback('select', function(data, cb)
    local point = active and type(data.id) == 'string' and active.choices[data.id]
    if not point or not point.enabled or active.busy then cb({ ok = false }); return end
    active.selected = point.id
    preview(point)
    cb({ ok = true })
end)
RegisterNUICallback('confirm', function(data, cb)
    if not active or active.busy or type(data.id) ~= 'string' or data.id ~= active.selected then cb({ ok = false, error = 'Select a starting point.' }); return end
    local session = active
    local token = session.token
    session.busy = true
    exports.egg_core:Action('spawn.confirm', { token = token, id = session.selected }, function(result)
        if not active or active.token ~= token then cb({ ok = false, error = 'Spawn selection has closed.' }); return end
        if not result.ok then active.busy = false; cb(result); return end
        cb({ ok = true })
        CreateThread(function()
            DoScreenFadeOut(200)
            Wait(250)
            if not active or active.token ~= token then
                if IsScreenFadedOut() then DoScreenFadeIn(0) end
                return
            end
            local point = result.coords
            stopCamera()
            RequestCollisionAtCoord(point.x, point.y, point.z)
            local deadline = GetGameTimer() + 5000
            while GetGameTimer() < deadline and not HasCollisionLoadedAroundEntity(PlayerPedId()) do
                RequestCollisionAtCoord(point.x, point.y, point.z)
                Wait(50)
            end
            if active and active.token == token then closeUi() end
            DoScreenFadeIn(500)
        end)
    end)
end)
RegisterNUICallback('cancel', function(_, cb)
    if not active or active.busy then cb({ ok = false }); return end
    local token = active.token
    active.busy = true
    exports.egg_core:Action('spawn.cancel', { token = token }, function(result)
        if result.ok then
            if active and active.token == token then closeUi() end
        elseif active and active.token == token then
            active.busy = false
            notify(result.error)
        end
        cb(result)
    end)
end)

CreateThread(function()
    while true do
        if active then
            local token = active.token
            if IsEntityDead(PlayerPedId()) or PlayerPedId() ~= active.ped or GetGameTimer() >= active.expires then
                closeUi()
                exports.egg_core:Action('spawn.cancel', { token = token }, function() end)
            end
            Wait(250)
        else Wait(1000) end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    generation = generation + 1
    waiting = false
    closeUi()
    if IsScreenFadedOut() then DoScreenFadeIn(0) end
end)
