(function () {
  'use strict';
  function cleanText(value, fallback) { return typeof value === 'string' && value.length ? value.slice(0, 120) : (fallback || ''); }
  function buildState(payload) {
    if (!payload || !Array.isArray(payload.choices) || !payload.character) return null;
    const seen = new Set();
    const choices = payload.choices.filter(point => point && typeof point.id === 'string' && /^[a-z_]+$/.test(point.id) && !seen.has(point.id) && seen.add(point.id))
      .map(point => ({ id: point.id, label: cleanText(point.label, 'Location'), area: cleanText(point.area), description: cleanText(point.description), enabled: point.enabled === true }));
    if (!choices.some(point => point.enabled)) return null;
    const selected = choices.find(point => point.id === payload.selected && point.enabled) || choices.find(point => point.enabled);
    return { choices, selected: selected.id, busy: false, selecting: false, character: {
      name: cleanText(payload.character.name, 'Your character'), dob: cleanText(payload.character.dob, '—'), employer: cleanText(payload.character.employer, 'Unemployed'),
    } };
  }
  function nextSelection(state, direction) {
    const allowed = state.choices.filter(point => point.enabled);
    if (!allowed.length) return null;
    const index = allowed.findIndex(point => point.id === state.selected);
    return allowed[(index + direction + allowed.length) % allowed.length].id;
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = { buildState, nextSelection };
  if (typeof document === 'undefined') return;

  const byId = id => document.getElementById(id);
  const screen = byId('spawn'), locations = byId('locations'), confirm = byId('confirm'), error = byId('error');
  let state = null;
  async function request(route, data) {
    if (typeof GetParentResourceName !== 'function') return { ok: false, error: 'Open this menu in the city.' };
    try {
      const result = await fetch(`https://${GetParentResourceName()}/${route}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data || {}) });
      return await result.json();
    } catch (_) { return { ok: false, error: 'The city did not respond. Try again.' }; }
  }
  function showError(message) { error.textContent = cleanText(message, 'Choose another location and try again.'); error.hidden = false; }
  function render() {
    if (!state) return;
    locations.replaceChildren();
    state.choices.forEach((point, index) => {
      const button = document.createElement('button');
      button.type = 'button'; button.className = `location${point.id === state.selected ? ' selected' : ''}`;
      button.disabled = !point.enabled || state.busy;
      button.setAttribute('role', 'option'); button.setAttribute('aria-selected', String(point.id === state.selected));
      button.setAttribute('aria-label', `${point.label}${point.enabled ? '' : ', unavailable'}`);
      const number = document.createElement('span'); number.className = 'number'; number.textContent = String(index + 1).padStart(2, '0');
      const label = document.createElement('span'); label.className = 'label'; label.textContent = point.label;
      const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); icon.setAttribute('viewBox', '0 0 12 12'); icon.setAttribute('aria-hidden', 'true'); icon.classList.add('chevron');
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path'); path.setAttribute('d', 'm4 2 4 4-4 4'); icon.append(path);
      button.append(number, label, icon); button.addEventListener('click', () => select(point.id)); locations.append(button);
    });
    const index = state.choices.findIndex(point => point.id === state.selected), point = state.choices[index];
    byId('location-count').textContent = `${String(index + 1).padStart(2, '0')} / ${String(state.choices.length).padStart(2, '0')}`;
    byId('selected-area').textContent = point.area; byId('selected-description').textContent = point.description;
    confirm.disabled = state.busy; confirm.querySelector('span').textContent = state.busy ? 'JOINING THE CITY…' : 'ENTER THE CITY';
  }
  async function select(id) {
    if (!state || state.busy || state.selecting || id === state.selected || !state.choices.some(point => point.id === id && point.enabled)) return;
    const expected = state;
    state.selecting = true;
    const result = await request('select', { id });
    if (state !== expected) return;
    state.selecting = false;
    if (result.ok) { state.selected = id; error.hidden = true; render(); }
    else showError(result.error);
  }
  async function enter() {
    if (!state || state.busy || state.selecting) return;
    const expected = state;
    state.busy = true; error.hidden = true; render();
    const result = await request('confirm', { id: state.selected });
    if (state !== expected) return;
    if (!result.ok) { state.busy = false; render(); showError(result.error); }
  }
  confirm.addEventListener('click', enter);
  window.addEventListener('message', event => {
    const message = event.data;
    if (!message || typeof message !== 'object') return;
    if (message.type === 'close') { state = null; screen.hidden = true; return; }
    if (message.type !== 'open') return;
    const next = buildState(message);
    if (!next) return;
    state = next;
    byId('character-name').textContent = state.character.name;
    byId('character-dob').textContent = state.character.dob;
    byId('character-employer').textContent = state.character.employer;
    screen.hidden = false; error.hidden = true; render();
  });
  document.addEventListener('keydown', event => {
    if (!state || state.busy || state.selecting) return;
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') { event.preventDefault(); select(nextSelection(state, event.key === 'ArrowDown' ? 1 : -1)); }
    else if (event.key === 'Enter') { event.preventDefault(); enter(); }
    else if (event.key === 'Escape') { event.preventDefault(); request('cancel', {}); }
  });
}());
