fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Egg Roleplay'
description 'Initial character login location selector with a live city camera'
version '0.1.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script '@egg_core/server_api.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
ui_page 'web/index.html'
files {
    'web/index.html', 'web/style.css', 'web/app.js',
    'web/fonts/BarlowCondensed-Regular.ttf', 'web/fonts/BarlowCondensed-SemiBold.ttf', 'web/fonts/OFL.txt',
}
dependencies { 'es_extended', 'oxmysql', 'egg_core' }
