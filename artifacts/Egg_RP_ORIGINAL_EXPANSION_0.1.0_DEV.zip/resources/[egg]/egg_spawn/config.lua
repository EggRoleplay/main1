Config = {}
-- Opt in only after checking the existing multicharacter/login sequence on staging.
Config.Enabled = false
Config.SessionSeconds = 120
Config.ReadyDelayMs = 1800
Config.ReadyRetryMs = 1000
Config.SaveIntervalSeconds = 30
Config.PreviewBucketBase = 600000
Config.DefaultPoint = 'alta'
Config.Camera = { x = 70.0, y = -95.0, z = 75.0, fov = 47.0, moveMs = 950 }
Config.World = { minX = -8000.0, maxX = 8000.0, minY = -6000.0, maxY = 10000.0, minZ = -10.0, maxZ = 1500.0 }

-- Last Location and Apartment are resolved server-side and complete the eight choices.
-- These six public arrival points are outside buildings and police secure areas.
Config.Points = {
    { id = 'alta', label = 'Alta Train Station', area = 'CITY CENTRE', description = 'A short walk from the shops and civic square.',
      coords = { x = -245.78, y = -990.82, z = 29.29, h = 338.0 } },
    { id = 'sandy', label = 'Sandy Shores', area = 'BLAINE COUNTY', description = 'Start out of town, near the main street.',
      coords = { x = 1850.88, y = 3683.39, z = 34.27, h = 214.0 } },
    { id = 'boardwalk', label = 'Boardwalk', area = 'WEST COAST', description = 'Beachfront paths and the pier are close by.',
      coords = { x = -1659.46, y = -1018.09, z = 13.01, h = 319.0 } },
    { id = 'paleto', label = 'Paleto Bay', area = 'NORTH COAST', description = 'Arrive on foot near the town centre.',
      coords = { x = -122.71, y = 6419.90, z = 31.42, h = 315.0 } },
    { id = 'lsia', label = 'LSIA Airport', area = 'SOUTH LOS SANTOS', description = 'The terminal forecourt. Welcome to the city.',
      coords = { x = -1036.74, y = -2733.95, z = 20.16, h = 328.0 } },
    { id = 'mrpd', label = 'MRPD', area = 'MISSION ROW', description = 'The public entrance to police headquarters.',
      coords = { x = 442.22, y = -982.75, z = 30.69, h = 91.0 } },
}
