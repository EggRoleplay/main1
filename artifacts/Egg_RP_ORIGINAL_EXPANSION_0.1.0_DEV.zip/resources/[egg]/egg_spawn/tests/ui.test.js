'use strict';
const assert = require('node:assert/strict');
const { buildState, nextSelection } = require('../web/app.js');

assert.equal(buildState(null), null);
assert.equal(buildState({ character: {}, choices: [] }), null);
assert.equal(buildState({ character: {}, choices: [{ id: 'last', enabled: false }] }), null);
const state = buildState({
  character: { name: '<img src=x onerror=alert(1)>', dob: '14/03/1995', employer: 'Victoria Police' },
  selected: 'last',
  choices: [
    { id: 'last', label: 'Last Location', enabled: false },
    { id: 'apartment', label: 'Apartment', enabled: false },
    { id: 'alta', label: 'Alta Train Station', enabled: true },
    { id: 'sandy', label: 'Sandy Shores', enabled: true },
    { id: 'alta', label: 'Duplicate', enabled: true },
    { id: '../../bad', label: 'Bad', enabled: true },
  ],
});
assert.equal(state.choices.length, 4, 'duplicate and malformed IDs are rejected');
assert.equal(state.selected, 'alta', 'disabled default falls back to an allowed location');
assert.equal(nextSelection(state, 1), 'sandy', 'keyboard navigation skips disabled choices');
assert.equal(nextSelection(state, -1), 'sandy', 'keyboard navigation wraps across enabled choices');
state.selected = 'sandy';
assert.equal(nextSelection(state, 1), 'alta');
assert.equal(state.character.name, '<img src=x onerror=alert(1)>', 'identity remains text; DOM rendering uses textContent');
const strict = buildState({ character: {}, selected: 'sandy', choices: [{ id: 'alta', enabled: 'true' }, { id: 'sandy', enabled: true }] });
assert.equal(strict.choices[0].enabled, false, 'an arbitrary truthy value cannot enable a location');
assert.equal(strict.character.employer, 'Unemployed');
console.log('Spawn UI checks passed: malformed input, duplicate IDs, disabled choices, keyboard wrapping, strict availability and identity text.');
