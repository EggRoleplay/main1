#!/usr/bin/env python3
"""Boundary checks using Lua 5.4 mocks, not a live FiveM server.

PYTHONPATH=/tmp/egg-validation python3 resources/'[egg]'/egg_spawn/tests/server_checks.py
Requires the repository's pinned test runtime, lupa==2.8.
"""
from pathlib import Path
from lupa.lua54 import LuaRuntime

RESOURCE = Path(__file__).resolve().parents[1]
lua = LuaRuntime(unpack_returned_tuples=True)
lua.execute((RESOURCE / 'config.lua').read_text())
lua.execute(r'''
Test = { actions={}, events={}, threads={}, players={}, positions={}, buckets={}, clients={}, saved={}, persists={}, exports={}, moves=0, time=100, home=nil, awaitHook=nil }
os.time=function() return Test.time end
function GetGameTimer() return Test.time*1000 end
function Wait() coroutine.yield() end
function CreateThread(fn) Test.threads[#Test.threads+1]=coroutine.create(fn) end
function AddEventHandler(name,fn) Test.events[name]=fn end
function TriggerClientEvent(name,src,...) Test.clients[#Test.clients+1]={name=name,source=src,args={...}} end
function GetCurrentResourceName() return 'egg_spawn' end
function GetResourceState(name) return name=='egg_city' and 'started' or 'missing' end
function GetPlayers() local out={} for src in pairs(Test.players) do out[#out+1]=tostring(src) end return out end
function GetPlayerPed(src) return Test.players[src] and src+1000 or 0 end
function DoesEntityExist(ped) return Test.players[ped-1000]~=nil end
function GetEntityHealth(ped) return Test.players[ped-1000].health end
function GetVehiclePedIsIn(ped) return Test.players[ped-1000].vehicle or 0 end
function GetEntityCoords(ped) return Test.positions[ped-1000] end
function GetEntityHeading() return 25.0 end
function SetEntityCoords(ped,x,y,z) Test.moves=Test.moves+1; Test.positions[ped-1000]={x=x,y=y,z=z} end
function SetEntityHeading() end
function FreezeEntityPosition(ped,value) Test.players[ped-1000].frozen=value end
function GetPlayerRoutingBucket(src) return Test.buckets[src] or 0 end
function SetPlayerRoutingBucket(src,bucket) Test.buckets[src]=bucket end
function SetRoutingBucketPopulationEnabled() end
function SetRoutingBucketEntityLockdownMode() end
function copy(value) local out={} for k,v in pairs(value) do out[k]=v end return out end
ESX={GetPlayerFromId=function(src) return Test.players[src] and copy(Test.players[src]) end}
exports={es_extended={getSharedObject=function() return ESX end},egg_city={GetOwnedSpawnPoint=function()
    if Test.homeHook then local fn=Test.homeHook; Test.homeHook=nil; fn() end
    return Test.home and copy(Test.home) or nil
end}}
setmetatable(exports, {__call=function(_,name,fn) Test.exports[name]=fn end})
EggCore={
 RegisterAction=function(_,name,opts,fn) Test.actions[name]=fn end,
 SessionAlive=function() return not Test.bound or (Test.players[Test.bound.source] and Test.players[Test.bound.source].identifier==Test.bound.identifier) end,
 Log=function() end,
}
MySQL={single={await=function(_,args)
 if Test.awaitHook then local fn=Test.awaitHook; Test.awaitHook=nil; fn() end
 return Test.saved[args[1]] and copy(Test.saved[args[1]]) or nil
end},update=function(query,args) Test.persists[#Test.persists+1]=args end}
function Test.player(src,identifier)
 Test.players[src]={identifier=identifier,health=200,job={label='Victoria Police',grade_label='Constable'},getName=function() return 'Alice Example' end,
   get=function(name) if name=='dateofbirth' then return '14/03/1995' end return false end}
 Test.positions[src]={x=35,y=45,z=40}
 Test.buckets[src]=0
end
function Test.run(name,src,payload)
 Test.bound={source=src,identifier=Test.players[src].identifier}
 local result=Test.actions[name](src,copy(Test.players[src]),payload or {})
 Test.bound=nil
 return result
end
function Test.load(src) Test.events['esx:playerLoaded'](src) end
function Test.ready(src) return Test.run('spawn.ready',src,{}) end
function Test.confirm(src,result,id,data)
 data=data or {}; data.token=result.token; data.id=id
 return Test.run('spawn.confirm',src,data)
end
function expect(value,message) assert(value,message) end
''')
lua.execute((RESOURCE / 'server.lua').read_text())
lua.execute(r'''
Test.player(1,'char1:license:one')
Test.load(1)
expect(not Test.ready(1).ok,'disabled resource does not offer a selector')
Config.Enabled=true
expect(not Test.ready(1).ok,'client cannot open without the actual ESX load event')
Test.load(1)
local opened=Test.ready(1)
expect(opened.ok and #opened.choices==8,'eight server-defined choices')
expect(not opened.choices[1].enabled and not opened.choices[2].enabled,'unknown last position and absent home unavailable')
expect(opened.character.name=='Alice Example' and opened.character.dob=='14/03/1995' and opened.character.employer=='Victoria Police','actual ESX character profile')
expect(Test.buckets[1]==Config.PreviewBucketBase+1 and Test.players[1].frozen,'isolated frozen preview')
expect(Test.exports.IsSelecting(1),'active preview is visible to core activity gate')
expect(not Test.ready(1).ok,'ready is one-use')
expect(not Test.confirm(1,opened,'invented').ok,'unapproved point denied')
expect(not Test.run('spawn.confirm',1,{token='wrong',id='alta'}).ok,'wrong session token denied')
local accepted=Test.confirm(1,opened,'alta',{coords={x=9999,y=9999,z=9999}})
expect(accepted.ok and Test.positions[1].x==Config.Points[1].coords.x,'client arbitrary coordinates ignored')
expect(Test.buckets[1]==0 and not Test.players[1].frozen,'confirm restores the main world and mobility')
expect(not Test.exports.IsSelecting(1),'confirmed selection releases the core activity gate')
local movements=Test.moves
expect(not Test.confirm(1,opened,'sandy').ok and Test.moves==movements,'consumed token cannot teleport again')

Test.load(1)
Test.positions[1]={x=35,y=45,z=40}
local cancellable=Test.ready(1)
Test.positions[1]={x=500,y=500,z=50}
expect(Test.run('spawn.cancel',1,{token=cancellable.token}).ok,'initial session can cancel')
expect(Test.positions[1].x==35 and Test.buckets[1]==0,'cancel restores server-captured origin, not changed preview coordinates')

Test.saved['char1:license:one']={x=5,y=8,z=-99,heading=5}
Test.load(1)
local interior=Test.ready(1)
expect(not interior.choices[1].enabled,'private negative-Z interior not offered as Last Location')
Test.run('spawn.cancel',1,{token=interior.token})
Test.saved['char1:license:one']={x=math.huge,y=8,z=30,heading=5}
Test.load(1)
local invalid=Test.ready(1)
expect(not invalid.choices[1].enabled,'nonfinite saved coordinate rejected')
Test.run('spawn.cancel',1,{token=invalid.token})
Test.saved['char1:license:one']={x=5,y=8,z=30,heading=5}
Test.home={roomId='alta_01',label='Alta Street · Apartment 1',coords={x=-270,y=-957,z=31,h=90}}
Test.load(1)
local home=Test.ready(1)
expect(home.choices[1].enabled and home.choices[2].enabled and home.selected=='last','safe last location and actual owned apartment available')
Test.home=nil
expect(not Test.confirm(1,home,'apartment').ok,'expired ownership revalidated at confirm')
Test.home={roomId='alta_01',label='Alta Street · Apartment 1',coords={x=-270,y=-957,z=31,h=90}}
expect(Test.confirm(1,home,'apartment').ok and Test.positions[1].x==-270,'owned apartment exterior is approved')

Test.load(1)
Test.awaitHook=function() Test.players[1].identifier='char2:license:one' end
movements=Test.moves
expect(not Test.ready(1).ok and Test.moves==movements,'character change during database await denies stale opening')
expect(Test.buckets[1]==0,'stale opening does not assign the new character to a preview bucket')
Test.load(1)
local replaced=Test.ready(1)
Test.players[1].identifier='char3:license:one'
movements=Test.moves
expect(not Test.confirm(1,replaced,'alta').ok and Test.moves==movements,'reused source cannot consume another character session')

Test.load(1)
local dying=Test.ready(1)
Test.players[1].health=0
movements=Test.moves
expect(not Test.confirm(1,dying,'alta').ok,'dead player is not spawned')
expect(Test.moves==movements and Test.players[1].health==0 and Test.buckets[1]==0,'death cleanup never moves or revives')
Test.players[1].health=200
Test.load(1)
local expires=Test.ready(1)
local watchdog=Test.threads[1]
expect(coroutine.resume(watchdog),'watchdog starts')
Test.time=Test.time+Config.SessionSeconds+1
expect(coroutine.resume(watchdog),'watchdog expires selector')
expect(Test.buckets[1]==0 and not Test.players[1].frozen,'timeout releases the bucket and ped')
expect(not Test.confirm(1,expires,'alta').ok,'expired selector cannot teleport')

Test.load(1)
local stopped=Test.ready(1)
Test.events['onResourceStop']('egg_spawn')
expect(Test.buckets[1]==0 and not Test.players[1].frozen,'resource stop restores the player')
expect(not Test.confirm(1,stopped,'alta').ok,'stopped session invalidated')
print('Spawn server checks passed: default disable, ESX-only admission, profile, eight choices, token/source/await guards, approved coordinates, one-use confirm, origin cancel, safe last location, apartment expiry, death, timeout and resource-stop cleanup.')
''')
