'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM } = require('jsdom');
const web = path.join(__dirname, '..', 'web');
const dom = new JSDOM(fs.readFileSync(path.join(web, 'index.html'), 'utf8'), { runScripts: 'outside-only', url: 'https://cfx-nui-egg_spawn/' });
const { window } = dom;
const requests = [];
let resolveSelection;
window.GetParentResourceName = () => 'egg_spawn';
window.fetch = async (url, options) => {
  const body = JSON.parse(options.body);
  const route = url.split('/').at(-1);
  requests.push({ route, body });
  if (route === 'select') await new Promise(resolve => { resolveSelection = resolve; });
  return { json: async () => route === 'confirm' ? { ok: false, error: 'That starting point is unavailable.' } : { ok: true } };
};
window.eval(fs.readFileSync(path.join(web, 'app.js'), 'utf8'));
const byId = id => window.document.getElementById(id);
const flush = () => new Promise(resolve => setImmediate(resolve));

(async () => {
  assert.equal(byId('spawn').hidden, true, 'menu is hidden until an authorized open message');
  window.dispatchEvent(new window.MessageEvent('message', { data: {
    type: 'open', selected: 'alta', character: { name: '<img src=x onerror=alert(1)>', dob: '14/03/1995', employer: 'Victoria Police' },
    choices: [
      { id: 'last', label: 'Last Location', enabled: false },
      { id: 'apartment', label: 'Apartment', enabled: false },
      { id: 'alta', label: 'Alta Train Station', area: 'CITY CENTRE', description: 'The public arrival point.', enabled: true },
      { id: 'sandy', label: 'Sandy Shores', area: 'BLAINE COUNTY', description: 'The main street.', enabled: true },
    ],
  } }));
  assert.equal(byId('spawn').hidden, false);
  assert.equal(window.document.querySelectorAll('.location').length, 4);
  assert.equal(window.document.querySelectorAll('.location:disabled').length, 2);
  assert.equal(window.document.querySelectorAll('img').length, 0, 'identity HTML is rendered as plain text');
  assert.equal(byId('character-name').textContent, '<img src=x onerror=alert(1)>');
  assert.equal(byId('reselect').disabled, true, 'unavailable character backend cannot be invoked');
  window.document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
  await flush();
  assert.deepEqual(requests[0], { route: 'select', body: { id: 'sandy' } });
  byId('confirm').click();
  await flush();
  assert.equal(requests.length, 1, 'confirm waits for selection to finish, avoiding a stale point mismatch');
  resolveSelection();
  await flush(); await flush();
  assert.equal(byId('selected-area').textContent, 'BLAINE COUNTY');
  assert.equal(window.document.querySelector('.selected .label').textContent, 'Sandy Shores');
  byId('confirm').click();
  await flush(); await flush();
  assert.deepEqual(requests[1], { route: 'confirm', body: { id: 'sandy' } });
  assert.equal(byId('error').hidden, false, 'server denial is shown without hiding the menu');
  assert.equal(byId('error').textContent, 'That starting point is unavailable.');
  assert.equal(byId('confirm').disabled, false, 'denied arrival can be retried');
  window.document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
  await flush();
  assert.deepEqual(requests[2], { route: 'cancel', body: {} });
  window.dispatchEvent(new window.MessageEvent('message', { data: { type: 'close' } }));
  assert.equal(byId('spawn').hidden, true);
  dom.window.close();
  console.log('Spawn DOM checks passed: admission visibility, safe identity text, disabled choices/reselect, actual NUI routes, keyboard selection, pending-selection guard, denial recovery and close.');
})().catch(error => { dom.window.close(); console.error(error); process.exitCode = 1; });
