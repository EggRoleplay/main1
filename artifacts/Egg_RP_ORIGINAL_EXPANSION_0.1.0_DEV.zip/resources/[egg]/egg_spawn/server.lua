local ESX = exports.es_extended:getSharedObject()
local Core = EggCore
local sessions, identities, latest = {}, {}, {}
local configured = {}
local sequence = 0
for _, point in ipairs(Config.Points) do configured[point.id] = point end

local function fail(message) return { ok = false, error = message } end
local function finite(value)
    value = tonumber(value)
    return value and value == value and value ~= math.huge and value ~= -math.huge and value or nil
end
local function safeCoords(value)
    if type(value) ~= 'table' and type(value) ~= 'vector3' then return nil end
    local x, y, z = finite(value.x), finite(value.y), finite(value.z)
    local h = finite(value.h or value.heading) or 0.0
    local world = Config.World
    if not x or not y or not z or x < world.minX or x > world.maxX or y < world.minY or y > world.maxY or z < world.minZ or z > world.maxZ then return nil end
    return { x = x, y = y, z = z, h = h % 360.0 }
end
local function text(value, fallback, limit)
    if type(value) ~= 'string' or value == '' then return fallback end
    return value:gsub('%c', ''):sub(1, limit or 80)
end
local function identity(source)
    local player = ESX.GetPlayerFromId(source)
    return player and player.identifier or nil
end
local function alive(source)
    local player, ped = ESX.GetPlayerFromId(source), GetPlayerPed(source)
    if not player or ped == 0 or not DoesEntityExist(ped) or GetEntityHealth(ped) <= 0 then return false end
    if player.get and (player.get('dead') == true or player.get('isDead') == true) then return false end
    return true
end
local function current(source, token)
    local session = sessions[source]
    if not Config.Enabled or not session or session.expires <= os.time() or session.identifier ~= identity(source) or (token and session.token ~= token) then return nil end
    if not Core:SessionAlive() then return nil end
    return session
end
exports('IsSelecting', function(source)
    local session = sessions[tonumber(source)]
    return session ~= nil and session.opened == true
end)
local function release(source, session, reason)
    if not session or not sessions[source] or sessions[source].token ~= session.token then return end
    sessions[source] = nil
    if session.opened then
        local ped = GetPlayerPed(source)
        -- Return from preview to the server-captured login position, never a
        -- client-supplied coordinate. A dead character is never moved or revived.
        if identity(source) == session.identifier and session.origin and alive(source) and ped ~= 0 and DoesEntityExist(ped) then
            SetEntityCoords(ped, session.origin.x, session.origin.y, session.origin.z, false, false, false, false)
            SetEntityHeading(ped, session.origin.h)
        end
        if GetPlayerRoutingBucket(source) == Config.PreviewBucketBase + source then
            SetPlayerRoutingBucket(source, 0)
            if ped ~= 0 and DoesEntityExist(ped) then FreezeEntityPosition(ped, false) end
        end
        TriggerClientEvent('egg_spawn:close', source, session.token, reason)
    end
end
local function apartment(source)
    if GetResourceState('egg_city') ~= 'started' then return nil end
    local ok, result = pcall(function() return exports.egg_city:GetOwnedSpawnPoint(source) end)
    if not ok or type(result) ~= 'table' or type(result.roomId) ~= 'string' then return nil end
    local coords = safeCoords(result.coords)
    return coords and { roomId = result.roomId, label = text(result.label, 'Your apartment'), coords = coords } or nil
end
local function profile(player)
    local job = player.job or {}
    local dob = player.get and player.get('dateofbirth') or nil
    return {
        name = text(player.getName and player.getName(), 'Your character'),
        dob = text(dob, '—', 24),
        employer = text(job.label or job.name, 'Unemployed'),
        role = text(job.grade_label, '', 64),
    }
end
local function persist(owner, coords)
    if not owner or not coords then return end
    local ok = pcall(function()
        MySQL.update([[INSERT INTO egg_spawn_last_location (identifier, x, y, z, heading) VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE x = VALUES(x), y = VALUES(y), z = VALUES(z), heading = VALUES(heading)]],
            { owner, coords.x, coords.y, coords.z, coords.h })
    end)
    if not ok then print('[egg_spawn] Last location could not be saved. Check oxmysql and sql/80_spawn.sql.') end
end

-- This is the real ESX server lifecycle event, not a client-requested open menu.
AddEventHandler('esx:playerLoaded', function(playerId)
    if not Config.Enabled then return end
    local source = tonumber(playerId)
    local owner = source and identity(source)
    if not owner then return end
    local previous = sessions[source]
    if previous then release(source, previous, 'character_changed') end
    sequence = sequence + 1
    local token = ('%d:%d:%d'):format(os.time(), sequence, math.random(1, 2147483647))
    identities[source] = owner
    sessions[source] = { identifier = owner, token = token, expires = os.time() + Config.SessionSeconds, opened = false }
    TriggerClientEvent('egg_spawn:eligible', source)
end)

Core:RegisterAction('spawn.ready', { cooldown = 750 }, function(source, player)
    local session = current(source)
    if not session or session.opened or session.loading then return fail('Spawn selection is only available when your character first joins.') end
    if not alive(source) or GetVehiclePedIsIn(GetPlayerPed(source), false) ~= 0 then return fail('Finish loading your character before choosing a location.') end
    if GetPlayerRoutingBucket(source) ~= 0 or not safeCoords(GetEntityCoords(GetPlayerPed(source))) then return fail('Finish returning to the public city before choosing a location.') end
    session.loading = true
    local token, owner = session.token, session.identifier
    local success, saved = pcall(function()
        return MySQL.single.await('SELECT x, y, z, heading FROM egg_spawn_last_location WHERE identifier = ?', { owner })
    end)
    if not success then print('[egg_spawn] Could not read saved location. Import sql/80_spawn.sql and check oxmysql.'); saved = nil end
    local home = apartment(source)
    session = current(source, token)
    if not session or not alive(source) then return fail('Your character session has ended.') end
    local last = safeCoords(saved)
    local choices = {
        { id = 'last', label = 'Last Location', area = 'CONTINUE WHERE YOU LEFT OFF', enabled = last ~= nil,
          description = last and 'Return to your last recorded outdoor location.' or 'No safe outdoor location has been recorded yet.', coords = last },
        { id = 'apartment', label = 'Apartment', area = home and home.label or 'YOUR FRONT DOOR', enabled = home ~= nil,
          description = home and 'Start outside your current home or motel.' or 'Available when you own a home or have an active tenancy.', coords = home and home.coords, roomId = home and home.roomId },
    }
    for _, point in ipairs(Config.Points) do
        local coords = safeCoords(point.coords)
        choices[#choices + 1] = { id = point.id, label = point.label, area = point.area, description = point.description, enabled = coords ~= nil, coords = coords }
    end
    session.choices = {}
    for _, point in ipairs(choices) do session.choices[point.id] = point end
    local ped = GetPlayerPed(source)
    local position = GetEntityCoords(ped)
    session.origin = safeCoords({ x = position.x, y = position.y, z = position.z, h = GetEntityHeading(ped) })
    if not session.origin then
        local fallback = configured[Config.DefaultPoint]
        session.origin = fallback and safeCoords(fallback.coords) or nil
    end
    session.opened, session.loading = true, false
    local bucket = Config.PreviewBucketBase + source
    SetRoutingBucketPopulationEnabled(bucket, false)
    SetRoutingBucketEntityLockdownMode(bucket, 'strict')
    SetPlayerRoutingBucket(source, bucket)
    FreezeEntityPosition(GetPlayerPed(source), true)
    return { ok = true, token = token, expiresIn = math.max(1, session.expires - os.time()), character = profile(player), choices = choices,
        selected = last and 'last' or (home and 'apartment' or Config.DefaultPoint), canReselect = false }
end)

Core:RegisterAction('spawn.confirm', { cooldown = 1200 }, function(source, _, data)
    if type(data.token) ~= 'string' or type(data.id) ~= 'string' then return fail('Choose a starting point.') end
    local session = current(source, data.token)
    if not session or not session.opened then return fail('Your spawn selection has ended. Rejoin to load your character normally.') end
    if not alive(source) then release(source, session, 'dead'); return fail('Spawn selection cannot revive your character.') end
    local choice = session.choices[data.id]
    if not choice or not choice.enabled then return fail('That starting point is unavailable.') end
    local coords = safeCoords(choice.coords)
    if data.id == 'apartment' then
        local home = apartment(source)
        if not home or home.roomId ~= choice.roomId then return fail('Your tenancy changed. Choose another starting point.') end
        coords = home.coords
    end
    session = current(source, data.token)
    if not session or not alive(source) or not coords or GetPlayerRoutingBucket(source) ~= Config.PreviewBucketBase + source then
        return fail('Your character is no longer in the spawn selection session.')
    end
    local ped, owner = GetPlayerPed(source), session.identifier
    local moved, errorText = pcall(function()
        SetEntityCoords(ped, coords.x, coords.y, coords.z, false, false, false, false)
        SetEntityHeading(ped, coords.h)
        SetPlayerRoutingBucket(source, 0)
        FreezeEntityPosition(ped, false)
    end)
    if not moved then
        print('[egg_spawn] Spawn teleport failed: ' .. tostring(errorText))
        release(source, session, 'failed')
        return fail('The city could not place your character. Your original login flow has been restored.')
    end
    -- Consume the permission before replying; the same token cannot move again.
    sessions[source] = nil
    latest[owner] = coords
    persist(owner, coords)
    local logged = pcall(function() Core:Log(source, 'spawn', 'Joined at ' .. choice.id) end)
    if not logged then print('[egg_spawn] Spawn completed, but the audit service could not record it.') end
    return { ok = true, coords = coords }
end)

Core:RegisterAction('spawn.cancel', { cooldown = 750 }, function(source, _, data)
    local session = type(data.token) == 'string' and current(source, data.token) or nil
    if not session or not session.opened then return fail('There is no active spawn selection.') end
    release(source, session, 'cancelled')
    return { ok = true }
end)

CreateThread(function()
    while true do
        Wait(1000)
        for source, session in pairs(sessions) do
            if session.expires <= os.time() or identity(source) ~= session.identifier or (session.opened and not alive(source)) then
                release(source, session, 'expired')
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(math.max(10, Config.SaveIntervalSeconds) * 1000)
        if Config.Enabled then
            for _, rawSource in ipairs(GetPlayers()) do
                local source = tonumber(rawSource)
                local owner = identity(source)
                if owner and not sessions[source] and GetPlayerRoutingBucket(source) == 0 and alive(source) then
                    local ped = GetPlayerPed(source)
                    local position = GetEntityCoords(ped)
                    local coords = safeCoords({ x = position.x, y = position.y, z = position.z, h = GetEntityHeading(ped) })
                    local previous = latest[owner]
                    if coords and (not previous or (coords.x - previous.x)^2 + (coords.y - previous.y)^2 + (coords.z - previous.z)^2 >= 9.0) then
                        latest[owner] = coords
                        persist(owner, coords)
                    end
                end
            end
        end
    end
end)

AddEventHandler('playerDropped', function()
    local playerId = source
    local owner = identities[playerId]
    if owner and latest[owner] then persist(owner, latest[owner]); latest[owner] = nil end
    sessions[playerId], identities[playerId] = nil, nil
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for source, session in pairs(sessions) do release(source, session, 'resource_stopped') end
end)
