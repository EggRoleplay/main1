fx_version 'cerulean'
game 'gta5'
lua54 'yes'
name 'Egg RP | shared services'
author 'Egg Roleplay'
version '0.1.0'
shared_script 'config.lua'
client_script 'client.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
dependencies { 'es_extended', 'oxmysql', '/onesync' }
