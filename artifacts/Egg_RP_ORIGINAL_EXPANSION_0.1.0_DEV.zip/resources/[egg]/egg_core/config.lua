Config = {}
Config.StaffGroups = { admin = true, superadmin = true }
Config.MaxTransaction = 10000000
Config.MaxItemTransfer = 1000
Config.MaxXPGrant = 1000
Config.AppearanceResource = 'illenium-appearance'
Config.AppearanceEvent = 'illenium-appearance:client:openClothingShopMenu'
-- Smart Phone Pro is installed separately from your licensed/original files.
-- Change this if your edition uses a different resource name.
Config.PhoneResource = 'qs-smartphone-pro'
Config.PhoneOpenEvent = '' -- set ONLY to your phone vendor's documented client event
Config.PhoneCommand = 'phone'
Config.ClothingShops = {
    { x = 72.3, y = -1399.1, z = 29.4 },
    { x = -709.3, y = -153.7, z = 37.4 },
    { x = 425.1, y = -806.4, z = 29.5 },
    { x = -1192.9, y = -772.4, z = 17.3 },
    { x = 1693.5, y = 4823.1, z = 42.1 }
}
