local ESX = exports.es_extended:getSharedObject()
local actions, lastCall, busy, locks = {}, {}, {}, {}
local contexts = setmetatable({}, { __mode = 'k' })
local pending = {}
local function callable(value)
    if type(value) == 'function' then return true end
    if type(value) ~= 'table' then return false end
    local meta = getmetatable(value)
    return (type(meta) == 'table' and type(meta.__call) == 'function') or rawget(value, '__cfx_functionReference') ~= nil
end

local function currentPlayer(source)
    local player = ESX.GetPlayerFromId(source)
    local context = contexts[coroutine.running()]
    if context then
        local actor = ESX.GetPlayerFromId(context.source)
        if context.cancelled or not actor or actor.identifier ~= context.identifier then return nil end
    end
    return player
end

local function integer(value, max)
    return type(value) == 'number' and value == value and value > 0 and value % 1 == 0 and value <= max
end

local function identifier(source)
    local player = currentPlayer(source)
    return player and player.identifier or nil
end

local function isStaff(source)
    local player = ESX.GetPlayerFromId(source)
    return player ~= nil and (IsPlayerAceAllowed(source, 'egg.staff') or Config.StaffGroups[player.getGroup()] == true)
end

local function near(source, coords, radius)
    if type(coords) ~= 'table' and type(coords) ~= 'vector3' then return false end
    local ped = GetPlayerPed(source)
    if not ped or ped == 0 or not DoesEntityExist(ped) then return false end
    local point = GetEntityCoords(ped)
    local x, y, z = tonumber(coords.x), tonumber(coords.y), tonumber(coords.z)
    if not x or not y or not z or not radius or radius <= 0 or radius > 250 then return false end
    return ((point.x - x)^2 + (point.y - y)^2 + (point.z - z)^2) <= radius^2
end

local function log(source, category, message)
    if type(category) ~= 'string' or type(message) ~= 'string' then return end
    MySQL.insert('INSERT INTO egg_audit (identifier, category, message) VALUES (?, ?, ?)', {
        identifier(source) or ('server:' .. tostring(source)), category:sub(1, 40), message:sub(1, 2000)
    })
end

local function debit(source, amount, account)
    if not integer(amount, Config.MaxTransaction) then return false end
    local player = currentPlayer(source)
    if not player then return false end
    account = account or 'bank'
    local balance = account == 'money' and player.getMoney() or (player.getAccount(account) or {}).money
    if type(balance) ~= 'number' or balance < amount then return false end
    if account == 'money' then player.removeMoney(amount, 'Egg RP transaction')
    else player.removeAccountMoney(account, amount, 'Egg RP transaction') end
    return true
end

local function credit(source, amount, account)
    if not integer(amount, Config.MaxTransaction) then return false end
    local player = currentPlayer(source)
    if not player then return false end
    account = account or 'bank'
    if account == 'money' then player.addMoney(amount, 'Egg RP transaction')
    elseif player.getAccount(account) then player.addAccountMoney(account, amount, 'Egg RP transaction')
    else return false end
    return true
end

local function itemDefinition(name)
    if type(name) ~= 'string' or #name > 80 then return nil end
    return ESX.GetItems()[name]
end

local function hasItem(source, name, count)
    if not integer(count or 1, Config.MaxItemTransfer) or not itemDefinition(name) then return false end
    local player = currentPlayer(source)
    local item = player and player.getInventoryItem(name)
    return item ~= nil and item.count >= (count or 1)
end

local function addItem(source, name, count)
    if not integer(count, Config.MaxItemTransfer) or not itemDefinition(name) then return false end
    local player = currentPlayer(source)
    if not player then return false end
    if player.canCarryItem then
        if not player.canCarryItem(name, count) then return false end
    else
        local item = player.getInventoryItem(name)
        if not item or (item.limit and item.limit >= 0 and item.count + count > item.limit) then return false end
    end
    player.addInventoryItem(name, count)
    return true
end

local function removeItem(source, name, count)
    if not hasItem(source, name, count) then return false end
    currentPlayer(source).removeInventoryItem(name, count)
    return true
end

local function skillKey(skill)
    return type(skill) == 'string' and #skill <= 32 and skill:match('^[a-z][a-z_]+$') ~= nil
end

local function getSkill(source, skill)
    local owner = identifier(source)
    if not owner or not skillKey(skill) then return { xp = 0, level = 1 } end
    local xp = tonumber(MySQL.scalar.await('SELECT xp FROM egg_skills WHERE identifier = ? AND skill = ?', { owner, skill })) or 0
    return { xp = xp, level = math.min(100, math.floor(math.sqrt(xp / 100)) + 1) }
end

local function addXP(source, skill, amount)
    local owner = identifier(source)
    if not owner or not skillKey(skill) or not integer(amount, Config.MaxXPGrant) then return false end
    MySQL.update.await('INSERT INTO egg_skills (identifier, skill, xp) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE xp = LEAST(xp + VALUES(xp), 980100)', { owner, skill, amount })
    return true
end

-- These exports are server-only. No amount, permission or item is accepted as authority from a client.
exports('Identifier', identifier)
exports('IsStaff', isStaff)
exports('RequireNear', near)
exports('TryDebit', debit)
exports('Credit', credit)
exports('AddItem', addItem)
exports('RemoveItem', removeItem)
exports('HasItem', hasItem)
exports('GetSkill', getSkill)
exports('AddXP', addXP)
exports('Log', log)
exports('Notify', function(source, message) TriggerClientEvent('egg_core:notify', source, message) end)

exports('WithLock', function(key, fn)
    assert(type(key) == 'string' and callable(fn), 'Invalid lock')
    while locks[key] do Wait(5) end
    locks[key] = true
    local result = table.pack(xpcall(fn, debug.traceback))
    locks[key] = nil
    if not result[1] then error(result[2]) end
    return table.unpack(result, 2, result.n)
end)

local function actionHelpers(context)
    local function alive()
        local player = ESX.GetPlayerFromId(context.source)
        return not context.cancelled and player ~= nil and player.identifier == context.identifier
    end
    local helpers = { SessionAlive = function() return alive() end }
    local functions = {
        Identifier = identifier, IsStaff = isStaff, RequireNear = near,
        TryDebit = debit, Credit = credit, AddItem = addItem, RemoveItem = removeItem,
        HasItem = hasItem, GetSkill = getSkill, AddXP = addXP
    }
    for name, implementation in pairs(functions) do
        helpers[name] = function(_, ...)
            if not alive() then
                if name == 'GetSkill' then return { xp = 0, level = 1 } end
                if name == 'Identifier' then return nil end
                return false
            end
            return implementation(...)
        end
    end
    helpers.Notify = function(_, target, message)
        if alive() then TriggerClientEvent('egg_core:notify', target, message) end
    end
    helpers.Log = function(_, actor, category, message)
        if type(category) ~= 'string' or type(message) ~= 'string' then return end
        -- Attribute the originating character even after its connection closes.
        MySQL.insert('INSERT INTO egg_audit (identifier, category, message) VALUES (?, ?, ?)', {
            context.identifier, category:sub(1, 40), message:sub(1, 2000)
        })
    end
    helpers.WithLock = function(_, key, fn)
        assert(type(key) == 'string' and callable(fn), 'Invalid lock')
        while locks[key] do Wait(5) end
        -- Database compensation may still need the lock after disconnect.
        -- Bound player mutations independently deny a cancelled character.
        locks[key] = true
        local result = table.pack(xpcall(fn, debug.traceback))
        locks[key] = nil
        if not result[1] then error(result[2]) end
        return table.unpack(result, 2, result.n)
    end
    return helpers
end

exports('RegisterAction', function(name, options, handler)
    assert(type(name) == 'string' and #name <= 80 and callable(handler), 'Invalid action')
    assert(not actions[name], 'Duplicate action: ' .. name)
    actions[name] = { options = options or {}, handler = handler, resource = GetInvokingResource() }
end)

local function validPayload(data, depth, budget)
    if depth > 4 then return false end
    if type(data) ~= 'table' then return false end
    for key, value in pairs(data) do
        budget.keys = budget.keys + 1
        if budget.keys > 100 then return false end
        if type(key) ~= 'number' and type(key) ~= 'string' then return false end
        if type(key) == 'string' then budget.bytes = budget.bytes + #key end
        local kind = type(value)
        if kind == 'string' then
            if #value > 4096 then return false end
            budget.bytes = budget.bytes + #value
        elseif kind == 'number' then
            if value ~= value or value == math.huge or value == -math.huge then return false end
        elseif kind == 'table' then
            if not validPayload(value, depth + 1, budget) then return false end
        elseif kind ~= 'boolean' then return false end
        if budget.bytes > 16000 then return false end
    end
    return true
end

ESX.RegisterServerCallback('egg:action', function(source, cb, name, payload)
    local action = type(name) == 'string' and actions[name] or nil
    local player = ESX.GetPlayerFromId(source)
    if not player or not action then cb({ ok = false, error = 'That service is unavailable.' }); return end
    if name:sub(1, 6) ~= 'spawn.' and GetResourceState('egg_spawn') == 'started' then
        local checked, selecting = pcall(function() return exports.egg_spawn:IsSelecting(source) end)
        if checked and selecting then cb({ ok = false, error = 'Finish choosing your starting point first.' }); return end
    end
    if not validPayload(payload or {}, 1, { keys = 0, bytes = 0 }) then
        cb({ ok = false, error = 'Invalid request.' }); return
    end
    local settings, stamp = action.options, GetGameTimer()
    local calls = lastCall[source] or {}
    if busy[source] or (calls.global and stamp - calls.global < 120) or (calls[name] and stamp - calls[name] < (settings.cooldown or 750)) then
        cb({ ok = false, error = 'Give it a moment.' }); return
    end
    if settings.staff and not isStaff(source) then cb({ ok = false, error = 'Staff access required.' }); return end
    if settings.job and (not player.job or not settings.job[player.job.name]) then cb({ ok = false, error = 'Your job does not have access.' }); return end
    local context = { source = source, identifier = player.identifier, resource = action.resource }
    pending[context] = true
    calls[name], calls.global, lastCall[source], busy[source] = stamp, stamp, calls, context
    local thread = coroutine.running()
    contexts[thread] = context
    local ok, result = xpcall(function() return action.handler(source, player, payload or {}, actionHelpers(context)) end, debug.traceback)
    contexts[thread] = nil
    pending[context] = nil
    if busy[source] == context then busy[source] = nil end
    local active = ESX.GetPlayerFromId(source)
    if context.cancelled or not active then return end
    if active.identifier ~= context.identifier then
        cb({ ok = false, error = 'Your character changed during that request. Try again.' }); return
    end
    if not ok then
        print(('[Egg RP] Action %s failed: %s'):format(name, tostring(result)))
        cb({ ok = false, error = 'The service could not complete that request. Staff have the server log.' })
    else
        cb(type(result) == 'table' and result or { ok = false, error = 'The service returned no result.' })
    end
end)

AddEventHandler('playerDropped', function()
    if busy[source] then busy[source].cancelled = true end
    lastCall[source], busy[source] = nil, nil
end)
AddEventHandler('onResourceStop', function(resource)
    for context in pairs(pending) do if context.resource == resource then context.cancelled = true end end
    for name, action in pairs(actions) do if action.resource == resource then actions[name] = nil end end
end)
