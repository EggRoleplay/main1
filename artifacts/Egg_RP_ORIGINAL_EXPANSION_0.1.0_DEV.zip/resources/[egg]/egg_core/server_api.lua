-- Loaded in EACH consuming resource, not in egg_core itself.
-- CFX function references cross resource boundaries on fresh coroutines. Bind
-- the action context explicitly, and reinstall it when WithLock calls back.
local Raw = exports.egg_core
local localContexts = setmetatable({}, { __mode = 'k' })
EggCore = {}
local function callable(value)
    if type(value) == 'function' then return true end
    if type(value) ~= 'table' then return false end
    local meta = getmetatable(value)
    return (type(meta) == 'table' and type(meta.__call) == 'function') or rawget(value, '__cfx_functionReference') ~= nil
end

local function inContext(context, callback, ...)
    local thread = coroutine.running()
    local previous = localContexts[thread]
    localContexts[thread] = context
    local values = table.pack(xpcall(callback, debug.traceback, ...))
    localContexts[thread] = previous
    if not values[1] then error(values[2]) end
    return table.unpack(values, 2, values.n)
end

function EggCore:RegisterAction(name, options, handler)
    Raw:RegisterAction(name, options, function(source, player, payload, context)
        assert(type(context) == 'table' and callable(context.SessionAlive), 'Egg core API version mismatch')
        return inContext(context, handler, source, player, payload)
    end)
end

function EggCore:WithLock(key, callback)
    local context = localContexts[coroutine.running()]
    local service = context or Raw
    -- Pass nil self for captured helper references; no recursive helper table
    -- needs to be msgpack-encoded on every callback.
    if context then
        return service.WithLock(nil, key, function() return inContext(context, callback) end)
    end
    return Raw:WithLock(key, callback)
end

function EggCore:SessionAlive()
    local context = localContexts[coroutine.running()]
    return context == nil or context.SessionAlive(nil)
end

setmetatable(EggCore, { __index = function(_, name)
    return function(_, ...)
        local context = localContexts[coroutine.running()]
        if context and context[name] then return context[name](nil, ...) end
        return Raw[name](Raw, ...)
    end
end })
