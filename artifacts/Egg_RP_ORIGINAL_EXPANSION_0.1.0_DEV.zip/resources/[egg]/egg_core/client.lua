local ESX = exports.es_extended:getSharedObject()

exports('Action', function(name, data, cb)
    ESX.TriggerServerCallback('egg:action', function(result)
        result = type(result) == 'table' and result or { ok = false, error = 'No response from the city. Try again.' }
        if cb then cb(result) elseif not result.ok then ESX.ShowNotification(result.error) end
    end, name, data or {})
end)

RegisterNetEvent('egg_core:notify', function(message)
    if type(message) == 'string' then ESX.ShowNotification(message) end
end)

RegisterCommand('eggappearance', function()
    if GetResourceState(Config.AppearanceResource) ~= 'started' then
        ESX.ShowNotification('Illenium Appearance is not running. Ask a server administrator.')
        return
    end
    local here = GetEntityCoords(PlayerPedId())
    for _, point in ipairs(Config.ClothingShops) do
        if #(here - vector3(point.x, point.y, point.z)) < 4.0 then
            TriggerEvent(Config.AppearanceEvent, false)
            return
        end
    end
    ESX.ShowNotification('Visit a clothing shop to change your appearance.')
end, false)

-- A separate alias prevents this pack taking over an existing phone keybind.
RegisterCommand('eggphone', function()
    if GetResourceState(Config.PhoneResource) ~= 'started' then
        ESX.ShowNotification('Smart Phone Pro is not running. Its original files must be installed separately.')
        return
    end
    if Config.PhoneOpenEvent ~= '' then TriggerEvent(Config.PhoneOpenEvent)
    else ExecuteCommand(Config.PhoneCommand) end
end, false)
