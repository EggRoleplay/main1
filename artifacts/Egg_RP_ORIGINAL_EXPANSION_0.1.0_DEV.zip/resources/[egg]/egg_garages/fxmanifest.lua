fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Egg RP public garages with server-owned checkout reservations'
dependencies { 'es_extended', 'oxmysql', 'egg_core', 'esx_menu_default' }
shared_script 'config.lua'
client_script 'client/main.lua'
server_script '@egg_core/server_api.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server/main.lua' }
