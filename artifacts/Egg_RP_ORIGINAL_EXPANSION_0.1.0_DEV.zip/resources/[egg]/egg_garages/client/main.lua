local ESX = exports.es_extended:getSharedObject()
local pending = false

local function notify(message) ESX.ShowNotification(message) end
local function action(name, data, callback)
    if pending then return end
    pending = true
    exports.egg_core:Action(name, data, function(result)
        pending = false
        if not result.ok then notify(result.error); return end
        if callback then callback(result) end
    end)
end

local function collect(garage, registration)
    action('garages:withdraw', { garage = garage.id, plate = registration }, function(result)
        CreateThread(function()
            local deadline = GetGameTimer() + 10000
            while not NetworkDoesEntityExistWithNetworkId(result.netId) and GetGameTimer() < deadline do Wait(50) end
            if not NetworkDoesEntityExistWithNetworkId(result.netId) then notify('Your vehicle is checked out but has not streamed in. Ask staff to check the collection bay.'); return end
            local vehicle = NetToVeh(result.netId)
            if vehicle == 0 or not DoesEntityExist(vehicle) then return end
            local props = result.properties
            local ped = PlayerPedId()
            local point = GetEntityCoords(ped)
            if #(point - vector3(garage.point.x, garage.point.y, garage.point.z)) > 35.0 then notify('Your vehicle is waiting in the collection bay.'); return end
            deadline = GetGameTimer() + 3000
            while not NetworkHasControlOfEntity(vehicle) and GetGameTimer() < deadline do NetworkRequestControlOfEntity(vehicle); Wait(50) end
            if NetworkHasControlOfEntity(vehicle) then
                SetVehicleNumberPlateText(vehicle, props.plate)
                SetVehicleColours(vehicle, props.color1, props.color2)
                SetVehicleExtraColours(vehicle, props.pearlescentColor, props.wheelColor)
            end
            if not IsPedDeadOrDying(ped, true) then TaskWarpPedIntoVehicle(ped, vehicle, -1) end
            notify('Vehicle collected. Drive safe.')
        end)
    end)
end

local function store(garage)
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 or GetPedInVehicleSeat(vehicle, -1) ~= ped then notify('You need to be in the driver’s seat.'); return end
    local colour1, colour2 = GetVehicleColours(vehicle)
    local pearl, wheels = GetVehicleExtraColours(vehicle)
    action('garages:store', {
        garage = garage.id, netId = VehToNet(vehicle),
        properties = { color1 = colour1, color2 = colour2, pearlescentColor = pearl, wheelColor = wheels },
    }, function(result) notify(result.message) end)
end

local function openGarage(garage)
    if IsPedInAnyVehicle(PlayerPedId(), false) then store(garage); return end
    action('garages:list', { garage = garage.id }, function(result)
        if #result.vehicles == 0 then notify('You don’t have any registered road vehicles.'); return end
        local elements = {}
        for _, vehicle in ipairs(result.vehicles) do
            local name = GetLabelText(GetDisplayNameFromVehicleModel(vehicle.model))
            if not name or name == 'NULL' then name = GetDisplayNameFromVehicleModel(vehicle.model) end
            local available = vehicle.status == 'stored'
            elements[#elements + 1] = {
                label = ('%s · %s · %s'):format(name, vehicle.plate, available and 'Available' or 'Checked out'),
                value = vehicle.plate, available = available,
            }
        end
        ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'garage', { title = garage.label, align = 'top-left', elements = elements }, function(data, menu)
            if not data.current.available then notify('That vehicle is out. Ask staff if it needs recovery.'); return end
            menu.close()
            collect(garage, data.current.value)
        end, function(_, menu) menu.close() end)
    end)
end

CreateThread(function()
    for _, garage in ipairs(Config.Garages) do
        local blip = AddBlipForCoord(garage.point.x, garage.point.y, garage.point.z)
        SetBlipSprite(blip, Config.Blip.sprite)
        SetBlipColour(blip, Config.Blip.colour)
        SetBlipScale(blip, Config.Blip.scale)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName('STRING'); AddTextComponentSubstringPlayerName(garage.label); EndTextCommandSetBlipName(blip)
    end
    while true do
        local sleep = 1200
        local point = GetEntityCoords(PlayerPedId())
        for _, garage in ipairs(Config.Garages) do
            local distance = #(point - vector3(garage.point.x, garage.point.y, garage.point.z))
            if distance < Config.DrawDistance then
                sleep = 0
                DrawMarker(1, garage.point.x, garage.point.y, garage.point.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.5, 85, 159, 184, 110, false, false, 2, false, nil, nil, false)
                if distance < Config.InteractDistance then
                    ESX.ShowHelpNotification(IsPedInAnyVehicle(PlayerPedId(), false) and 'Press ~INPUT_CONTEXT~ to store your vehicle' or 'Press ~INPUT_CONTEXT~ to open the garage')
                    if IsControlJustReleased(0, 38) then openGarage(garage) end
                end
            end
        end
        Wait(sleep)
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then ESX.UI.Menu.CloseAll() end
end)
