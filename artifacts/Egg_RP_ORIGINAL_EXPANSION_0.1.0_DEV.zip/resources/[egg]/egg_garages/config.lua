Config = {}
Config.InteractDistance = 2.5
Config.ServerDistance = 12.0
Config.SpawnClearance = 4.0
Config.DrawDistance = 35.0
Config.Blip = { sprite = 357, colour = 3, scale = 0.55 }

-- The model is always read from owned_vehicles, never accepted from a player.
-- FiveM's server setter requires a vehicle type for motorcycles.
Config.Motorcycles = {
    'akuma', 'avarus', 'bagger', 'bati', 'bati2', 'bf400', 'carbonrs', 'chimera',
    'cliffhanger', 'daemon', 'daemon2', 'defiler', 'diablous', 'diablous2', 'double',
    'enduro', 'esskey', 'faggio', 'faggio2', 'faggio3', 'fcr', 'fcr2', 'gargoyle',
    'hakuchou', 'hakuchou2', 'hexer', 'innovation', 'lectro', 'manchez', 'manchez2',
    'nemesis', 'nightblade', 'pcj', 'ratbike', 'ruffian', 'sanchez', 'sanchez2',
    'sanctus', 'shotaro', 'sovereign', 'stryder', 'thrust', 'vader', 'vindicator',
    'vortex', 'wolfsbane', 'zombiea', 'zombieb', 'shinobi', 'reever', 'powersurge',
}

-- Twenty original locations on the stock GTA map; no purchased map assets.
Config.Garages = {
    { id = 'civic', label = 'Civic Square', point = { x = 215.12, y = -810.18, z = 30.73 }, spawn = { x = 229.40, y = -800.08, z = 30.56, h = 157.0 } },
    { id = 'west_end', label = 'West End', point = { x = -340.03, y = -876.01, z = 31.07 }, spawn = { x = -343.92, y = -891.44, z = 31.07, h = 168.0 } },
    { id = 'central', label = 'Central Station', point = { x = 437.64, y = -1007.62, z = 27.10 }, spawn = { x = 445.10, y = -1018.50, z = 28.48, h = 91.0 } },
    { id = 'hospital', label = 'Hospital Visitor Parking', point = { x = 294.38, y = -611.47, z = 43.37 }, spawn = { x = 288.56, y = -604.71, z = 43.21, h = 70.0 } },
    { id = 'east_market', label = 'East Market', point = { x = 1009.09, y = -774.18, z = 58.01 }, spawn = { x = 1005.45, y = -771.75, z = 57.88, h = 219.0 } },
    { id = 'mirror_park', label = 'Mirror Park', point = { x = 1036.32, y = -763.63, z = 57.99 }, spawn = { x = 1046.62, y = -774.07, z = 57.89, h = 270.0 } },
    { id = 'beach', label = 'Beachside', point = { x = -1184.57, y = -1509.65, z = 4.65 }, spawn = { x = -1187.44, y = -1498.24, z = 4.38, h = 124.0 } },
    { id = 'pier', label = 'Pier Parking', point = { x = -1605.63, y = -1046.95, z = 13.03 }, spawn = { x = -1600.67, y = -1048.42, z = 13.03, h = 318.0 } },
    { id = 'marina', label = 'Marina', point = { x = -800.49, y = -1311.72, z = 5.00 }, spawn = { x = -793.83, y = -1299.31, z = 5.00, h = 351.0 } },
    { id = 'airport', label = 'Airport Long Stay', point = { x = -1035.32, y = -2732.85, z = 20.17 }, spawn = { x = -1029.18, y = -2728.58, z = 20.10, h = 240.0 } },
    { id = 'port', label = 'Port Workers Parking', point = { x = 811.35, y = -2982.20, z = 6.02 }, spawn = { x = 822.01, y = -2981.67, z = 5.90, h = 89.0 } },
    { id = 'industrial', label = 'Industrial Estate', point = { x = 873.70, y = -1454.82, z = 30.50 }, spawn = { x = 880.00, y = -1455.47, z = 30.32, h = 270.0 } },
    { id = 'vinewood', label = 'Vinewood', point = { x = 638.69, y = 205.58, z = 97.50 }, spawn = { x = 645.10, y = 202.20, z = 96.84, h = 159.0 } },
    { id = 'university', label = 'University', point = { x = -1684.50, y = 49.03, z = 64.05 }, spawn = { x = -1680.85, y = 43.27, z = 63.70, h = 339.0 } },
    { id = 'chumash', label = 'Chumash Foreshore', point = { x = -3143.05, y = 1121.05, z = 20.86 }, spawn = { x = -3139.46, y = 1125.01, z = 20.70, h = 244.0 } },
    { id = 'route68', label = 'Route 68', point = { x = 1177.48, y = 2640.35, z = 37.75 }, spawn = { x = 1181.39, y = 2638.80, z = 37.72, h = 1.0 } },
    { id = 'sandy', label = 'Sandy Town Centre', point = { x = 1737.27, y = 3710.34, z = 34.14 }, spawn = { x = 1734.21, y = 3717.17, z = 34.00, h = 20.0 } },
    { id = 'grapeseed', label = 'Grapeseed', point = { x = 1690.47, y = 4782.31, z = 42.01 }, spawn = { x = 1696.19, y = 4786.77, z = 41.92, h = 91.0 } },
    { id = 'paleto', label = 'Paleto Main Street', point = { x = 105.49, y = 6613.60, z = 32.40 }, spawn = { x = 110.75, y = 6607.67, z = 31.80, h = 225.0 } },
    { id = 'lumberyard', label = 'North Coast Timber Yard', point = { x = -767.36, y = 5596.98, z = 33.60 }, spawn = { x = -773.49, y = 5598.41, z = 33.49, h = 90.0 } },
}
