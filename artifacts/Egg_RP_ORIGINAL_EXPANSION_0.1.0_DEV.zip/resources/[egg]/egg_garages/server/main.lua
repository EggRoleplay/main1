local ESX = exports.es_extended:getSharedObject()
local garages, motorcycleModels = {}, {}
for _, garage in ipairs(Config.Garages) do garages[garage.id] = garage end
for _, model in ipairs(Config.Motorcycles) do motorcycleModels[GetHashKey(model) % 4294967296] = true end

local function fail(message) return { ok = false, error = message } end
local function plate(value)
    if type(value) ~= 'string' then return nil end
    value = value:upper():match('^%s*(.-)%s*$')
    if #value < 1 or #value > 8 or not value:match('^[A-Z0-9 %-]+$') then return nil end
    return value
end

local function decode(value)
    if type(value) == 'table' then return value end
    if type(value) ~= 'string' then return {} end
    local ok, result = pcall(json.decode, value)
    return ok and type(result) == 'table' and result or {}
end

local function modelHash(value)
    if type(value) == 'string' and value:match('^[%w_]+$') then value = GetHashKey(value) end
    if type(value) ~= 'number' or value ~= value or value % 1 ~= 0 then return nil end
    value = value % 4294967296
    return value ~= 0 and value or nil
end

local function colour(value, fallback)
    if type(value) == 'number' and value % 1 == 0 and value >= 0 and value <= 255 then return value end
    return fallback or 0
end

local function appearance(properties, registration, fallback)
    properties, fallback = decode(properties), decode(fallback)
    local model = modelHash(registration.model)
    if not model then return nil end
    return {
        model = model, plate = registration.plate,
        color1 = colour(properties.color1, colour(fallback.color1)),
        color2 = colour(properties.color2, colour(fallback.color2)),
        pearlescentColor = colour(properties.pearlescentColor, colour(fallback.pearlescentColor)),
        wheelColor = colour(properties.wheelColor, colour(fallback.wheelColor)),
    }
end

local function owned(owner, registration)
    local rows = MySQL.query.await('SELECT * FROM owned_vehicles WHERE owner = ? AND UPPER(TRIM(plate)) = ? LIMIT 2', { owner, registration })
    if #rows ~= 1 then return nil end
    local row = rows[1]
    local props = decode(row.vehicle)
    local hash = modelHash(props.model)
    if not hash then return nil end
    -- These are public road garages. Aircraft and watercraft use their own depots.
    if row.type and row.type ~= 'car' and row.type ~= 'bike' and row.type ~= 'motorcycle' then return nil end
    row.properties, row.model, row.plate = props, hash, plate(row.plate)
    return row.plate and row or nil
end

local function getState(owner, row, garage)
    local wasOut = row.stored ~= nil and (row.stored == false or tonumber(row.stored) == 0)
    MySQL.insert.await('INSERT IGNORE INTO egg_garage_state (owner, plate, status, garage_id) VALUES (?, ?, ?, ?)', {
        owner, row.plate, wasOut and 'legacy_out' or 'stored', garage.id,
    })
    return MySQL.single.await('SELECT * FROM egg_garage_state WHERE owner = ? AND plate = ?', { owner, row.plate })
end

local function atGarage(source, id)
    local garage = type(id) == 'string' and garages[id] or nil
    if not garage or GetPlayerRoutingBucket(source) ~= 0 then return nil end
    return EggCore:RequireNear(source, garage.point, Config.ServerDistance) and garage or nil
end

local function anyVehicleWithPlate(registration)
    for _, vehicle in ipairs(GetAllVehicles()) do
        if DoesEntityExist(vehicle) and plate(GetVehicleNumberPlateText(vehicle)) == registration then return true end
    end
    return false
end

local function clearSpawn(garage)
    for _, vehicle in ipairs(GetAllVehicles()) do
        if DoesEntityExist(vehicle) and GetEntityRoutingBucket(vehicle) == 0 then
            local point = GetEntityCoords(vehicle)
            if (point.x - garage.spawn.x)^2 + (point.y - garage.spawn.y)^2 + (point.z - garage.spawn.z)^2 < Config.SpawnClearance^2 then return false end
        end
    end
    return true
end

local function suspended(owner)
    if GetResourceState('egg_police') ~= 'started' then return false end
    local ok, result = pcall(function() return exports.egg_police:IsLicenseSuspended(owner, 'driver') end)
    -- Fail closed if the active licence service cannot answer.
    return not ok or result == true
end

EggCore:RegisterAction('garages:list', { cooldown = 1200 }, function(source, xPlayer, data)
    local garage = atGarage(source, data.garage)
    if not garage then return fail('Visit a public garage first.') end
    local owner, vehicles = xPlayer.identifier, {}
    local rows = MySQL.query.await('SELECT * FROM owned_vehicles WHERE owner = ? LIMIT 150', { owner })
    for _, row in ipairs(rows) do
        row.plate, row.properties = plate(row.plate), decode(row.vehicle)
        row.model = modelHash(row.properties.model)
        if row.plate and row.model and (not row.type or row.type == 'car' or row.type == 'bike' or row.type == 'motorcycle') then
            local state = getState(owner, row, garage)
            vehicles[#vehicles + 1] = { plate = row.plate, model = row.model, status = state.status }
        end
    end
    return { ok = true, vehicles = vehicles }
end)

EggCore:RegisterAction('garages:withdraw', { cooldown = 3000 }, function(source, xPlayer, data)
    local garage, registration, owner = atGarage(source, data.garage), plate(data.plate), xPlayer.identifier
    if not garage or not registration then return fail('Visit a garage and select an owned vehicle.') end
    if suspended(owner) then return fail('Your driving licence is suspended. Contact the court before collecting a vehicle.') end
    return EggCore:WithLock('garage:spawn', function()
      return EggCore:WithLock('garage:plate:' .. registration, function()
        if EggCore:Identifier(source) ~= owner or not atGarage(source, garage.id) then return fail('Return to the garage collection point.') end
        if suspended(owner) then return fail('Your driving licence is suspended.') end
        local row = owned(owner, registration)
        if not row then return fail('That registration is not a road vehicle owned by you.') end
        local state = getState(owner, row, garage)
        if not state or state.status ~= 'stored' then return fail('That vehicle is already out or awaiting staff recovery.') end
        if anyVehicleWithPlate(registration) then return fail('That registration is already in the city. Staff can check the duplicate.') end
        if not clearSpawn(garage) then return fail('The collection bay is occupied. Clear it and try again.') end
        local token = ('%d:%d:%d'):format(os.time(), source, math.random(1, 2147483647))
        local changed = MySQL.update.await([[UPDATE egg_garage_state SET status = 'spawning', session_token = ?, net_id = NULL,
            garage_id = ? WHERE owner = ? AND plate = ? AND status = 'stored']], { token, garage.id, owner, registration })
        if changed ~= 1 then return fail('That vehicle is being collected. Try again shortly.') end
        local vehicle = 0
        local success, result = xpcall(function()
            vehicle = CreateVehicleServerSetter(row.model, motorcycleModels[row.model] and 'bike' or 'automobile', garage.spawn.x, garage.spawn.y, garage.spawn.z, garage.spawn.h)
            local deadline = GetGameTimer() + 5000
            while vehicle ~= 0 and not DoesEntityExist(vehicle) and GetGameTimer() < deadline do Wait(50) end
            if vehicle == 0 or not DoesEntityExist(vehicle) then error('Vehicle creation failed') end
            if EggCore:Identifier(source) ~= owner then error('Player disconnected during collection') end
            SetEntityRoutingBucket(vehicle, 0)
            if SetEntityOrphanMode then SetEntityOrphanMode(vehicle, 2) end
            SetVehicleNumberPlateText(vehicle, registration)
            Entity(vehicle).state:set('eggGarageSession', token, true)
            local netId = NetworkGetNetworkIdFromEntity(vehicle)
            if not netId or netId == 0 then error('Vehicle has no network ID') end
            local updated = MySQL.update.await([[UPDATE egg_garage_state SET status = 'out', net_id = ?
                WHERE owner = ? AND plate = ? AND status = 'spawning' AND session_token = ?]], { netId, owner, registration, token })
            if updated ~= 1 then error('Checkout reservation was lost') end
            local props = appearance(state.appearance, { model = row.model, plate = registration }, row.properties)
            EggCore:Log(source, 'garage', 'Collected ' .. registration .. ' from ' .. garage.id)
            return { ok = true, netId = netId, properties = props }
        end, debug.traceback)
        if not success then
            if vehicle ~= 0 and DoesEntityExist(vehicle) then
                DeleteEntity(vehicle)
                local deadline = GetGameTimer() + 2000
                while DoesEntityExist(vehicle) and GetGameTimer() < deadline do Wait(50) end
            end
            -- Never free a reservation while its spawned entity still exists.
            if vehicle == 0 or not DoesEntityExist(vehicle) then
                MySQL.update.await([[UPDATE egg_garage_state SET status = 'stored', net_id = NULL, session_token = NULL
                    WHERE owner = ? AND plate = ? AND session_token = ?]], { owner, registration, token })
            end
            print(('[egg_garages] Checkout failed for %s: %s'):format(registration, result))
            return fail('The collection bay could not release the vehicle. Try again or contact staff.')
        end
        return result
      end)
    end)
end)

EggCore:RegisterAction('garages:store', { cooldown = 2500 }, function(source, xPlayer, data)
    local garage, owner = atGarage(source, data.garage), xPlayer.identifier
    if not garage or type(data.netId) ~= 'number' or data.netId % 1 ~= 0 or data.netId <= 0 then return fail('Drive into a public garage to store your vehicle.') end
    local vehicle = NetworkGetEntityFromNetworkId(data.netId)
    local ped = GetPlayerPed(source)
    if vehicle == 0 or not DoesEntityExist(vehicle) or GetPedInVehicleSeat(vehicle, -1) ~= ped then return fail('You must be driving the vehicle.') end
    local registration = plate(GetVehicleNumberPlateText(vehicle))
    if not registration then return fail('This vehicle has no valid registration.') end
    return EggCore:WithLock('garage:plate:' .. registration, function()
        local row = owned(owner, registration)
        if EggCore:Identifier(source) ~= owner or not atGarage(source, garage.id) or not DoesEntityExist(vehicle) or GetPedInVehicleSeat(vehicle, -1) ~= GetPlayerPed(source) then
            return fail('Stay in the driver’s seat at the garage while the vehicle is checked.')
        end
        if not row or GetEntityModel(vehicle) % 4294967296 ~= row.model then return fail('The registration and model do not match your ownership record.') end
        local state = getState(owner, row, garage)
        if state.status ~= 'out' or tonumber(state.net_id) ~= data.netId or Entity(vehicle).state.eggGarageSession ~= state.session_token then
            return fail('This vehicle was not checked out through Egg garages. Staff can inspect older garage records.')
        end
        for _, player in ipairs(GetPlayers()) do
            if tonumber(player) ~= source and GetVehiclePedIsIn(GetPlayerPed(player), false) == vehicle then return fail('Ask your passengers to step out before storing.') end
        end
        -- Only bounded cosmetic colours are accepted; the database owns the model.
        local props = appearance(data.properties, { model = row.model, plate = registration }, appearance(state.appearance, { model = row.model, plate = registration }, row.properties))
        local changed = MySQL.update.await([[UPDATE egg_garage_state SET status = 'storing' WHERE owner = ? AND plate = ?
            AND status = 'out' AND session_token = ? AND net_id = ?]], { owner, registration, state.session_token, data.netId })
        if changed ~= 1 then return fail('The garage is already handling this vehicle.') end
        DeleteEntity(vehicle)
        local deadline = GetGameTimer() + 2000
        while DoesEntityExist(vehicle) and GetGameTimer() < deadline do Wait(50) end
        if DoesEntityExist(vehicle) then
            MySQL.update.await([[UPDATE egg_garage_state SET status = 'out' WHERE owner = ? AND plate = ? AND status = 'storing'
                AND session_token = ?]], { owner, registration, state.session_token })
            return fail('The vehicle could not be stored. Stay in the bay and try again.')
        end
        MySQL.update.await([[UPDATE egg_garage_state SET status = 'stored', garage_id = ?, appearance = ?, net_id = NULL,
            session_token = NULL WHERE owner = ? AND plate = ? AND status = 'storing' AND session_token = ?]], {
            garage.id, json.encode(props), owner, registration, state.session_token,
        })
        EggCore:Log(source, 'garage', 'Stored ' .. registration .. ' at ' .. garage.id)
        return { ok = true, message = 'Vehicle stored. You can collect it at any public garage.' }
    end)
end)

RegisterCommand('garagerecover', function(source, args)
    if source ~= 0 and not EggCore:IsStaff(source) then return end
    local target = tonumber(args[1])
    local registration = plate(table.concat(args, ' ', 2))
    local owner = target and EggCore:Identifier(target)
    local function tell(message)
        if source == 0 then print('[egg_garages] ' .. message) else EggCore:Notify(source, message) end
    end
    if not owner or not registration then tell('Usage: /garagerecover playerID registration'); return end
    EggCore:WithLock('garage:plate:' .. registration, function()
        if not owned(owner, registration) then tell('No matching ownership record.'); return end
        if anyVehicleWithPlate(registration) then tell('Recovery blocked: that registration still exists in the city.'); return end
        local changed = MySQL.update.await([[UPDATE egg_garage_state SET status = 'stored', net_id = NULL, session_token = NULL
            WHERE owner = ? AND plate = ? AND status <> 'stored']], { owner, registration })
        tell(changed == 1 and 'Recovery complete. The owner can collect the vehicle.' or 'No outstanding checkout to recover.')
        if changed == 1 then EggCore:Log(source, 'garage_recovery', 'Recovered ' .. registration .. ' for player ' .. target) end
    end)
end, false)
