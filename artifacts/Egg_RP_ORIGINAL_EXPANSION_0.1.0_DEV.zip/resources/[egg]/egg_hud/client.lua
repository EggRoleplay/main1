local ESX = exports.es_extended:getSharedObject()
local hunger, thirst, belt, lastVehicle = 100, 100, false, 0
local enabled = Config.Enabled
local function percent(n) return math.max(0, math.min(100, math.floor(tonumber(n) or 0))) end

CreateThread(function()
    while true do
        if GetResourceState(Config.NeedsResource) == 'started' then
            TriggerEvent('esx_status:getStatus', 'hunger', function(status) if status then hunger = percent(status.getPercent()) end end)
            TriggerEvent('esx_status:getStatus', 'thirst', function(status) if status then thirst = percent(status.getPercent()) end end)
        end
        Wait(2000)
    end
end)

CreateThread(function()
    while true do
        local ped, player = PlayerPedId(), PlayerId()
        local vehicle = GetVehiclePedIsIn(ped, false)
        if vehicle ~= lastVehicle then belt = false; lastVehicle = vehicle end
        local coords = GetEntityCoords(ped)
        local street, crossing = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
        local road = GetStreetNameFromHashKey(street)
        local cross = crossing ~= 0 and GetStreetNameFromHashKey(crossing) or ''
        local area = GetLabelText(GetNameOfZone(coords.x, coords.y, coords.z))
        local postal
        if GetResourceState('egg_work') == 'started' then
            local success, result = pcall(function() return exports.egg_work:NearestPostal(coords) end)
            if success then postal = result end
        end
        local voice = LocalPlayer.state.proximity
        local range = type(voice) == 'table' and tonumber(voice.distance) or nil
        local visible = enabled and NetworkIsPlayerActive(player) and not IsEntityDead(ped) and not LocalPlayer.state.eggSpawnSelecting and not (Config.HideOnPause and IsPauseMenuActive())
        SendNUIMessage({ action = 'state', visible = visible,
            health = percent((GetEntityHealth(ped) - 100) / math.max(1, GetEntityMaxHealth(ped) - 100) * 100),
            armour = percent(GetPedArmour(ped)), hunger = hunger, thirst = thirst,
            stamina = percent(GetPlayerSprintStaminaRemaining(player)),
            talking = NetworkIsPlayerTalking(player), range = range, road = road, cross = cross, area = area,
            showStatus = Config.Status, showLocation = Config.Location, showVehicle = Config.Vehicle,
            heading = math.floor(GetEntityHeading(ped)), compass = Config.Compass,
            showNumbers = Config.ShowNumbers, showStamina = Config.ShowStamina,
            postal = postal, stateLabel = Config.StateLabel, speedLimit = Config.DefaultSpeedLimit,
            vehicle = vehicle ~= 0, speed = vehicle ~= 0 and math.floor(GetEntitySpeed(vehicle) * 3.6 + 0.5) or 0,
            gear = vehicle ~= 0 and GetVehicleCurrentGear(vehicle) or 0,
            fuel = vehicle ~= 0 and percent(GetVehicleFuelLevel(vehicle)) or 0,
            engine = vehicle ~= 0 and percent(GetVehicleEngineHealth(vehicle) / 10) or 0,
            belt = belt, beltEnabled = Config.SeatbeltEnabled })
        Wait(visible and Config.UpdateMs or 1000)
    end
end)

CreateThread(function()
    while true do
        local vehicle = GetVehiclePedIsIn(PlayerPedId(), false)
        if Config.SeatbeltEnabled and vehicle ~= 0 and GetVehicleClass(vehicle) ~= 8 and GetVehicleClass(vehicle) ~= 13 then
            if IsControlJustReleased(0, Config.SeatbeltControl) then belt = not belt; PlaySoundFrontend(-1, 'SELECT', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true) end
            if belt then DisableControlAction(0, 75, true); DisableControlAction(27, 75, true) end
            Wait(0)
        else belt = false; Wait(600) end
    end
end)

RegisterCommand('egghud', function() enabled = not enabled end, false)
RegisterNetEvent('egg_hud:progress', function(data)
    if not Config.Progress or type(data) ~= 'table' then return end
    local duration = tonumber(data.duration)
    if not duration or duration < 100 or duration > 3600000 then return end
    SendNUIMessage({ action = 'progress', label = tostring(data.label or 'Working…'):sub(1, 100), duration = duration })
end)
RegisterNetEvent('egg_hud:progressStop', function() SendNUIMessage({ action = 'progressStop' }) end)

CreateThread(function()
    if not Config.PauseBranding then return end
    AddTextEntry('PM_SCR_MAP', 'Egg RP Map')
    AddTextEntry('PM_SCR_GAM', 'Game Options')
    AddTextEntry('PM_SCR_INF', 'Server Info')
    AddTextEntry('PM_SCR_STA', 'Session Stats')
    AddTextEntry('PM_SCR_SET', 'FiveM Settings')
    AddTextEntry('PM_SCR_GAL', 'In-Game Gallery')
    while true do
        local data = ESX.GetPlayerData()
        local name = data and (data.firstName or data.name) or GetPlayerName(PlayerId()) or 'mate'
        -- Strip GTA formatting markers supplied by an untrusted player name.
        name = tostring(name):gsub('~', ''):sub(1, 30)
        AddTextEntry('FE_THDR_GTAO', 'Egg~r~RP~s~ - Hello, ' .. name .. '!')
        Wait(5000)
    end
end)
AddEventHandler('onResourceStop', function(resource) if resource == GetCurrentResourceName() then SendNUIMessage({ action = 'state', visible = false }) end end)
