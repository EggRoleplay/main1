'use strict';
const byId = id => document.getElementById(id);
const hud = byId('hud');
const finite = value => Number.isFinite(Number(value)) ? Number(value) : 0;
const clamp = value => Math.max(0, Math.min(100, Math.round(finite(value))));
let progressFrame = null;
function stopProgress() {
  if (progressFrame !== null) cancelAnimationFrame(progressFrame);
  progressFrame = null;
  byId('progress').hidden = true;
}
window.addEventListener('message', ({ data: state }) => {
  if (!state) return;
  if (state.action === 'progressStop') { stopProgress(); return; }
  if (state.action === 'progress') {
    stopProgress();
    const duration = Math.max(100, Math.min(3600000, finite(state.duration)));
    const start = performance.now();
    byId('progress').hidden = false;
    byId('progress-label').textContent = String(state.label || 'Working…');
    const draw = now => {
      const amount = Math.min(100, (now - start) / duration * 100);
      byId('progress-fill').style.width = `${amount}%`;
      byId('progress').setAttribute('aria-valuenow', String(Math.floor(amount)));
      if (amount < 100) progressFrame = requestAnimationFrame(draw); else stopProgress();
    };
    progressFrame = requestAnimationFrame(draw);
    return;
  }
  if (state.action !== 'state') return;
  hud.hidden = !state.visible;
  byId('street').hidden = !state.showLocation;
  byId('status').hidden = !state.showStatus;
  for (const name of ['health', 'armour', 'hunger', 'thirst', 'stamina']) {
    const item = document.querySelector(`[data-stat="${name}"]`);
    const amount = clamp(state[name]);
    item.querySelector('span').textContent = amount;
    item.querySelector('span').hidden = !state.showNumbers;
    item.style.setProperty('--value', `${amount}%`);
    item.hidden = (name === 'stamina' && !state.showStamina) || (name === 'armour' && amount === 0);
    item.classList.toggle('low', amount < 20 && name !== 'armour');
  }
  byId('road').textContent = String(state.road || '');
  byId('area').textContent = [state.cross, state.area].filter(Boolean).join(' · ');
  const directions = ['N', 'NW', 'W', 'SW', 'S', 'SE', 'E', 'NE'];
  const heading = ((finite(state.heading) % 360) + 360) % 360;
  const sector = Math.round(heading / 45) % 8;
  byId('compass').hidden = !state.compass;
  byId('compass-heading').textContent = directions[sector];
  byId('compass-left').textContent = directions[(sector + 1) % 8];
  byId('compass-right').textContent = directions[(sector + 7) % 8];
  byId('voice').classList.toggle('talking', !!state.talking);
  byId('voice-range').textContent = state.range ? `${finite(state.range)} M` : 'VOICE';
  byId('vehicle').hidden = !(state.vehicle && state.showVehicle);
  byId('speed').textContent = String(Math.max(0, Math.round(finite(state.speed))));
  byId('speed-limit').textContent = `Speed limit: ${finite(state.speedLimit)} km/h`;
  byId('postal').hidden = !state.showLocation;
  byId('postal-code').textContent = state.postal ? `Nearest postal: ${state.postal.code} (${Math.round(finite(state.postal.distance))} m away)` : '';
  byId('postal-road').textContent = [state.stateLabel, state.road, state.area].filter(Boolean).join(' · ');
  byId('gear').textContent = state.gear === 0 ? 'N' : String(state.gear || 0);
  byId('fuel').textContent = `FUEL ${clamp(state.fuel)}`;
  byId('engine').textContent = `ENG ${clamp(state.engine)}`;
  byId('belt').hidden = !state.beltEnabled;
  byId('belt').textContent = state.belt ? 'BELT ON' : 'BELT OFF';
  byId('belt').classList.toggle('on', !!state.belt);
});
