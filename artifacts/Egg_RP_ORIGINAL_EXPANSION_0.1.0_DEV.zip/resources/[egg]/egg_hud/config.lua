Config = {}
-- No top-right markup is supplied. The existing identity/logo/server panel keeps its space.
Config.Enabled = true
Config.Status = true
Config.Location = true
Config.Vehicle = true
Config.HideOnPause = true
Config.UpdateMs = 250
Config.NeedsResource = 'esx_status'
Config.SeatbeltControl = 29 -- B; change if another script already manages seatbelts
Config.SeatbeltEnabled = true
Config.PauseBranding = true
Config.Compass = true
Config.Progress = true
Config.ShowNumbers = false
Config.ShowStamina = false
Config.DefaultSpeedLimit = 60
Config.StateLabel = 'VIC'
