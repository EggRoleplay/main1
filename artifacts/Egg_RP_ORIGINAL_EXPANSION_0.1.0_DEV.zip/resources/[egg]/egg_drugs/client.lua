local ESX = exports['es_extended']:getSharedObject()
local active, menuOpen, delivery, deliveryBlip = nil, false, nil, nil
local inLab = false

local function hudProgress(label, duration)
    if GetResourceState('egg_hud') == 'started' then TriggerEvent('egg_hud:progress', { label = label, duration = duration }) end
end
local function stopProgress()
    if GetResourceState('egg_hud') == 'started' then TriggerEvent('egg_hud:progressStop') end
end
local function loadInterior()
    RequestIpl(Config.Interior.ipl)
    local deadline = GetGameTimer() + 8000
    while not IsIplActive(Config.Interior.ipl) and GetGameTimer() < deadline do Wait(50) end
    if not IsIplActive(Config.Interior.ipl) then return false end
    local interior = GetInteriorAtCoords(1093.60, -3196.60, -38.99)
    if interior ~= 0 and IsValidInterior(interior) then
        PinInteriorInMemory(interior)
        for _, prop in ipairs(Config.Interior.props) do EnableInteriorProp(interior, prop) end
        RefreshInterior(interior)
    end
    return true
end

local function notify(message) ESX.ShowNotification(message) end
local function action(name, data, callback)
    exports.egg_core:Action(name, data, function(result)
        if not result or not result.ok then
            notify(result and result.error or 'No reply. Try again shortly.')
            if callback then callback(nil) end
            return
        end
        if result.message then notify(result.message) end
        if callback then callback(result) end
    end)
end
local function distance(coords, point) return #(coords - vector3(point.x, point.y, point.z)) end
local function openMenu(name, title, entries, callback)
    menuOpen = true
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), name,
        { title = title, align = 'top-left', elements = entries },
        function(data, menu) callback(data.current, menu) end,
        function(_, menu) menu.close() menuOpen = false end)
end
local function setDelivery(contract)
    if deliveryBlip then RemoveBlip(deliveryBlip) deliveryBlip = nil end
    delivery = contract
    if not delivery then return end
    delivery.deadline = GetGameTimer() + delivery.secondsRemaining * 1000
    deliveryBlip = AddBlipForCoord(delivery.drop.x, delivery.drop.y, delivery.drop.z)
    SetBlipSprite(deliveryBlip, 501)
    SetBlipColour(deliveryBlip, 5)
    SetBlipScale(deliveryBlip, 0.8)
    SetBlipRoute(deliveryBlip, true)
    SetBlipRouteColour(deliveryBlip, 5)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName('Delivery · ' .. delivery.drop.label)
    EndTextCommandSetBlipName(deliveryBlip)
end
local function cancelJob(message)
    if not active then return end
    local token = active.token
    active = nil
    ClearPedTasks(PlayerPedId())
    stopProgress()
    if token then action('drugs:cancel', { token = token }) end
    if message then notify(message) end
end
local function startJob(station, mode, recipe)
    if active then return end
    ESX.UI.Menu.CloseAll()
    menuOpen = false
    active = { station = station, pending = true }
    action('drugs:begin', { station = station.id, mode = mode, recipe = recipe }, function(result)
        if not result then active = nil return end
        if not active then action('drugs:cancel', { token = result.token }) return end
        active = { station = station, token = result.token, label = result.label,
            started = GetGameTimer(), duration = result.duration * 1000 + 250 }
        hudProgress(result.label .. '...', result.duration * 1000)
        if recipe == 'cocaine_cut' then
            local dict = 'anim@amb@business@coc@coc_unpack_cut_left@'
            RequestAnimDict(dict)
            local timeout = GetGameTimer() + 2000
            while not HasAnimDictLoaded(dict) and GetGameTimer() < timeout do Wait(25) end
            if active and HasAnimDictLoaded(dict) then
                TaskPlayAnim(PlayerPedId(), dict, 'coke_cut_v1_coccutter', 2.0, -2.0, -1, 1, 0.0, false, false, false)
            elseif active then TaskStartScenarioInPlace(PlayerPedId(), 'WORLD_HUMAN_HAMMERING', 0, true) end
        else
            TaskStartScenarioInPlace(PlayerPedId(), mode == 'process' and 'WORLD_HUMAN_HAMMERING' or 'WORLD_HUMAN_GARDENER_PLANT', 0, true)
        end
    end)
end
local function recipeMaterials(recipe)
    local parts = {}
    for item, count in pairs(recipe.inputs) do parts[#parts + 1] = count .. ' ' .. (Config.Labels[item] or item) end
    table.sort(parts)
    return table.concat(parts, ', ')
end
local function findRecipe(id)
    for _, recipe in ipairs(Config.Recipes) do if recipe.id == id then return recipe end end
end
local function stockMenu(status)
    local entries = {
        { label = ('Growing — level %d / %d XP'):format(status.cultivation.level, status.cultivation.xp) },
        { label = ('Street work — level %d / %d XP'):format(status.contraband.level, status.contraband.xp) }
    }
    for _, row in ipairs(status.stock or {}) do
        entries[#entries + 1] = { label = ('%s × %d — quality %d/100'):format(Config.Labels[row.item] or row.item, row.quantity, row.quality) }
    end
    if #status.stock == 0 then entries[#entries + 1] = { label = 'No registered stock' } end
    openMenu('stock', 'Your stock book', entries, function() end)
end
local function growMenu(station, status)
    local plant
    for _, row in ipairs(status.plants or {}) do if row.spot == station.id then plant = row break end end
    local entries = {}
    if plant then
        local remaining = math.max(0, tonumber(plant.ready_at) - status.now)
        entries[#entries + 1] = { label = ('Crop quality: %d/100'):format(plant.quality) }
        entries[#entries + 1] = remaining == 0 and { label = 'Harvest crop', mode = 'harvest' }
            or { label = ('Growing — about %d minutes left'):format(math.ceil(remaining / 60)) }
        entries[#entries + 1] = { label = 'Clear patch', clear = true }
    else
        entries[#entries + 1] = { label = 'Plant crop', mode = 'plant' }
        entries[#entries + 1] = { label = 'Needs: 1 cannabis seed + 1 grow supply crate' }
        entries[#entries + 1] = { label = ('Your planted crops: %d/%d'):format(#status.plants, Config.MaxPlants) }
    end
    openMenu('growing', station.label, entries, function(entry, menu)
        if entry.mode then startJob(station, entry.mode) end
        if entry.clear then
            menu.close()
            openMenu('clear', 'Clear this patch?', {
                { label = 'Keep the crop', keep = true }, { label = 'Clear it — crop and supplies are lost', clear = true }
            }, function(choice, confirmation)
                confirmation.close() menuOpen = false
                if choice.clear then action('drugs:clearPlant', { station = station.id }) end
            end)
        end
    end)
end
local function processingMenu(station, status)
    local entries = {}
    if station.type == 'lab' then
        local expires
        for _, lease in ipairs(status.leases or {}) do if lease.lab == station.id then expires = tonumber(lease.expires_at) end end
        if expires and expires > status.now then
            entries[#entries + 1] = { label = ('Bench rented — %d minutes remaining'):format(math.ceil((expires - status.now) / 60)) }
        else
            entries[#entries + 1] = { label = ('Rent a bench — $%d / %d hours'):format(Config.LeasePrice, Config.LeaseSeconds / 3600), lease = true }
        end
    end
    for _, id in ipairs(station.recipes or {}) do
        local recipe = findRecipe(id)
        entries[#entries + 1] = { label = recipe.label .. ' — level ' .. recipe.level, recipe = recipe }
    end
    entries[#entries + 1] = { label = 'Stock book', stock = true }
    openMenu('bench', station.label, entries, function(entry, menu)
        if entry.lease then menu.close() menuOpen = false action('drugs:lease', { station = station.id }) return end
        if entry.stock then menu.close() stockMenu(status) return end
        if not entry.recipe then return end
        menu.close()
        openMenu('job', entry.recipe.label, {
            { label = 'Needs: ' .. recipeMaterials(entry.recipe) },
            { label = ('Makes: %d %s'):format(entry.recipe.count, Config.Labels[entry.recipe.output]) },
            { label = 'Start work', start = true }
        }, function(choice) if choice.start then startJob(station, 'process', entry.recipe.id) end end)
    end)
end
local function stationMenu(station)
    if active then return end
    if station.type == 'exit' then action('drugs:exitLab', {}) return end
    if station.type == 'supply' then
        local entries = {}
        for _, stock in ipairs(Config.Supplies) do entries[#entries + 1] = { label = stock.label .. ' — $' .. stock.price, stock = stock } end
        openMenu('supplies', station.label, entries, function(entry, menu)
            menu.close()
            local amounts = {}
            for _, count in ipairs({ 1, 5, 10, 20 }) do
                if count <= Config.MaxTradeCount then amounts[#amounts + 1] = { label = ('Buy %d — $%d cash'):format(count, count * entry.stock.price), count = count } end
            end
            openMenu('amount', entry.stock.label, amounts, function(amount, amountMenu)
                action('drugs:supply', { station = station.id, item = entry.stock.item, count = amount.count }, function(result)
                    if result then amountMenu.close() menuOpen = false end
                end)
            end)
        end)
        return
    end
    action('drugs:status', {}, function(status)
        if not status then return end
        inLab = status.lab ~= nil
        setDelivery(status.contract)
        if station.type == 'grow' then growMenu(station, status)
        elseif station.type == 'process' or station.type == 'interior_process' then processingMenu(station, status)
        elseif station.type == 'lab' then
            local entries = { { label = 'Enter workshop', enter = true },
                { label = ('Rent a bench — $%d / %d hours'):format(Config.LeasePrice, Config.LeaseSeconds / 3600), lease = true } }
            openMenu('door', station.label, entries, function(entry, menu)
                menu.close() menuOpen = false
                if entry.lease then action('drugs:lease', { station = station.id })
                elseif entry.enter then
                    if not loadInterior() then notify('The workshop interior did not load. Try again shortly.') return end
                    action('drugs:enterLab', { station = station.id })
                end
            end)
        elseif station.type == 'dealer' then
            openMenu('contact', station.label, {
                { label = status.contract and 'Show outstanding drop' or 'Ask for a delivery', contract = true },
                { label = 'Stock book', stock = true }, { label = 'Cancel outstanding delivery', cancel = true }
            }, function(entry, menu)
                menu.close() menuOpen = false
                if entry.stock then stockMenu(status)
                elseif entry.cancel then
                    action('drugs:cancelContract', {}, function(result) if result then setDelivery(nil) end end)
                elseif entry.contract then
                    action('drugs:contract', { station = station.id }, function(result)
                        if result then
                            setDelivery(result.contract)
                            notify(('%s needs %d %s.'):format(result.contract.drop.label, result.contract.count, result.contract.label:lower()))
                        end
                    end)
                end
            end)
        end
    end)
end
RegisterCommand('stockbook', function()
    action('drugs:status', {}, function(status)
        if status then inLab = status.lab ~= nil setDelivery(status.contract) stockMenu(status) end
    end)
end, false)
RegisterCommand('passstock', function(_, args)
    action('drugs:handoff', { target = tonumber(args[1]), stock = args[2], count = tonumber(args[3]) })
end, false)

CreateThread(function()
    loadInterior()
    Wait(5000)
    exports.egg_core:Action('drugs:recoverLab', {}, function()
        Wait(200)
        exports.egg_core:Action('drugs:status', {}, function(result)
            if result and result.ok then inLab = result.lab ~= nil setDelivery(result.contract) end
        end)
    end)
end)
RegisterNetEvent('esx:playerLoaded', function()
    cancelJob()
    inLab = false
    Wait(1500)
    exports.egg_core:Action('drugs:recoverLab', {}, function()
        Wait(200)
        exports.egg_core:Action('drugs:status', {}, function(result)
            if result and result.ok then inLab = result.lab ~= nil setDelivery(result.contract) end
        end)
    end)
end)

RegisterNetEvent('egg_drugs:labTravel', function(point, entering)
    ESX.UI.Menu.CloseAll() menuOpen = false
    if active then cancelJob() end
    DoScreenFadeOut(250)
    Wait(300)
    if entering and not loadInterior() then
        notify('The workshop interior is unavailable. Returning outside.')
        DoScreenFadeIn(250)
        action('drugs:exitLab', {})
        return
    end
    inLab = entering == true
    RequestCollisionAtCoord(point.x, point.y, point.z)
    SetEntityCoords(PlayerPedId(), point.x, point.y, point.z, false, false, false, false)
    SetEntityHeading(PlayerPedId(), point.heading or 180.0)
    local timeout = GetGameTimer() + 5000
    while not HasCollisionLoadedAroundEntity(PlayerPedId()) and GetGameTimer() < timeout do Wait(50) end
    DoScreenFadeIn(250)
end)

CreateThread(function()
    while true do
        local sleep, ped = 1000, PlayerPedId()
        local coords = GetEntityCoords(ped)
        if delivery and GetGameTimer() > delivery.deadline then setDelivery(nil) end
        if active and not active.pending then
            sleep = 0
            local elapsed = GetGameTimer() - active.started
            if IsEntityDead(ped) or IsPedInAnyVehicle(ped, false) or distance(coords, active.station) > Config.CancelDistance then cancelJob('Job cancelled. You left the spot.')
            elseif IsControlJustReleased(0, 73) then cancelJob('Job cancelled.')
            elseif elapsed >= active.duration then
                local token = active.token
                active = nil
                ClearPedTasks(ped)
                stopProgress()
                action('drugs:finish', { token = token })
            else
                DisableControlAction(0, 24, true) DisableControlAction(0, 25, true) DisableControlAction(0, 37, true)
                if GetResourceState('egg_hud') ~= 'started' then
                    ESX.ShowHelpNotification(active.label .. '... ~INPUT_VEH_DUCK~ to cancel.')
                end
            end
        elseif not active then
            local nearest, nearestDistance
            local stations = Config.Stations
            if inLab then
                stations = {}
                for _, station in ipairs(Config.Interior.stations) do stations[#stations + 1] = station end
                stations[#stations + 1] = Config.Interior.exit
            end
            for _, station in ipairs(stations) do
                local metres = distance(coords, station)
                if metres < 20.0 then
                    sleep = 0
                    DrawMarker(2, station.x, station.y, station.z + 0.15, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0,
                        0.2, 0.2, 0.2, 218, 171, 87, 165, false, true, 2, false, nil, nil, false)
                end
                if metres < Config.InteractionDistance and (not nearestDistance or metres < nearestDistance) then nearest, nearestDistance = station, metres end
            end
            if delivery and distance(coords, delivery.drop) < 20.0 then
                sleep = 0
                DrawMarker(2, delivery.drop.x, delivery.drop.y, delivery.drop.z + 0.15, 0.0, 0.0, 0.0, 0.0, 180.0, 0.0,
                    0.3, 0.3, 0.3, 218, 171, 87, 200, false, true, 2, false, nil, nil, false)
                if distance(coords, delivery.drop) < Config.InteractionDistance and not menuOpen and not IsPedInAnyVehicle(ped, false) then
                    ESX.ShowHelpNotification('Press ~INPUT_CONTEXT~ to hand over the stock.')
                    if IsControlJustReleased(0, 38) then action('drugs:deliver', {}, function(result) if result then setDelivery(nil) end end) end
                end
            elseif nearest and not menuOpen and not IsPedInAnyVehicle(ped, false) and not IsEntityDead(ped) then
                ESX.ShowHelpNotification('Press ~INPUT_CONTEXT~ for ' .. nearest.label .. '.')
                if IsControlJustReleased(0, 38) then stationMenu(nearest) end
            end
        end
        Wait(sleep)
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        if active then ClearPedTasks(PlayerPedId()) end
        stopProgress()
        if deliveryBlip then RemoveBlip(deliveryBlip) end
        ESX.UI.Menu.CloseAll()
    end
end)
