local ESX = exports['es_extended']:getSharedObject()
local core = EggCore
local sessions, inside = {}, {}

local function failure(message) return { ok = false, error = message } end
local function find(list, key, value)
    for _, row in ipairs(list) do if row[key] == value then return row end end
end
local function integer(value, maximum)
    return type(value) == 'number' and value == value and value >= 1 and value % 1 == 0 and value <= maximum
end
local function level(source, key)
    return math.max(1, tonumber(core:GetSkill(source, key).level) or 1)
end
local function onFoot(source)
    local ped = GetPlayerPed(source)
    return ped ~= 0 and GetEntityHealth(ped) > 0 and GetVehiclePedIsIn(ped, false) == 0
end
local function stationAt(source, id)
    local station = type(id) == 'string' and find(Config.Stations, 'id', id)
    if not station and type(id) == 'string' then
        station = find(Config.Interior.stations, 'id', id)
        local room = inside[source]
        if not room or room.identifier ~= core:Identifier(source) or GetPlayerRoutingBucket(source) ~= room.bucket then return nil end
    end
    return station and core:RequireNear(source, station, Config.ValidationDistance) and station or nil
end
local function locked(source, fn)
    local identifier = core:Identifier(source)
    if not identifier then return failure('Your character is not ready.') end
    return core:WithLock('egg_drugs:' .. identifier, function()
        if core:Identifier(source) ~= identifier then return failure('Your character has changed. Try again.') end
        return fn()
    end)
end
local function transaction(queries)
    if #queries == 0 then return true end
    local ok, result = pcall(function() return MySQL.transaction.await(queries) end)
    return ok and result == true
end
local function hasInputs(source, inputs)
    for item, count in pairs(inputs) do if not core:HasItem(source, item, count) then return false end end
    return true
end
local function applyInventory(source, inputs, outputs, expectedIdentifier)
    if expectedIdentifier and core:Identifier(source) ~= expectedIdentifier then return nil, 'Your character has changed. Try again.' end
    local owner = expectedIdentifier or core:Identifier(source)
    local removed, added = {}, {}
    local function undo()
        if core:Identifier(source) ~= owner then
            core:Log(source, 'drugs', 'Disconnected during inventory rollback; staff must reconcile the original character.')
            return
        end
        for item, count in pairs(added) do core:RemoveItem(source, item, count) end
        for item, count in pairs(removed) do
            if not core:AddItem(source, item, count) then core:Log(source, 'drugs', 'Inventory rollback failed for ' .. item .. '.') end
        end
    end
    if not hasInputs(source, inputs) then return nil, 'You are missing the stock or supplies.' end
    for item, count in pairs(inputs) do
        if not core:RemoveItem(source, item, count) then undo() return nil, 'The stock could not be taken.' end
        removed[item] = count
    end
    for item, count in pairs(outputs) do
        if not core:AddItem(source, item, count) then undo() return nil, 'Make some room in your inventory first.' end
        added[item] = count
    end
    return undo
end
local function commitInventory(source, inputs, outputs, queries, identifier)
    local undo, reason = applyInventory(source, inputs, outputs, identifier)
    if not undo then return false, reason end
    if not transaction(queries) then undo() return false, 'The stock record could not be saved. Let staff know.' end
    return true
end

-- ESX stack inventories have no lot metadata. The server ledger binds accepted quantity
-- and weighted quality to its owner; only this resource's validated handoff moves ownership.
local function ledgerPlan(source, inputs)
    local identifier = core:Identifier(source)
    local queries, weightedQuality, total = {}, 0, 0
    for item, count in pairs(inputs) do
        if Config.TrackedItems[item] then
            local remaining = count
            local rows = MySQL.query.await([[
                SELECT id, quantity, quality FROM egg_drugs_lots
                WHERE identifier = ? AND item = ? AND quantity > 0 ORDER BY id
            ]], { identifier, item })
            for _, lot in ipairs(rows) do
                local take = math.min(remaining, tonumber(lot.quantity))
                if take > 0 then
                    queries[#queries + 1] = { query = 'UPDATE egg_drugs_lots SET quantity = quantity - ? WHERE id = ? AND identifier = ? AND quantity >= ?',
                        values = { take, lot.id, identifier, take } }
                    weightedQuality, total = weightedQuality + take * tonumber(lot.quality), total + take
                    remaining = remaining - take
                end
                if remaining == 0 then break end
            end
            if remaining > 0 then return nil, nil, 'That stock has no valid lot record. Use the supported stock handoff.' end
        end
    end
    return queries, total > 0 and math.floor(weightedQuality / total) or nil
end
local function addLot(queries, identifier, item, count, quality, origin)
    queries[#queries + 1] = {
        query = 'INSERT INTO egg_drugs_lots (identifier, item, quantity, quality, origin) VALUES (?, ?, ?, ?, ?)',
        values = { identifier, item, count, quality, origin }
    }
end
local function leaseActive(identifier, lab)
    local expires = MySQL.scalar.await('SELECT expires_at FROM egg_drugs_leases WHERE identifier = ? AND lab = ?', { identifier, lab })
    return tonumber(expires or 0) > os.time()
end
local function sendOutside(source, room)
    if core:Identifier(source) ~= room.identifier then return false end
    SetPlayerRoutingBucket(source, room.returnBucket)
    local ped = GetPlayerPed(source)
    if ped ~= 0 then SetEntityCoords(ped, room.exterior.x, room.exterior.y, room.exterior.z, false, false, false, false) end
    TriggerClientEvent('egg_drugs:labTravel', source, room.exterior, false)
    inside[source], sessions[source] = nil, nil
    return true
end
local function allowedRecipe(station, id)
    for _, recipeId in ipairs(station.recipes or {}) do if recipeId == id then return find(Config.Recipes, 'id', id) end end
end
local function currentContract(identifier)
    return MySQL.single.await('SELECT * FROM egg_drugs_contracts WHERE identifier = ?', { identifier })
end
local function contractView(row)
    if not row or row.status ~= 'active' or tonumber(row.expires_at) <= os.time() then return nil end
    local drop = find(Config.Drops, 'id', row.drop_id)
    return drop and { item = row.item, label = Config.Labels[row.item], count = tonumber(row.quantity), drop = drop,
        expires = tonumber(row.expires_at), earliest = tonumber(row.min_complete_at),
        secondsRemaining = math.max(0, tonumber(row.expires_at) - os.time()) } or nil
end

core:RegisterAction('drugs:status', { cooldown = 1500 }, function(source)
    local identifier = core:Identifier(source)
    local stock = MySQL.query.await([[
        SELECT item, SUM(quantity) AS quantity, FLOOR(SUM(quantity * quality) / SUM(quantity)) AS quality
        FROM egg_drugs_lots WHERE identifier = ? AND quantity > 0 GROUP BY item
    ]], { identifier })
    return { ok = true, now = os.time(),
        cultivation = core:GetSkill(source, 'cultivation'), contraband = core:GetSkill(source, 'contraband'),
        plants = MySQL.query.await('SELECT spot, ready_at, quality, yield_count FROM egg_drugs_plants WHERE identifier = ?', { identifier }),
        leases = MySQL.query.await('SELECT lab, expires_at FROM egg_drugs_leases WHERE identifier = ?', { identifier }),
        stock = stock, contract = contractView(currentContract(identifier)),
        lab = inside[source] and inside[source].identifier == identifier and inside[source].lab or nil }
end)

core:RegisterAction('drugs:supply', { cooldown = 750 }, function(source, _, data)
    return locked(source, function()
        local station = stationAt(source, data.station)
        local stock = type(data.item) == 'string' and find(Config.Supplies, 'item', data.item)
        if not station or station.type ~= 'supply' or not stock or not integer(data.count, Config.MaxTradeCount) then
            return failure('Choose an amount at the supply counter.')
        end
        local cost = stock.price * data.count
        if not core:TryDebit(source, cost, 'money') then return failure('Bring enough cash for the supplies.') end
        if not core:AddItem(source, stock.item, data.count) then
            if not core:Credit(source, cost, 'money') then core:Log(source, 'drugs', 'Supply refund failed for $' .. cost) end
            return failure('Make some room in your inventory first.')
        end
        return { ok = true, message = ('Bought %d %s for $%d.'):format(data.count, stock.label:lower(), cost) }
    end)
end)

core:RegisterAction('drugs:lease', { cooldown = 1000 }, function(source, _, data)
    return locked(source, function()
        local station = stationAt(source, data.station)
        if not station or station.type ~= 'lab' then return failure('Visit the workshop to rent a bench.') end
        local identifier = core:Identifier(source)
        if leaseActive(identifier, station.id) then return failure('You already have an active rental here.') end
        if core:Identifier(source) ~= identifier then return failure('Your character has changed. Try again.') end
        if not core:TryDebit(source, Config.LeasePrice, 'bank') then return failure('There is not enough in your bank account for the rental.') end
        if not transaction({ { query = 'INSERT INTO egg_drugs_leases (identifier, lab, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE expires_at = VALUES(expires_at)',
            values = { identifier, station.id, os.time() + Config.LeaseSeconds } } }) then
            if core:Identifier(source) ~= identifier or not core:Credit(source, Config.LeasePrice, 'bank') then core:Log(source, 'drugs', 'Rental refund failed for $' .. Config.LeasePrice) end
            return failure('The rental could not be saved.')
        end
        return { ok = true, message = ('Bench rented for %d hours.'):format(math.floor(Config.LeaseSeconds / 3600)) }
    end)
end)

core:RegisterAction('drugs:enterLab', { cooldown = 1500 }, function(source, _, data)
    return locked(source, function()
        local station = stationAt(source, data.station)
        if not station or station.type ~= 'lab' or not onFoot(source) then return failure('Walk up to the workshop door first.') end
        local identifier = core:Identifier(source)
        if inside[source] then return failure('You are already inside a workshop.') end
        if not leaseActive(identifier, station.id) then return failure('Rent a bench here before going inside.') end
        if core:Identifier(source) ~= identifier then return failure('Your character changed. Try again.') end
        if not onFoot(source) or not core:RequireNear(source, station, Config.ValidationDistance) then return failure('Stay at the workshop door while it unlocks.') end
        local room = { identifier = identifier, lab = station.id, exterior = station,
            bucket = Config.LabBucketBase + source, returnBucket = GetPlayerRoutingBucket(source) }
        inside[source] = room
        SetRoutingBucketPopulationEnabled(room.bucket, false)
        SetRoutingBucketEntityLockdownMode(room.bucket, 'strict')
        SetPlayerRoutingBucket(source, room.bucket)
        local ped = GetPlayerPed(source)
        SetEntityCoords(ped, Config.Interior.entry.x, Config.Interior.entry.y, Config.Interior.entry.z, false, false, false, false)
        TriggerClientEvent('egg_drugs:labTravel', source, Config.Interior.entry, true)
        return { ok = true, message = 'Workshop unlocked.' }
    end)
end)

core:RegisterAction('drugs:exitLab', { cooldown = 1000 }, function(source)
    local room = inside[source]
    if not room or room.identifier ~= core:Identifier(source) then return failure('You are not in a workshop.') end
    if GetPlayerRoutingBucket(source) ~= room.bucket or not core:RequireNear(source, Config.Interior.exit, Config.ValidationDistance) then
        return failure('Use the workshop exit door.')
    end
    if not sendOutside(source, room) then return failure('Your character has changed.') end
    return { ok = true }
end)

core:RegisterAction('drugs:recoverLab', { cooldown = 2000 }, function(source)
    if not inside[source] and core:RequireNear(source, Config.Interior.entry, 45.0) then
        local exterior = find(Config.Stations, 'id', 'city_lab')
        local room = { identifier = core:Identifier(source), returnBucket = 0, exterior = exterior }
        sendOutside(source, room)
    end
    return { ok = true }
end)

core:RegisterAction('drugs:begin', { cooldown = 1000 }, function(source, _, data)
    return locked(source, function()
        local station = stationAt(source, data.station)
        if not station or not onFoot(source) then return failure('Walk up to the work spot first.') end
        if sessions[source] and sessions[source].expires > os.time() then return failure('Finish or cancel the current job first.') end
        local identifier, mode, inputs, recipe, plant = core:Identifier(source), data.mode, {}, nil, nil
        local duration, label
        if station.type == 'grow' then
            plant = MySQL.single.await('SELECT * FROM egg_drugs_plants WHERE identifier = ? AND spot = ?', { identifier, station.id })
            if mode == 'plant' then
                if plant then return failure('There is already a crop here.') end
                local count = tonumber(MySQL.scalar.await('SELECT COUNT(*) FROM egg_drugs_plants WHERE identifier = ?', { identifier })) or 0
                if count >= Config.MaxPlants then return failure('You already have enough crops on the go.') end
                inputs = { egg_weed_seed = 1, egg_grow_crate = 1 }
                duration, label = Config.PlantSeconds, 'Setting up the growing patch'
            elseif mode == 'harvest' then
                if not plant or tonumber(plant.ready_at) > os.time() then return failure('This crop is not ready yet.') end
                duration, label = Config.HarvestSeconds, 'Collecting the green crop'
            else return failure('Choose plant or harvest.') end
        elseif station.type == 'process' or station.type == 'interior_process' then
            mode = 'process'
            recipe = allowedRecipe(station, data.recipe)
            if not recipe then return failure('That job is not available at this bench.') end
            if station.type == 'interior_process' and not leaseActive(identifier, inside[source].lab) then return failure('The workshop rental has expired.') end
            if level(source, recipe.stage) < recipe.level then return failure('You need more experience for that job.') end
            inputs, duration, label = recipe.inputs, recipe.duration, recipe.label
        else return failure('This spot does not have a production bench.') end
        if not hasInputs(source, inputs) then return failure('You are missing the stock or supplies.') end
        local plan, _, why = ledgerPlan(source, inputs)
        if not plan then return failure(why) end
        if core:Identifier(source) ~= identifier then return failure('Your character has changed. Try again.') end
        local token = ('%d:%d:%d'):format(source, os.time(), math.random(100000, 999999))
        sessions[source] = { token = token, identifier = identifier, station = station, mode = mode,
            inputs = inputs, recipe = recipe, plant = plant, ready = os.time() + duration,
            expires = os.time() + duration + Config.SessionGrace }
        return { ok = true, token = token, duration = duration, label = label, mode = mode }
    end)
end)

core:RegisterAction('drugs:finish', { cooldown = 500 }, function(source, _, data)
    return locked(source, function()
        local session = sessions[source]
        if not session or session.token ~= data.token or session.identifier ~= core:Identifier(source) then return failure('That job has ended.') end
        if os.time() > session.expires then sessions[source] = nil return failure('That job has expired.') end
        if os.time() < session.ready then return failure('The job is still running.') end
        if not onFoot(source) or not core:RequireNear(source, session.station, Config.ValidationDistance) then
            sessions[source] = nil return failure('You left the work spot. Start again when you are ready.')
        end
        sessions[source] = nil
        local queries, quality, why = ledgerPlan(source, session.inputs)
        if not queries then return failure(why) end
        local outputs, xp, skillName, message = {}, 0, 'cultivation', nil
        if session.mode == 'plant' then
            local occupied = MySQL.scalar.await('SELECT id FROM egg_drugs_plants WHERE identifier = ? AND spot = ?', { session.identifier, session.station.id })
            local count = tonumber(MySQL.scalar.await('SELECT COUNT(*) FROM egg_drugs_plants WHERE identifier = ?', { session.identifier })) or 0
            if occupied or count >= Config.MaxPlants then return failure('That patch is no longer available.') end
            quality = math.min(95, math.random(40, 65) + level(source, 'cultivation') * 2)
            local yield = math.random(5, 8)
            queries[#queries + 1] = { query = 'INSERT INTO egg_drugs_plants (identifier, spot, ready_at, quality, yield_count) VALUES (?, ?, ?, ?, ?)',
                values = { session.identifier, session.station.id, os.time() + Config.GrowSeconds, quality, yield } }
            xp, message = 10, ('Patch planted. Check back in %d minutes.'):format(math.ceil(Config.GrowSeconds / 60))
        elseif session.mode == 'harvest' then
            local plant = MySQL.single.await('SELECT * FROM egg_drugs_plants WHERE id = ? AND identifier = ?', { session.plant.id, session.identifier })
            if not plant or tonumber(plant.ready_at) > os.time() then return failure('That crop is not ready or has already been collected.') end
            quality = tonumber(plant.quality)
            outputs.egg_weed_crop = tonumber(plant.yield_count)
            queries[#queries + 1] = { query = 'DELETE FROM egg_drugs_plants WHERE id = ? AND identifier = ?', values = { plant.id, session.identifier } }
            addLot(queries, session.identifier, 'egg_weed_crop', outputs.egg_weed_crop, quality, 'plant:' .. plant.id)
            xp, message = 35, ('Collected %d green crop. Quality: %d/100.'):format(outputs.egg_weed_crop, quality)
        else
            local recipe = session.recipe
            if session.station.type == 'interior_process' then
                local room = inside[source]
                if not room or room.identifier ~= session.identifier or GetPlayerRoutingBucket(source) ~= room.bucket or not leaseActive(session.identifier, room.lab) then
                    return failure('The workshop rental has expired or you have left it.')
                end
            end
            if level(source, recipe.stage) < recipe.level then return failure('You do not have the required experience.') end
            quality = math.min(95, math.max(1, (quality or recipe.baseQuality or 40) + math.random(-3, 3) + math.min(4, level(source, recipe.stage))))
            outputs[recipe.output] = recipe.count
            addLot(queries, session.identifier, recipe.output, recipe.count, quality, 'recipe:' .. recipe.id)
            xp, skillName, message = recipe.xp, recipe.stage, ('%s ready. Quality: %d/100.'):format(Config.Labels[recipe.output], quality)
        end
        local success, reason = commitInventory(source, session.inputs, outputs, queries, session.identifier)
        if not success then return failure(reason) end
        if core:Identifier(source) == session.identifier then core:AddXP(source, skillName, xp) end
        return { ok = true, message = message }
    end)
end)

core:RegisterAction('drugs:cancel', { cooldown = 200 }, function(source, _, data)
    if sessions[source] and sessions[source].token == data.token then sessions[source] = nil end
    return { ok = true }
end)

core:RegisterAction('drugs:contract', { cooldown = 1500 }, function(source, _, data)
    return locked(source, function()
        local station = stationAt(source, data.station)
        if not station or station.type ~= 'dealer' then return failure('Speak to your contact first.') end
        local identifier = core:Identifier(source)
        local previous = currentContract(identifier)
        if contractView(previous) then return { ok = true, contract = contractView(previous), message = 'You still have an outstanding delivery.' } end
        if previous and tonumber(previous.next_available) > os.time() then return failure('The contact is laying low. Come back shortly.') end
        local eligible = {}
        for _, product in ipairs(Config.Contract.products) do
            if level(source, 'contraband') >= product.level and core:HasItem(source, product.item, Config.Contract.minCount) then
                local plan = ledgerPlan(source, { [product.item] = Config.Contract.minCount })
                if plan then eligible[#eligible + 1] = product end
            end
        end
        if #eligible == 0 then return failure('Bring at least two sealed stock with valid lot records.') end
        local product, count = eligible[math.random(1, #eligible)], math.random(Config.Contract.minCount, Config.Contract.maxCount)
        while count > Config.Contract.minCount and not core:HasItem(source, product.item, count) do count = count - 1 end
        local plan, quality, why = ledgerPlan(source, { [product.item] = count })
        if not plan then return failure(why) end
        local drop = Config.Drops[math.random(1, #Config.Drops)]
        local now = os.time()
        if not transaction({ { query = [[
            INSERT INTO egg_drugs_contracts (identifier, status, item, quantity, drop_id, quality_quote, base_price, min_complete_at, expires_at, next_available)
            VALUES (?, 'active', ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE status = 'active', item = VALUES(item), quantity = VALUES(quantity), drop_id = VALUES(drop_id),
            quality_quote = VALUES(quality_quote), base_price = VALUES(base_price), min_complete_at = VALUES(min_complete_at),
            expires_at = VALUES(expires_at), next_available = VALUES(next_available)
        ]], values = { identifier, product.item, count, drop.id, quality, product.basePrice,
            now + Config.Contract.minimumTravelSeconds, now + Config.Contract.seconds, now + Config.Contract.seconds + Config.Contract.cooldown } } }) then
            return failure('The delivery could not be booked.')
        end
        return { ok = true, contract = contractView(currentContract(identifier)), message = 'The contact sent you a drop. Take your stock there.' }
    end)
end)

core:RegisterAction('drugs:deliver', { cooldown = 1000 }, function(source)
    return locked(source, function()
        local identifier, now = core:Identifier(source), os.time()
        local row = currentContract(identifier)
        local contract = contractView(row)
        if not contract then return failure('You do not have an active delivery.') end
        if now < tonumber(row.min_complete_at) then return failure('The buyer is not ready yet. Give them a moment.') end
        if not onFoot(source) or not core:RequireNear(source, contract.drop, Config.ValidationDistance) then return failure('Walk up to the delivery address first.') end
        local inputs = { [row.item] = tonumber(row.quantity) }
        local queries, quality, why = ledgerPlan(source, inputs)
        if not queries then return failure(why) end
        quality = math.min(quality, tonumber(row.quality_quote))
        local payout = math.floor(tonumber(row.base_price) * tonumber(row.quantity) * (0.75 + quality / 200))
        local undo, reason = applyInventory(source, inputs, {}, identifier)
        if not undo then return failure(reason) end
        if not core:Credit(source, payout, 'money') then undo() return failure('The payment could not be completed.') end
        queries[#queries + 1] = { query = "UPDATE egg_drugs_contracts SET status = 'completed', next_available = ? WHERE identifier = ? AND status = 'active'",
            values = { now + Config.Contract.cooldown, identifier } }
        if not transaction(queries) then
            if core:Identifier(source) ~= identifier or not core:TryDebit(source, payout, 'money') then core:Log(source, 'drugs', 'Contract payment rollback failed for $' .. payout) end
            undo()
            return failure('The delivery could not be recorded. Let staff know.')
        end
        if core:Identifier(source) == identifier then core:AddXP(source, 'contraband', 30) end
        core:Log(source, 'drugs', ('Delivered %d %s, quality %d, paid $%d.'):format(row.quantity, row.item, quality, payout))
        if core:Identifier(source) == identifier and Config.DispatchChance > 0 and math.random(1, 100) <= Config.DispatchChance and GetResourceState(Config.PoliceResource) == 'started' then
            local dispatched = pcall(function() exports[Config.PoliceResource]:Dispatch(source, 'Reports of a suspected street handover') end)
            if not dispatched then core:Log(source, 'drugs', 'Dispatch export failed; check police resource configuration.') end
        end
        return { ok = true, message = ('Delivery done. $%d cash.'):format(payout) }
    end)
end)

core:RegisterAction('drugs:clearPlant', { cooldown = 1000 }, function(source, _, data)
    return locked(source, function()
        local station = stationAt(source, data.station)
        if not station or station.type ~= 'grow' then return failure('Walk up to your growing patch first.') end
        if not transaction({ { query = 'DELETE FROM egg_drugs_plants WHERE identifier = ? AND spot = ?',
            values = { core:Identifier(source), station.id } } }) then return failure('The patch could not be cleared.') end
        sessions[source] = nil
        return { ok = true, message = 'Patch cleared. The crop and supplies are gone.' }
    end)
end)

core:RegisterAction('drugs:cancelContract', { cooldown = 1000 }, function(source)
    return locked(source, function()
        local identifier = core:Identifier(source)
        if not transaction({ { query = "UPDATE egg_drugs_contracts SET status = 'cancelled', next_available = ? WHERE identifier = ? AND status = 'active'",
            values = { os.time() + Config.Contract.cooldown, identifier } } }) then return failure('The cancellation could not be saved.') end
        return { ok = true, message = 'Delivery cancelled. Give the contact some time.' }
    end)
end)

core:RegisterAction('drugs:handoff', { cooldown = 1000 }, function(source, _, data)
    if not integer(data.target, 65535) or data.target == source or not integer(data.count, Config.MaxTradeCount) then return failure('Use /passstock playerID stock amount.') end
    local item = type(data.stock) == 'string' and Config.TransferAliases[data.stock]
    if not item then return failure('Stock types: crop, trim, green, batch, crystal, coke_batch, cocaine.') end
    local identifier, targetIdentifier = core:Identifier(source), core:Identifier(data.target)
    if not identifier or not targetIdentifier or identifier == targetIdentifier then return failure('Choose a nearby player.') end
    local first, second = identifier, targetIdentifier
    if first > second then first, second = second, first end
    return core:WithLock('egg_drugs:' .. first, function()
        return core:WithLock('egg_drugs:' .. second, function()
            if core:Identifier(data.target) ~= targetIdentifier or GetPlayerRoutingBucket(source) ~= GetPlayerRoutingBucket(data.target) then return failure('Choose a nearby player.') end
            local targetPed = GetPlayerPed(data.target)
            if targetPed == 0 then return failure('That player is unavailable.') end
            local position = GetEntityCoords(targetPed)
            local targetPosition = { x = position.x, y = position.y, z = position.z }
            if not core:RequireNear(source, targetPosition, 3.0) then return failure('Stand next to the other player.') end
            local queries, quality, why = ledgerPlan(source, { [item] = data.count })
            if not queries then return failure(why) end
            -- MySQL awaits above can span a disconnect and a numeric player-ID reuse.
            if core:Identifier(source) ~= identifier or core:Identifier(data.target) ~= targetIdentifier then return failure('That player has changed character. Try again.') end
            local currentPed = GetPlayerPed(data.target)
            if currentPed == 0 then return failure('That player is unavailable.') end
            local currentPosition = GetEntityCoords(currentPed)
            if GetPlayerRoutingBucket(source) ~= GetPlayerRoutingBucket(data.target) or not core:RequireNear(source, { x = currentPosition.x, y = currentPosition.y, z = currentPosition.z }, 3.0) then return failure('Stand next to the other player.') end
            if not core:RemoveItem(source, item, data.count) then return failure('You do not have that stock.') end
            if not core:AddItem(data.target, item, data.count) then
                if not core:AddItem(source, item, data.count) then core:Log(source, 'drugs', 'Stock handoff refund failed.') end
                return failure('The other player cannot carry it.')
            end
            addLot(queries, targetIdentifier, item, data.count, quality, 'handoff:' .. source)
            if not transaction(queries) then
                if core:Identifier(data.target) == targetIdentifier then core:RemoveItem(data.target, item, data.count)
                else core:Log(source, 'drugs', 'Recipient disconnected during stock rollback; staff must reconcile.') end
                if core:Identifier(source) ~= identifier or not core:AddItem(source, item, data.count) then core:Log(source, 'drugs', 'Stock handoff database rollback failed.') end
                return failure('The handoff could not be recorded.')
            end
            if core:Identifier(data.target) == targetIdentifier then core:Notify(data.target, ('Received %d %s. Quality: %d/100.'):format(data.count, Config.Labels[item]:lower(), quality)) end
            return { ok = true, message = 'Stock passed over.' }
        end)
    end)
end)

AddEventHandler('playerDropped', function() sessions[source], inside[source] = nil, nil end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for player, room in pairs(inside) do sendOutside(player, room) end
end)
CreateThread(function()
    while true do
        Wait(60000)
        local now = os.time()
        for player, session in pairs(sessions) do if session.expires < now then sessions[player] = nil end end
    end
end)
