Config = {}
Config.InteractionDistance = 2.0
Config.ValidationDistance = 4.0
Config.CancelDistance = 7.0
Config.SessionGrace = 60
Config.MaxTradeCount = 20
Config.MaxPlants = 2
Config.GrowSeconds = 900
Config.PlantSeconds = 12
Config.HarvestSeconds = 15
Config.LeaseSeconds = 86400
Config.LeasePrice = 2400
Config.DispatchChance = 15
Config.PoliceResource = 'egg_police'
Config.LabBucketBase = 500000 -- Reserve this range from other routing/instance resources.

Config.Interior = {
    ipl = 'bkr_biker_interior_placement_interior_4_biker_dlc_int_ware03_milo',
    entry = { x = 1088.67, y = -3187.91, z = -38.99, heading = 180.0 },
    exit = { id = 'lab_exit', type = 'exit', label = 'Workshop exit', x = 1088.67, y = -3187.91, z = -38.99 },
    props = { 'coke_basic', 'coke_equipment_basic', 'coke_cut_01', 'coke_cut_02', 'coke_cut_03', 'coke_stock' },
    stations = {
        { id = 'cocaine_cut', type = 'interior_process', label = 'Cutting bench', x = 1093.17, y = -3195.32, z = -38.99, recipes = { 'cocaine_cut' } },
        { id = 'cocaine_pack', type = 'interior_process', label = 'Packing bench', x = 1100.20, y = -3199.73, z = -38.99, recipes = { 'cocaine_pack' } },
        { id = 'lab_batch', type = 'interior_process', label = 'Side bench', x = 1102.18, y = -3193.66, z = -38.99, recipes = { 'batch', 'sealed_pack' } }
    }
}

Config.Stations = {
    { id = 'supplies', type = 'supply', label = 'Back lane supplies', x = 1408.47, y = -1490.47, z = 60.66 },
    { id = 'grow_1', type = 'grow', label = 'Grapeseed growing patch', x = 2222.65, y = 5576.08, z = 53.82 },
    { id = 'grow_2', type = 'grow', label = 'Grapeseed growing patch', x = 2225.78, y = 5578.33, z = 53.84 },
    { id = 'grow_3', type = 'grow', label = 'Grapeseed growing patch', x = 2228.28, y = 5580.35, z = 53.87 },
    { id = 'grow_4', type = 'grow', label = 'Grapeseed growing patch', x = 2231.34, y = 5582.60, z = 53.86 },
    { id = 'trim', type = 'process', label = 'Grapeseed trimming bench', x = 1963.39, y = 5181.52, z = 47.98, recipes = { 'trim', 'green_pack' } },
    { id = 'city_lab', type = 'lab', label = 'La Mesa private workshop', x = 1184.78, y = -3110.60, z = 6.03 },
    { id = 'county_lab', type = 'lab', label = 'Sandy private shed', x = 1391.47, y = 3605.31, z = 38.94 },
    { id = 'contact_city', type = 'dealer', label = 'Davis contact', x = 117.96, y = -1946.50, z = 20.75 },
    { id = 'contact_county', type = 'dealer', label = 'Sandy contact', x = 1684.79, y = 3854.93, z = 34.91 }
}

Config.Supplies = {
    { item = 'egg_weed_seed', label = 'Cannabis seed', price = 35 },
    { item = 'egg_grow_crate', label = 'Grow supply crate', price = 70 },
    { item = 'egg_packaging', label = 'Plain packaging', price = 15 },
    { item = 'egg_lab_crate', label = 'Lab supply crate', price = 140 },
    { item = 'egg_coca_crate', label = 'Cocaine supply crate', price = 150 }
}

-- Abstract GTA item transformations only. These are not chemical formulas or real production instructions.
Config.Recipes = {
    { id = 'trim', label = 'Trim cannabis', level = 1, duration = 20, xp = 18,
      inputs = { egg_weed_crop = 3 }, output = 'egg_weed_trim', count = 2, stage = 'cultivation' },
    { id = 'green_pack', label = 'Bag cannabis', level = 1, duration = 18, xp = 16,
      inputs = { egg_weed_trim = 2, egg_packaging = 1 }, output = 'egg_weed_pack', count = 1, stage = 'cultivation' },
    { id = 'batch', label = 'Prepare lab batch', level = 3, duration = 30, xp = 25,
      inputs = { egg_lab_crate = 1, egg_packaging = 1 }, output = 'egg_lab_batch', count = 2, baseQuality = 45, stage = 'contraband' },
    { id = 'sealed_pack', label = 'Seal crystal stock', level = 5, duration = 35, xp = 30,
      inputs = { egg_lab_batch = 2, egg_packaging = 2 }, output = 'egg_lab_pack', count = 1, stage = 'contraband' },
    { id = 'cocaine_cut', label = 'Cutting cocaine', level = 3, duration = 30, xp = 25,
      inputs = { egg_coca_crate = 1 }, output = 'egg_cocaine_batch', count = 2, baseQuality = 50, stage = 'contraband' },
    { id = 'cocaine_pack', label = 'Bagging cocaine', level = 3, duration = 25, xp = 22,
      inputs = { egg_cocaine_batch = 2, egg_packaging = 1 }, output = 'egg_cocaine_bag', count = 1, stage = 'contraband' }
}
Config.TrackedItems = {
    egg_weed_crop = true, egg_weed_trim = true, egg_weed_pack = true,
    egg_lab_batch = true, egg_lab_pack = true, egg_cocaine_batch = true, egg_cocaine_bag = true
}
Config.Labels = {
    egg_weed_seed = 'Cannabis seed', egg_grow_crate = 'Grow supply crate', egg_packaging = 'Plain packaging',
    egg_lab_crate = 'Lab supply crate', egg_weed_crop = 'Harvested cannabis', egg_weed_trim = 'Trimmed cannabis',
    egg_weed_pack = 'Bagged cannabis', egg_lab_batch = 'Unsealed batch', egg_lab_pack = 'Sealed crystal stock',
    egg_coca_crate = 'Cocaine supply crate', egg_cocaine_batch = 'Cut cocaine batch', egg_cocaine_bag = 'Bagged cocaine'
}
Config.TransferAliases = { crop = 'egg_weed_crop', trim = 'egg_weed_trim', green = 'egg_weed_pack', batch = 'egg_lab_batch', crystal = 'egg_lab_pack', coke_batch = 'egg_cocaine_batch', cocaine = 'egg_cocaine_bag' }

Config.Contract = { seconds = 600, minimumTravelSeconds = 45, cooldown = 120, minCount = 2, maxCount = 4,
    products = {
        { item = 'egg_weed_pack', level = 1, basePrice = 360 },
        { item = 'egg_lab_pack', level = 5, basePrice = 620 },
        { item = 'egg_cocaine_bag', level = 3, basePrice = 540 }
    }
}
Config.Drops = {
    { id = 'vespucci', label = 'Vespucci side street', x = -1154.74, y = -1518.54, z = 10.63 },
    { id = 'mirror', label = 'Mirror Park back lane', x = 1224.68, y = -454.67, z = 66.92 },
    { id = 'elburro', label = 'El Burro Heights driveway', x = 1274.21, y = -1711.28, z = 54.77 },
    { id = 'sandy', label = 'Sandy side street', x = 1803.81, y = 3921.38, z = 33.17 },
    { id = 'grapeseed', label = 'Grapeseed service lane', x = 1706.29, y = 4770.07, z = 41.99 }
}
