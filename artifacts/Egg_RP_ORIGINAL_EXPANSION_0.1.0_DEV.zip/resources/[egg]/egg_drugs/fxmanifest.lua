fx_version 'cerulean'
game 'gta5'
lua54 'yes'
name 'egg_drugs'
description 'Persistent game contraband, leased workspaces and local delivery runs'
version '0.1.0'
shared_script 'config.lua'
client_script 'client.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', '@egg_core/server_api.lua', 'server.lua' }
dependencies { 'egg_core', 'es_extended', 'oxmysql', 'esx_menu_default' }
