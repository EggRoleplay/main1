-- Conservative server guard. This is abuse throttling, not a commercial anticheat replacement.
local windows = {}
local MAX_EXPLOSIONS = 12
local WINDOW_MS = 10000

AddEventHandler('explosionEvent', function(sender, event)
    local now = GetGameTimer()
    local window = windows[sender]
    if not window or now - window.started > WINDOW_MS then window = { started = now, count = 0, logged = false }; windows[sender] = window end
    window.count = window.count + 1
    if window.count > MAX_EXPLOSIONS then
        CancelEvent()
        if not window.logged then
            window.logged = true
            exports.egg_core:Log(sender, 'guard', 'Explosion burst cancelled; investigate before any disciplinary action.')
        end
    end
end)

AddEventHandler('playerDropped', function() windows[source] = nil end)

RegisterCommand('egghealth', function(source)
    if source ~= 0 and not IsPlayerAceAllowed(source, 'egg.health') then return end
    for _, resource in ipairs({ 'oxmysql', 'es_extended', 'esx_menu_default', 'esx_menu_dialog', 'egg_core', 'egg_city', 'egg_work', 'egg_drugs', 'egg_dispatch', 'egg_crime', 'egg_police', 'egg_garages', 'egg_quality', 'egg_staff', 'egg_menu', 'egg_spawn', 'egg_hud' }) do
        print(('[Egg Health] %s: %s'):format(resource, GetResourceState(resource)))
    end
end, true)
