'use strict';
const app = document.getElementById('app');
const content = document.getElementById('content');
const nav = document.getElementById('nav');
const feedback = document.getElementById('feedback');
const state = { view: 'overview', mode: null, dashboard: null, person: null, caseId: null };
const resource = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'egg_police';
let toastTimer;
function esc(value) { return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
function date(value) {
  if (!value) return '—';
  const parsed = new Date(typeof value === 'number' && value < 100000000000 ? value * 1000 : value);
  return Number.isNaN(parsed.getTime()) ? esc(value) : parsed.toLocaleString('en-AU', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function normalize(result) {
  for (const field of ['certifications', 'people', 'weapons', 'suspensions', 'infringements', 'cases', 'notes', 'evidence', 'items', 'inventory', 'notices']) {
    if (result?.[field] && !Array.isArray(result[field])) result[field] = Object.values(result[field]);
  }
  return result;
}
function money(value) { return '$' + Number(value || 0).toLocaleString('en-AU'); }
function setFeedback(message, error = false) { feedback.textContent = message; feedback.style.color = error ? '#e4b5a0' : ''; }
async function send(endpoint, data = {}) {
  const response = await fetch(`https://${resource}/${endpoint}`, { method: 'POST', headers: { 'Content-Type': 'application/json; charset=UTF-8' }, body: JSON.stringify(data) });
  return response.json();
}
async function action(name, payload = {}) {
  try {
    const result = normalize(await send('action', { action: name, payload }));
    if (!result.ok) setFeedback(result.error || 'Request failed.', true);
    else if (result.message) setFeedback(result.message);
    else setFeedback('Records updated');
    return result;
  } catch (_) { setFeedback('Records connection unavailable. Try again.', true); return { ok: false }; }
}
function table(headers, rows, empty = 'No records.') {
  if (!rows.length) return `<p class="empty">${esc(empty)}</p>`;
  return `<div class="table-wrap"><table><thead><tr>${headers.map(header => `<th scope="col">${esc(header)}</th>`).join('')}</tr></thead><tbody>${rows.map(row => `<tr>${row.map(cell => `<td>${cell}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function field(label, name, kind = 'text', extra = '') {
  return `<label>${esc(label)}${kind === 'textarea' ? `<textarea name="${name}" ${extra}></textarea>` : `<input name="${name}" type="${kind}" ${extra}>`}</label>`;
}
function select(label, name, entries, placeholder = null) {
  return `<label>${esc(label)}<select name="${name}" required>${placeholder !== null ? `<option value="">${esc(placeholder)}</option>` : ''}${entries.map(([value, text]) => `<option value="${esc(value)}">${esc(text)}</option>`).join('')}</select></label>`;
}
function onlineOptions() { return (state.dashboard?.people || []).map(person => [person.source, `#${person.source} · ${person.name}`]); }
function subjectOptions() { return (state.dashboard?.people || []).map(person => [person.identifier, `${person.name} (#${person.source})`]); }
function cert(key) { return (state.dashboard?.certifications || []).some(entry => entry.certification === key); }
function bindForm(id, callback) {
  const form = document.getElementById(id);
  if (!form) return;
  form.addEventListener('submit', async event => {
    event.preventDefault();
    const button = form.querySelector('button[type="submit"]');
    if (button?.disabled) return;
    if (button) button.disabled = true;
    try { await callback(Object.fromEntries(new FormData(form))); } finally { if (button?.isConnected) button.disabled = false; }
  });
}
function bindRecords() {
  content.querySelectorAll('[data-person]').forEach(button => button.addEventListener('click', () => showPerson(button.dataset.person)));
  content.querySelectorAll('[data-case]').forEach(button => button.addEventListener('click', () => showCase(Number(button.dataset.case))));
}
function heading(title, summary) { return `<h1>${esc(title)}</h1><p class="intro">${esc(summary)}</p>`; }
function navigation() {
  const entries = [['overview', 'Watchhouse'], ['people', 'People'], ['anpr', 'Vehicle intelligence'], ['cases', 'Casebook']];
  if (state.dashboard?.police) entries.push(['locker', 'Station locker'], ['training', 'Certifications']);
  nav.innerHTML = entries.map(([key, text]) => `<button data-view="${key}" class="${state.view === key ? 'active' : ''}">${esc(text)}</button>`).join('');
  nav.querySelectorAll('button').forEach(button => button.addEventListener('click', () => navigate(button.dataset.view)));
}
async function navigate(view, extra = {}) {
  state.view = view;
  navigation();
  content.innerHTML = '<p class="empty">Opening records…</p>';
  const renderers = { overview: overview, people: people, anpr: anpr, cases: cases, locker: locker, training: training };
  if (renderers[view]) await renderers[view](extra);
}
function overview() {
  const dashboard = state.dashboard;
  const certs = Object.entries(dashboard.certificationTypes).map(([key, label]) => `<div class="row" style="justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--line)"><span>${esc(label)}</span><span class="tag ${cert(key) ? 'good' : ''}">${cert(key) ? 'Certified' : 'Pending'}</span></div>`).join('');
  content.innerHTML = heading('Watchhouse', `${dashboard.name} / ${dashboard.job}`) + `<div class="columns"><div><h2>Shift notes</h2><p>Keep the reason for each stop in the casebook. A registration match is a lead; confirm the driver’s identity before taking action.</p><p class="muted">Fingerprint collection asks the person’s consent. Evidence entries store your notes, location and a media reference. Bodycam status does not record footage.</p><div class="actions"><button data-view="cases">Open casebook</button><button data-view="people" class="quiet">Find a person</button></div></div><div><h2>Certifications</h2>${certs}</div></div><div class="card"><h2>Traffic notices</h2><p>Fixed cameras issue a notice to the driver. Drivers can review and pay notices with <strong>/infringements</strong>. Suspension decisions are recorded separately.</p><small>Licences are checked by Egg garages. ESX licensing tables are left to the server’s existing licence resource.</small></div>`;
  content.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => navigate(button.dataset.view)));
}
function people() {
  content.innerHTML = heading('People', 'Search identity records or select someone currently in the city.') + `<form id="person-search" class="row"><input name="query" aria-label="Name search" placeholder="First or last name" minlength="3" maxlength="80" required><button type="submit">Search</button></form><div id="people-results"></div><div class="card"><h2>Currently in the city</h2>${table(['ID', 'Name', ''], (state.dashboard.people || []).map(person => [esc(person.source), esc(person.name), `<button data-person="${esc(person.identifier)}">Open record</button>`]), 'Nobody is available.')}</div>`;
  bindForm('person-search', async data => {
    const result = await action('people', data);
    if (result.ok) { document.getElementById('people-results').innerHTML = table(['Name', ''], result.people.map(person => [esc(person.name), `<button data-person="${esc(person.identifier)}">Open record</button>`]), 'No matching identities.'); bindRecords(); }
  });
  bindRecords();
}
async function showPerson(identifier) {
  const result = await action('person', { identifier });
  if (!result.ok) return;
  state.person = identifier;
  state.view = 'people'; navigation();
  const active = (result.suspensions || []).filter(row => !row.reinstated_at && new Date(row.expires_at) > new Date());
  const canSuspend = state.dashboard.courtAuthority || cert('traffic');
  const online = state.dashboard.people.find(person => person.identifier === identifier);
  content.innerHTML = `<button id="back-people" class="quiet">Back to people</button><div style="margin-top:18px">${heading(result.name, 'Identity record')}</div><div class="columns"><div><h2>Fingerprint</h2><p>${esc(result.fingerprint?.fingerprint || 'No consented collection on file')}</p><h2>Weapon registry</h2>${table(['Weapon', 'Registry serial'], result.weapons.map(row => [esc(row.weapon_name), esc(row.serial)]))}<small>Registry entries are per owner and weapon type. They do not alter inventory metadata.</small></div><div><h2>Active suspensions</h2>${table(['Licence', 'Until', 'Reason', ''], active.map(row => [esc(row.licence_type), date(row.expires_at), esc(row.reason), state.dashboard.supervisor || state.dashboard.courtAuthority ? `<button data-reinstate="${row.id}">Reinstate</button>` : '']))}</div></div><h2 class="form-heading">Cases</h2>${table(['Reference', 'Title', 'Status', ''], result.cases.map(row => [`E${esc(row.id)}`, esc(row.title), esc(row.status), `<button data-case="${row.id}">Open</button>`]))}<h2 class="form-heading">Traffic notices</h2>${table(['Ref', 'Location', 'Speed', 'Fine', 'Status'], result.infringements.map(row => [`E${esc(row.id)}`, esc(row.location), `${esc(row.speed)} / ${esc(row.speed_limit)} km/h`, money(row.fine), row.paid_at ? 'Paid' : 'Unpaid']))}${canSuspend ? `<div class="card"><h2>Suspend a licence</h2><form id="suspend-form"><div class="columns">${select('Licence', 'type', [['driver', 'Driver'], ['weapon', 'Weapon']])}${field('Duration in days', 'days', 'number', 'min="1" max="90" value="7" required')}</div>${field('Reason', 'reason', 'textarea', 'maxlength="500" required')}<button type="submit" class="danger">Record suspension</button></form></div>` : ''}${online && state.dashboard.police ? `<div class="card"><h2>Collection / person must be nearby</h2><p class="muted">Online ID #${esc(online.source)}. The server checks the person’s distance and your certification.</p><div class="actions">${cert('forensics') ? '<button id="collect-print">Request fingerprints</button>' : ''}</div>${cert('firearms') ? `<form id="weapon-form" style="margin-top:18px">${field('ESX weapon name', 'weapon', 'text', 'placeholder="WEAPON_PISTOL" maxlength="64" required')}<button type="submit">Register held weapon type</button></form>` : ''}</div>` : ''}<div id="reinstate-panel"></div>`;
  document.getElementById('back-people').onclick = () => navigate('people');
  bindRecords();
  bindForm('suspend-form', async data => { const response = await action('suspend', { ...data, identifier }); if (response.ok) await showPerson(identifier); });
  bindForm('weapon-form', async data => { const response = await action('weaponRegister', { ...data, target: online.source }); if (response.ok) await showPerson(identifier); });
  document.getElementById('collect-print')?.addEventListener('click', () => action('fingerprintRequest', { target: online.source }));
  content.querySelectorAll('[data-reinstate]').forEach(button => button.addEventListener('click', () => {
    document.getElementById('reinstate-panel').innerHTML = `<div class="card"><h2>Reinstate licence / entry ${esc(button.dataset.reinstate)}</h2><form id="reinstate-form">${field('Decision reason', 'reason', 'textarea', 'maxlength="300" required')}<button type="submit">Confirm reinstatement</button></form></div>`;
    bindForm('reinstate-form', async data => { const response = await action('reinstate', { ...data, id: Number(button.dataset.reinstate) }); if (response.ok) await showPerson(identifier); });
  }));
}
function anpr(extra) {
  content.innerHTML = heading('Vehicle intelligence', 'Check a registration against the city’s owned vehicle records.') + `<form id="plate-form" class="row"><input name="plate" aria-label="Vehicle registration" placeholder="Registration plate" maxlength="16" value="${esc(extra.plate || '')}" required><button type="submit">Check registration</button></form><div id="plate-result"></div><p class="muted">Use /anpr to read your vehicle or the closest vehicle. Registry checks require vehicle intelligence certification.</p>`;
  const lookup = async data => {
    const result = await action('anpr', data);
    if (!result.ok) return;
    document.getElementById('plate-result').innerHTML = result.found ? `<div class="card"><h2>${esc(result.plate)}</h2><dl class="key-value"><dt>Registered to</dt><dd>${esc(result.owner)}</dd><dt>Driver licence</dt><dd>${result.suspended ? '<span class="tag warning">Suspended</span>' : 'No active Egg suspension'}</dd></dl><button data-person="${esc(result.identifier)}">Open owner record</button></div>` : `<div class="card"><h2>${esc(result.plate)}</h2><p>No owned vehicle registration found.</p></div>`;
    bindRecords();
  };
  bindForm('plate-form', lookup);
  if (extra.plate) lookup({ plate: extra.plate });
}
async function cases() {
  const result = await action('cases');
  content.innerHTML = heading('Casebook', 'Investigation records, evidence entries and court notes.') + `<div id="case-list">${result.ok ? table(['Ref', 'Title', 'Status', 'Officer', ''], result.cases.map(row => [`E${esc(row.id)}`, esc(row.title), `<span class="tag">${esc(row.status)}</span>`, esc(row.officer_name), `<button data-case="${row.id}">Open</button>`])) : '<p class="empty">Case records unavailable.</p>'}</div><div class="card"><h2>Open a case</h2><form id="case-create">${field('Case title', 'title', 'text', 'maxlength="120" required')}${select('Subject / optional', 'identifier', subjectOptions(), 'No subject selected')}${field('Initial summary', 'summary', 'textarea', 'maxlength="3000" required')}<button type="submit">Open case</button></form></div>`;
  document.querySelector('#case-create select').required = false;
  bindRecords();
  bindForm('case-create', async data => { const response = await action('caseCreate', data); if (response.ok) await showCase(response.id); });
}
async function showCase(id) {
  const result = await action('case', { id });
  if (!result.ok) return;
  state.caseId = id; state.view = 'cases'; navigation();
  const record = result.case;
  content.innerHTML = `<button id="back-cases" class="quiet">Back to casebook</button><div style="margin-top:18px">${heading(`E${record.id} / ${record.title}`, `${record.officer_name} · ${date(record.created_at)}`)}</div><span class="tag">${esc(record.status)}</span><p style="white-space:pre-wrap">${esc(record.summary)}</p>${record.subject_identifier ? `<button data-person="${esc(record.subject_identifier)}" class="quiet">Open subject record</button>` : ''}<h2 class="form-heading">Notes</h2>${result.notes.length ? result.notes.map(row => `<article class="note"><small>${esc(row.author_name)} · ${esc(row.note_type)} · ${date(row.created_at)}</small><p>${esc(row.note)}</p></article>`).join('') : '<p class="empty">No notes added.</p>'}<form id="case-note">${select('Note type', 'type', state.dashboard.court ? [['investigation', 'Investigation'], ['court', 'Court']] : [['investigation', 'Investigation']])}${field('Add a note', 'note', 'textarea', 'maxlength="3000" required')}<button type="submit">Save note</button></form><h2 class="form-heading">Evidence register</h2>${result.evidence.length ? result.evidence.map(row => `<article class="note"><h2>${esc(row.title)}</h2><small>${esc(row.author_name)} · ${date(row.created_at)} · ${Number(row.x).toFixed(1)}, ${Number(row.y).toFixed(1)}</small><p>${esc(row.description)}</p>${row.media_reference ? `<small>Media reference: ${esc(row.media_reference)}</small>` : ''}</article>`).join('') : '<p class="empty">No evidence entries.</p>'}${state.dashboard.police ? `<div class="card"><h2>Record evidence</h2><form id="evidence-form">${field('Evidence title', 'title', 'text', 'maxlength="120" required')}${field('Description / chain of custody', 'description', 'textarea', 'maxlength="3000" required')}${field('Media reference / optional', 'mediaReference', 'url', 'placeholder="https://…" maxlength="240"')}<p class="muted">A reference only. Your current location and the server timestamp are saved with this entry.</p><button type="submit">Save evidence entry</button></form></div>` : ''}${state.dashboard.supervisor || state.dashboard.courtAuthority ? `<form id="case-status" class="card"><h2>Case status</h2>${select('Move case to', 'status', [['open', 'Open'], ['court', 'Before court'], ['closed', 'Closed']])}<button type="submit">Update status</button></form>` : ''}`;
  document.getElementById('back-cases').onclick = () => navigate('cases');
  bindRecords();
  bindForm('case-note', async data => { const response = await action('caseNote', { ...data, id }); if (response.ok) await showCase(id); });
  bindForm('evidence-form', async data => { const response = await action('evidence', { ...data, id }); if (response.ok) await showCase(id); });
  bindForm('case-status', async data => { const response = await action('caseStatus', { ...data, id }); if (response.ok) await showCase(id); });
}
async function locker() {
  const result = await action('locker');
  content.innerHTML = heading('Station locker', 'Personal storage. Use the locker while standing inside a configured station.') + (result.ok ? `<div class="columns"><div><h2>In your locker</h2>${table(['Item', 'Quantity'], result.items.map(row => [esc(row.item), esc(row.quantity)]))}</div><div><h2>In your inventory</h2>${table(['Item', 'Quantity'], result.inventory.map(row => [esc(row.label), esc(row.quantity)]))}</div></div><div class="card"><h2>Transfer items</h2><p class="muted">Capacity: ${esc(result.capacity)} items. This locker accepts ESX inventory items; firearms stay in the framework loadout.</p><form id="locker-form"><div class="columns">${select('Item', 'item', Object.keys(state.dashboard.lockerItems).sort().map(item => [item, item]))}${field('Quantity', 'count', 'number', `min="1" max="${result.capacity}" value="1" required`)}</div>${select('Direction', 'direction', [['deposit', 'Inventory → locker'], ['withdraw', 'Locker → inventory']])}<button type="submit">Transfer</button></form></div>` : '<div class="card"><h2>Station access required</h2><p>City watchhouse, Sandy station or Paleto station. Stand near the locker and reopen this section.</p><button id="retry-locker">Try again</button></div>');
  document.getElementById('retry-locker')?.addEventListener('click', locker);
  bindForm('locker-form', async data => { const response = await action('lockerTransfer', data); if (response.ok) await locker(); });
}
function training() {
  content.innerHTML = heading('Certifications', 'Recorded training controls access to specialist functions.') + table(['Certification', 'Granted'], state.dashboard.certifications.map(row => [esc(state.dashboard.certificationTypes[row.certification] || row.certification), date(row.granted_at)]), 'No certifications recorded.') + (state.dashboard.supervisor ? `<div class="card"><h2>Supervisor decision</h2><form id="certification-form">${select('Online officer', 'target', onlineOptions(), 'Select an officer')}${select('Certification', 'certification', Object.entries(state.dashboard.certificationTypes))}${select('Decision', 'decision', [['grant', 'Grant'], ['revoke', 'Revoke']])}<button type="submit">Save decision</button></form></div>` : '<p class="muted">A police supervisor records training decisions after assessment.</p>');
  bindForm('certification-form', async data => {
    const result = await action('certify', { target: data.target, certification: data.certification, revoke: data.decision === 'revoke' });
    if (result.ok) { const fresh = await action('dashboard'); if (fresh.ok) state.dashboard = fresh; training(); }
  });
}
async function notices(payload) {
  const result = payload || await action('notices');
  if (!result.ok) return;
  content.innerHTML = heading('Traffic infringements', 'Notices issued to you by the city’s fixed speed cameras.') + (result.notices.length ? result.notices.map(row => `<article class="card"><div class="notice-head"><div><h2>Infringement E${esc(row.id)}</h2><span class="muted">${esc(row.location)} · ${date(row.issued_at)}</span></div><strong class="notice-amount">${money(row.fine)}</strong></div><div class="fine-details"><div>${esc(row.plate)}<span>Registration</span></div><div>${esc(row.speed)} km/h<span>Measured speed</span></div><div>${esc(row.speed_limit)} km/h<span>Speed limit</span></div><div>${esc(row.points)}<span>Recorded points</span></div></div>${row.paid_at ? `<span class="tag good">Paid · ${date(row.paid_at)}</span>` : `<button data-pay="${row.id}">Pay ${money(row.fine)} from bank</button>`}</article>`).join('') : '<div class="card"><h2>No infringement notices</h2><p>Your record is clear.</p></div>');
  content.querySelectorAll('[data-pay]').forEach(button => button.addEventListener('click', async () => {
    button.disabled = true;
    const response = await action('payNotice', { id: Number(button.dataset.pay) });
    if (response.ok) await notices(); else button.disabled = false;
  }));
}
function consent(payload) {
  content.innerHTML = heading('Fingerprint collection', `${payload.officer} has requested permission to collect your fingerprints.`) + '<p>This records a stable fingerprint against your character in the police database. The officer must remain within three metres.</p><div class="actions"><button id="accept-print">Allow collection</button><button id="decline-print" class="quiet">Decline</button></div><p class="muted">The request expires after 30 seconds. Closing this window declines it.</p>';
  document.getElementById('accept-print').onclick = () => action('fingerprintConsent', { accept: true });
  document.getElementById('decline-print').onclick = () => action('fingerprintConsent', { accept: false });
}
function close() { send('close').catch(() => {}); }
document.getElementById('close').addEventListener('click', close);
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !app.hidden) close(); });
window.addEventListener('message', async event => {
  const message = event.data;
  if (!message || typeof message !== 'object') return;
  if (message.type === 'close') { app.hidden = true; state.mode = null; }
  if (message.type === 'open') {
    app.hidden = false; state.mode = message.view;
    app.classList.toggle('compact-app', message.view !== 'mdt');
    nav.hidden = message.view !== 'mdt';
    setFeedback('Connected');
    document.getElementById('app-title').textContent = message.view === 'mdt' ? 'Egg Police Records' : message.view === 'notices' ? 'City Traffic Office' : 'Consent request';
    document.getElementById('identity').textContent = message.view === 'mdt' ? `${message.payload.name} / ${message.payload.job}` : 'Egg Roleplay';
    if (message.view === 'mdt') { state.dashboard = normalize(message.payload); await navigate('overview'); }
    if (message.view === 'notices') await notices(normalize(message.payload));
    if (message.view === 'consent') consent(message.payload);
  }
  if (message.type === 'navigate' && state.mode === 'mdt') await navigate(message.view, message);
  if (message.type === 'noticeToast') {
    const notice = message.payload;
    document.getElementById('toast').textContent = `Speed camera / ${notice.location}. ${notice.speed} km/h in a ${notice.speed_limit} zone. Infringement E${notice.id}: ${money(notice.fine)}. Use /infringements to review.`;
    document.getElementById('toast').hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { document.getElementById('toast').hidden = true; }, 10000);
  }
  if (message.type === 'bodycam') {
    document.getElementById('bodycam').hidden = !message.enabled;
    document.getElementById('bodycam-name').textContent = message.officer || '';
  }
});
setInterval(() => { document.getElementById('bodycam-time').textContent = new Date().toLocaleTimeString('en-AU', { hour12: false }); }, 1000);
