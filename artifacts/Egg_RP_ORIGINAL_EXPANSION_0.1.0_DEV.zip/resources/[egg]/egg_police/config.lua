Config = {}
Config.PoliceJobs = { police = true, sheriff = true }
Config.CourtJobs = { judge = true, doj = true, lawyer = true }
Config.CourtAuthorityJobs = { judge = true, doj = true }
Config.SupervisorGrade = 3
Config.Certifications = {
    anpr = 'Vehicle intelligence', firearms = 'Firearms registry',
    forensics = 'Fingerprint collection', traffic = 'Traffic enforcement'
}
Config.LockerLocations = {
    { label = 'City watchhouse', x = 452.25, y = -980.04, z = 30.69 },
    { label = 'Sandy station', x = 1853.03, y = 3688.55, z = 34.27 },
    { label = 'Paleto station', x = -449.58, y = 6011.51, z = 31.72 }
}
Config.LockerRoutingBucket = 0
Config.CameraRoutingBucket = 0
Config.LockerCapacity = 100
-- ESX inventory items only. Firearms stay in their framework-managed loadout.
Config.LockerItems = { bread = true, water = true, bandage = true, medikit = true,
    repairkit = true, lockpick = true, radio = true, phone = true, gps = true,
    egg_lockpick = true, egg_gps = true, egg_toolkit = true }
Config.MaxBarriers = 4
Config.BarrierModel = 'prop_barrier_work05'
Config.Cameras = {
    { id = 'alta_01', label = 'Alta Street', x = -235.25, y = -887.53, z = 30.10, limit = 60, radius = 24 },
    { id = 'vespucci_01', label = 'Vespucci Boulevard', x = -657.56, y = -854.69, z = 24.53, limit = 60, radius = 24 },
    { id = 'senora_01', label = 'Senora Freeway', x = 1680.51, y = 4820.57, z = 42.02, limit = 100, radius = 24 }
}
Config.CameraCooldown = 90 -- per driver, vehicle and camera
Config.SpeedPenalties = {
    { over = 6, fine = 210, points = 1 }, { over = 15, fine = 330, points = 3 },
    { over = 25, fine = 540, points = 4 }, { over = 40, fine = 790, points = 6 }
}
Config.MaximumMeasuredSpeed = 340
Config.MaxSuspensionDays = 90
Config.AllowPhotographicReferences = true -- stores a reference only; does not upload or record video
