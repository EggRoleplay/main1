local ESX = exports.es_extended:getSharedObject()
local Core = EggCore
local accessJobs, pendingPrints, barriers, cameraVisits, speedSamples = {}, {}, {}, {}, {}
local schema = { users = false, names = false, vehicles = false }
for job in pairs(Config.PoliceJobs) do accessJobs[job] = true end
for job in pairs(Config.CourtJobs) do accessJobs[job] = true end

local function deny(message) return { ok = false, error = message } end
local function clean(value, limit)
    if type(value) ~= 'string' then return nil end
    value = value:gsub('[%c]', ' '):match('^%s*(.-)%s*$')
    if value == '' or #value > limit then return nil end
    return value
end
local function integer(value, low, high)
    local number = tonumber(value)
    if not number or number ~= number or number % 1 ~= 0 or number < low or number > high then return nil end
    return number
end
local function identifier(player) return player and player.getIdentifier() end
local function sameSession(source, player)
    local current = ESX.GetPlayerFromId(source)
    return Core:SessionAlive() and current ~= nil and identifier(current) == identifier(player)
end
local function name(player) return clean(player and player.getName() or '', 100) or 'Unknown person' end
local function police(player) return player and player.job and Config.PoliceJobs[player.job.name] == true end
local function court(player) return player and player.job and Config.CourtJobs[player.job.name] == true end
local function courtAuthority(player) return player and player.job and Config.CourtAuthorityJobs[player.job.name] == true end
local function supervisor(source, player)
    return Core:IsStaff(source) or (police(player) and tonumber(player.job.grade) >= Config.SupervisorGrade)
end
local function certified(player, cert)
    if not police(player) then return false end
    return MySQL.scalar.await('SELECT 1 FROM egg_police_certifications WHERE identifier = ? AND certification = ?', { identifier(player), cert }) ~= nil
end
local function nearPlayers(first, second, radius)
    if GetPlayerRoutingBucket(first) ~= GetPlayerRoutingBucket(second) then return false end
    local a, b = GetPlayerPed(first), GetPlayerPed(second)
    if a == 0 or b == 0 then return false end
    return #(GetEntityCoords(a) - GetEntityCoords(b)) <= radius
end
local function atLocker(source)
    if GetPlayerRoutingBucket(source) ~= Config.LockerRoutingBucket then return false end
    for _, point in ipairs(Config.LockerLocations) do
        if Core:RequireNear(source, point, 4.0) then return true end
    end
    return false
end
local function licenceType(value)
    if value == 'driver' or value == 'drive' or value == 'driving' then return 'driver' end
    if value == 'weapon' then return 'weapon' end
    return nil
end
local function resolveIdentifier(value)
    if type(value) == 'number' then return identifier(ESX.GetPlayerFromId(value)) end
    return clean(value, 80)
end
local function isSuspended(value, licence)
    local owner, kind = resolveIdentifier(value), licenceType(licence)
    if not owner or not kind then return false end
    return MySQL.scalar.await([[
        SELECT 1 FROM egg_license_suspensions WHERE identifier = ? AND licence_type = ?
        AND reinstated_at IS NULL AND expires_at > CURRENT_TIMESTAMP LIMIT 1
    ]], { owner, kind }) ~= nil
end
exports('IsLicenseSuspended', isSuspended)
exports('HasSuspendedLicense', isSuspended)
exports('GetActiveInfringements', function(value)
    local owner = resolveIdentifier(value)
    if not owner then return {} end
    return MySQL.query.await('SELECT id, location, speed, speed_limit, fine, points, issued_at FROM egg_police_infringements WHERE identifier = ? AND paid_at IS NULL ORDER BY id DESC LIMIT 50', { owner })
end)


exports('Dispatch', function(source, message)
    if GetResourceState('egg_dispatch') == 'started' then
        return exports.egg_dispatch:Dispatch(source, message, 'police')
    end
    print('[egg_police] Emergency dispatch is not running; check egg.cfg.')
    return false
end)

MySQL.ready(function()
    local rows = MySQL.query.await([[
        SELECT TABLE_NAME AS tab, COLUMN_NAME AS col FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ('users', 'owned_vehicles')
    ]])
    local columns = { users = {}, owned_vehicles = {} }
    for _, row in ipairs(rows or {}) do columns[row.tab][row.col] = true end
    schema.users = columns.users.identifier == true
    schema.names = schema.users and columns.users.firstname and columns.users.lastname or false
    schema.vehicles = columns.owned_vehicles.owner and columns.owned_vehicles.plate or false
    print(('[egg_police] Records ready. ESX identities: %s; owned vehicles: %s.'):format(tostring(schema.names), tostring(schema.vehicles)))
end)

local function personName(owner)
    if schema.names then
        local row = MySQL.single.await("SELECT CONCAT(COALESCE(firstname, ''), ' ', COALESCE(lastname, '')) AS name FROM users WHERE identifier = ? LIMIT 1", { owner })
        if row then return clean(row.name, 100) or 'Identity not recorded' end
    end
    for _, player in pairs(ESX.GetExtendedPlayers()) do
        if identifier(player) == owner then return name(player) end
    end
    return 'Identity not recorded'
end
local function subjectExists(owner)
    if not owner then return true end
    if schema.users then return MySQL.scalar.await('SELECT 1 FROM users WHERE identifier = ? LIMIT 1', { owner }) ~= nil end
    for _, player in pairs(ESX.GetExtendedPlayers()) do if identifier(player) == owner then return true end end
    return false
end
local function action(suffix, options, callback)
    options = options or {}
    options.cooldown = options.cooldown or 500
    Core:RegisterAction('police:' .. suffix, options, callback)
end
local function recordAudit(source, event, data)
    Core:Log(source, event, json.encode(data))
end

-- General records require a police or court job. Sensitive collection actions enforce a police certificate below.
action('dashboard', { job = accessJobs }, function(source, player)
    local certs = MySQL.query.await('SELECT certification, granted_at FROM egg_police_certifications WHERE identifier = ?', { identifier(player) })
    local people = {}
    for _, other in pairs(ESX.GetExtendedPlayers()) do
        people[#people + 1] = { source = other.source, name = name(other), identifier = identifier(other) }
        if #people >= 64 then break end
    end
    table.sort(people, function(a, b) return a.source < b.source end)
    return { ok = true, name = name(player), job = player.job.label, police = police(player), court = court(player), courtAuthority = courtAuthority(player),
        supervisor = supervisor(source, player), certifications = certs, certificationTypes = Config.Certifications,
        people = people, lockerItems = Config.LockerItems, cameras = Config.Cameras,
        features = { names = schema.names, vehicles = schema.vehicles } }
end)

action('people', { job = accessJobs }, function(_, _, data)
    local query = clean(data.query, 80)
    if not query or #query < 3 or query:find('[%%_]') then return deny('Enter at least three letters; wildcard searches are unavailable.') end
    if not schema.names then return deny('ESX identity columns are unavailable. Use the on-duty list to select someone online.') end
    local rows = MySQL.query.await([[
        SELECT identifier, CONCAT(COALESCE(firstname, ''), ' ', COALESCE(lastname, '')) AS name
        FROM users WHERE CONCAT(COALESCE(firstname, ''), ' ', COALESCE(lastname, '')) LIKE ?
        ORDER BY firstname, lastname LIMIT 20
    ]], { '%' .. query .. '%' })
    return { ok = true, people = rows }
end)

action('person', { job = accessJobs }, function(_, _, data)
    local owner = clean(data.identifier, 80)
    if not owner or not subjectExists(owner) then return deny('Person not found.') end
    return { ok = true, name = personName(owner), identifier = owner,
        fingerprint = MySQL.single.await('SELECT fingerprint, collected_at FROM egg_police_fingerprints WHERE identifier = ?', { owner }),
        weapons = MySQL.query.await('SELECT weapon_name, serial, registered_at FROM egg_police_weapon_registry WHERE owner_identifier = ? ORDER BY id DESC LIMIT 20', { owner }),
        suspensions = MySQL.query.await('SELECT id, licence_type, reason, imposed_at, expires_at, reinstated_at FROM egg_license_suspensions WHERE identifier = ? ORDER BY id DESC LIMIT 20', { owner }),
        infringements = MySQL.query.await('SELECT id, plate, location, speed, speed_limit, fine, points, issued_at, paid_at FROM egg_police_infringements WHERE identifier = ? ORDER BY id DESC LIMIT 30', { owner }),
        cases = MySQL.query.await('SELECT id, title, status, officer_name, created_at FROM egg_police_cases WHERE subject_identifier = ? ORDER BY id DESC LIMIT 20', { owner }) }
end)

action('anpr', { job = Config.PoliceJobs }, function(source, player, data)
    if not certified(player, 'anpr') then return deny('Vehicle intelligence certification required.') end
    if not schema.vehicles then return deny('The ESX owned_vehicles owner/plate columns are unavailable.') end
    local plate = clean(data.plate, 16)
    if not plate then return deny('Enter a registration plate.') end
    plate = plate:upper():gsub('%s+', '')
    local row = MySQL.single.await('SELECT owner, plate FROM owned_vehicles WHERE REPLACE(UPPER(plate), " ", "") = ? LIMIT 1', { plate })
    if not row then return { ok = true, plate = plate, found = false } end
    recordAudit(source, 'police.anpr', { plate = row.plate })
    return { ok = true, found = true, plate = row.plate, owner = personName(row.owner),
        identifier = row.owner, suspended = isSuspended(row.owner, 'driver') }
end)

action('certify', { job = Config.PoliceJobs, cooldown = 1200 }, function(source, player, data)
    if not supervisor(source, player) then return deny('A police supervisor must change certifications.') end
    local target = ESX.GetPlayerFromId(integer(data.target, 1, 65535) or 0)
    local cert = clean(data.certification, 32)
    if not target or not police(target) or not cert or not Config.Certifications[cert] then return deny('Select an online officer and a valid certification.') end
    if data.revoke == true then
        MySQL.update.await('DELETE FROM egg_police_certifications WHERE identifier = ? AND certification = ?', { identifier(target), cert })
    else
        MySQL.update.await('INSERT INTO egg_police_certifications (identifier, certification, granted_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE granted_by = VALUES(granted_by), granted_at = CURRENT_TIMESTAMP', { identifier(target), cert, identifier(player) })
    end
    recordAudit(source, 'police.certification', { target = target.source, certification = cert, revoke = data.revoke == true })
    Core:Notify(target.source, ('Your %s certification was %s.'):format(Config.Certifications[cert], data.revoke and 'revoked' or 'granted'))
    return { ok = true, message = 'Certification updated.' }
end)

action('fingerprintRequest', { job = Config.PoliceJobs, cooldown = 3000 }, function(source, player, data)
    if not certified(player, 'forensics') then return deny('Fingerprint collection certification required.') end
    local targetSource = integer(data.target, 1, 65535)
    if not targetSource or targetSource == source or not ESX.GetPlayerFromId(targetSource) or not nearPlayers(source, targetSource, 3.0) then return deny('Ask a person within three metres.') end
    local existing = pendingPrints[targetSource]
    if existing and existing.expires > os.time() then return deny('That person already has a pending request.') end
    local targetIdentifier = identifier(ESX.GetPlayerFromId(targetSource))
    local token = MySQL.scalar.await('SELECT UUID()')
    if not sameSession(source, player) or identifier(ESX.GetPlayerFromId(targetSource)) ~= targetIdentifier or not nearPlayers(source, targetSource, 3.0) then return deny('That person or your connection changed. Ask again.') end
    pendingPrints[targetSource] = { officer = source, officerIdentifier = identifier(player), targetIdentifier = targetIdentifier, token = token, expires = os.time() + 30 }
    TriggerClientEvent('egg_police:fingerprintRequest', targetSource, { token = token, officer = name(player), expires = 30 })
    return { ok = true, message = 'Fingerprint request sent. The person has 30 seconds to consent.' }
end)

action('fingerprintConsent', { cooldown = 800 }, function(source, player, data)
    local request = pendingPrints[source]
    if not request or request.targetIdentifier ~= identifier(player) or request.token ~= data.token or request.expires <= os.time() then return deny('The fingerprint request has expired.') end
    pendingPrints[source] = nil
    if data.accept ~= true then
        Core:Notify(request.officer, 'Fingerprint collection declined.')
        return { ok = true, message = 'Request declined.' }
    end
    local officer = ESX.GetPlayerFromId(request.officer)
    if not officer or identifier(officer) ~= request.officerIdentifier or not certified(officer, 'forensics') or not nearPlayers(source, request.officer, 3.0) then return deny('The officer is no longer authorised or nearby.') end
    local mark = MySQL.scalar.await("SELECT CONCAT('EGG-', UPPER(SUBSTRING(SHA2(?, 256), 1, 20)))", { identifier(player) })
    if not sameSession(source, player) or identifier(ESX.GetPlayerFromId(request.officer)) ~= request.officerIdentifier or not nearPlayers(source, request.officer, 3.0) then return deny('Collection interrupted. Ask the officer to request it again.') end
    MySQL.update.await('INSERT INTO egg_police_fingerprints (identifier, fingerprint, collected_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE collected_by = VALUES(collected_by), collected_at = CURRENT_TIMESTAMP', { identifier(player), mark, request.officerIdentifier })
    recordAudit(request.officer, 'police.fingerprint', { target = source, consent = true })
    Core:Notify(request.officer, 'Fingerprint recorded: ' .. mark)
    return { ok = true, message = 'Your fingerprint was recorded with your consent.' }
end)

action('weaponRegister', { job = Config.PoliceJobs, cooldown = 1200 }, function(source, player, data)
    if not certified(player, 'firearms') then return deny('Firearms registry certification required.') end
    local targetSource = integer(data.target, 1, 65535)
    local target = targetSource and ESX.GetPlayerFromId(targetSource)
    local weapon = clean(data.weapon, 64)
    if not target or not weapon or not nearPlayers(source, targetSource, 3.0) then return deny('The weapon holder must be within three metres.') end
    weapon = weapon:upper()
    local owned = false
    for _, entry in pairs(target.getLoadout()) do if entry.name and entry.name:upper() == weapon then owned = true end end
    if not owned then return deny('That weapon is absent from the person’s ESX loadout.') end
    return Core:WithLock('police:weapon:' .. identifier(target) .. ':' .. weapon, function()
        local row = MySQL.single.await('SELECT serial FROM egg_police_weapon_registry WHERE owner_identifier = ? AND weapon_name = ?', { identifier(target), weapon })
        if row then return { ok = true, serial = row.serial, message = 'Existing registry entry: ' .. row.serial } end
        local serial = MySQL.scalar.await("SELECT CONCAT('EGG-', UPPER(REPLACE(UUID(), '-', '')))")
        serial = serial:sub(1, 28)
        MySQL.insert.await('INSERT INTO egg_police_weapon_registry (owner_identifier, weapon_name, serial, registered_by) VALUES (?, ?, ?, ?)', { identifier(target), weapon, serial, identifier(player) })
        recordAudit(source, 'police.weapon_registered', { target = targetSource, weapon = weapon, serial = serial })
        return { ok = true, serial = serial, message = 'Registry entry created: ' .. serial }
    end)
end)

action('cases', { job = accessJobs }, function(_, _, data)
    local status = data.status
    if status and status ~= 'open' and status ~= 'court' and status ~= 'closed' then return deny('Invalid case status.') end
    local rows
    if status then rows = MySQL.query.await('SELECT id, title, status, officer_name, created_at FROM egg_police_cases WHERE status = ? ORDER BY id DESC LIMIT 40', { status })
    else rows = MySQL.query.await('SELECT id, title, status, officer_name, created_at FROM egg_police_cases ORDER BY id DESC LIMIT 40') end
    return { ok = true, cases = rows }
end)

action('case', { job = accessJobs }, function(_, _, data)
    local id = integer(data.id, 1, 2147483647)
    if not id then return deny('Invalid case reference.') end
    local row = MySQL.single.await('SELECT * FROM egg_police_cases WHERE id = ?', { id })
    if not row then return deny('Case not found.') end
    return { ok = true, case = row,
        notes = MySQL.query.await('SELECT id, author_name, note_type, note, created_at FROM egg_police_case_notes WHERE case_id = ? ORDER BY id DESC LIMIT 100', { id }),
        evidence = MySQL.query.await('SELECT id, author_name, title, description, media_reference, x, y, z, created_at FROM egg_police_evidence WHERE case_id = ? ORDER BY id DESC LIMIT 60', { id }) }
end)

action('caseCreate', { job = accessJobs, cooldown = 1500 }, function(source, player, data)
    local title, summary, owner = clean(data.title, 120), clean(data.summary, 3000), clean(data.identifier, 80)
    if not title or not summary then return deny('Provide a case title and a summary (maximum 3,000 characters).') end
    if not subjectExists(owner) then return deny('Subject not found in the ESX records.') end
    local id = MySQL.insert.await("INSERT INTO egg_police_cases (title, summary, subject_identifier, officer_identifier, officer_name) VALUES (?, ?, NULLIF(?, ''), ?, ?)", { title, summary, owner or '', identifier(player), name(player) })
    recordAudit(source, 'police.case_created', { case = id })
    return { ok = true, id = id, message = 'Case E' .. id .. ' opened.' }
end)

action('caseNote', { job = accessJobs, cooldown = 1200 }, function(source, player, data)
    local id, note = integer(data.id, 1, 2147483647), clean(data.note, 3000)
    local kind = data.type == 'court' and 'court' or 'investigation'
    if kind == 'court' and not court(player) then return deny('Court notes require a DOJ job.') end
    if not id or not note or not MySQL.scalar.await('SELECT 1 FROM egg_police_cases WHERE id = ?', { id }) then return deny('Select a case and enter a note.') end
    MySQL.insert.await('INSERT INTO egg_police_case_notes (case_id, author_identifier, author_name, note_type, note) VALUES (?, ?, ?, ?, ?)', { id, identifier(player), name(player), kind, note })
    MySQL.update.await('UPDATE egg_police_cases SET updated_at = CURRENT_TIMESTAMP WHERE id = ?', { id })
    recordAudit(source, 'police.case_note', { case = id, type = kind })
    return { ok = true, message = 'Note added to case E' .. id .. '.' }
end)

action('caseStatus', { job = accessJobs }, function(source, player, data)
    local id, status = integer(data.id, 1, 2147483647), data.status
    if not id or (status ~= 'open' and status ~= 'court' and status ~= 'closed') then return deny('Select a case and a valid status.') end
    if not courtAuthority(player) and not supervisor(source, player) then return deny('A supervisor or DOJ officer must change a case status.') end
    if MySQL.update.await('UPDATE egg_police_cases SET status = ? WHERE id = ?', { status, id }) == 0 then return deny('Case not found or already in that status.') end
    recordAudit(source, 'police.case_status', { case = id, status = status })
    return { ok = true, message = 'Case status updated.' }
end)

action('evidence', { job = Config.PoliceJobs, cooldown = 1500 }, function(source, player, data)
    local id, title, description = integer(data.id, 1, 2147483647), clean(data.title, 120), clean(data.description, 3000)
    local reference = clean(data.mediaReference, 240)
    if reference and (not Config.AllowPhotographicReferences or not reference:match('^https://')) then return deny('Media references must use HTTPS.') end
    if not id or not title or not description or not MySQL.scalar.await('SELECT 1 FROM egg_police_cases WHERE id = ?', { id }) then return deny('Select a case and describe the evidence.') end
    local ped = GetPlayerPed(source)
    if ped == 0 then return deny('Your player entity is unavailable.') end
    local point = GetEntityCoords(ped)
    MySQL.insert.await("INSERT INTO egg_police_evidence (case_id, author_identifier, author_name, title, description, media_reference, x, y, z) VALUES (?, ?, ?, ?, ?, NULLIF(?, ''), ?, ?, ?)", { id, identifier(player), name(player), title, description, reference or '', point.x, point.y, point.z })
    recordAudit(source, 'police.evidence_recorded', { case = id, title = title })
    return { ok = true, message = 'Evidence entry saved with your location and timestamp.' }
end)

action('suspend', { job = accessJobs, cooldown = 1500 }, function(source, player, data)
    if not courtAuthority(player) and not certified(player, 'traffic') then return deny('Traffic enforcement certification or a DOJ job is required.') end
    local owner, kind, reason = clean(data.identifier, 80), licenceType(data.type), clean(data.reason, 500)
    local days = integer(data.days, 1, Config.MaxSuspensionDays)
    if not owner or not subjectExists(owner) or not kind or not reason or not days then return deny('Choose a person, licence type, reason and a duration of 1–90 days.') end
    return Core:WithLock('police:licence:' .. owner .. ':' .. kind, function()
        if isSuspended(owner, kind) then return deny('That licence already has an active suspension. Reinstate it before imposing a new one.') end
        local id = MySQL.insert.await('INSERT INTO egg_license_suspensions (identifier, licence_type, reason, imposed_by, expires_at) VALUES (?, ?, ?, ?, DATE_ADD(CURRENT_TIMESTAMP, INTERVAL ? DAY))', { owner, kind, reason, identifier(player), days })
        recordAudit(source, 'police.licence_suspended', { suspension = id, type = kind, days = days })
        return { ok = true, message = 'Licence suspended for ' .. days .. ' days.' }
    end)
end)

action('reinstate', { job = accessJobs }, function(source, player, data)
    if not courtAuthority(player) and not supervisor(source, player) then return deny('A police supervisor or DOJ officer must reinstate a licence.') end
    local id, reason = integer(data.id, 1, 2147483647), clean(data.reason, 300)
    if not id or not reason then return deny('Select a suspension and enter the reinstatement reason.') end
    local count = MySQL.update.await('UPDATE egg_license_suspensions SET reinstated_at = CURRENT_TIMESTAMP, reinstated_by = ? WHERE id = ? AND reinstated_at IS NULL', { identifier(player), id })
    if count == 0 then return deny('Suspension not found or already reinstated.') end
    recordAudit(source, 'police.licence_reinstated', { suspension = id, reason = reason })
    return { ok = true, message = 'Licence reinstated.' }
end)

action('locker', { job = Config.PoliceJobs }, function(source, player)
    if not atLocker(source) then return deny('Use your locker inside a police station.') end
    local items = MySQL.query.await('SELECT item, quantity FROM egg_police_lockers WHERE identifier = ? AND quantity > 0 ORDER BY item', { identifier(player) })
    local inventory = {}
    for item in pairs(Config.LockerItems) do
        local entry = player.getInventoryItem(item)
        if entry and entry.count and entry.count > 0 then inventory[#inventory + 1] = { item = item, label = entry.label or item, quantity = entry.count } end
    end
    return { ok = true, items = items, inventory = inventory, capacity = Config.LockerCapacity }
end)

action('lockerTransfer', { job = Config.PoliceJobs, cooldown = 1000 }, function(source, player, data)
    if not atLocker(source) then return deny('Use your locker inside a police station.') end
    local item, count = clean(data.item, 64), integer(data.count, 1, Config.LockerCapacity)
    if not item or not Config.LockerItems[item] or not count or (data.direction ~= 'deposit' and data.direction ~= 'withdraw') then return deny('Choose a supported item, quantity and transfer direction.') end
    return Core:WithLock('police:locker:' .. identifier(player), function()
        if not sameSession(source, player) or not atLocker(source) then return deny('Stay at the station locker.') end
        local stored = tonumber(MySQL.scalar.await('SELECT quantity FROM egg_police_lockers WHERE identifier = ? AND item = ?', { identifier(player), item })) or 0
        if data.direction == 'deposit' then
            local total = tonumber(MySQL.scalar.await('SELECT COALESCE(SUM(quantity), 0) FROM egg_police_lockers WHERE identifier = ?', { identifier(player) })) or 0
            if total + count > Config.LockerCapacity then return deny('Your locker is full.') end
            if not sameSession(source, player) or not atLocker(source) then return deny('Stay at the station locker.') end
            if not Core:RemoveItem(source, item, count) then return deny('You do not have enough of that item.') end
            local ok, result = pcall(function()
                return MySQL.update.await('INSERT INTO egg_police_lockers (identifier, item, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)', { identifier(player), item, count })
            end)
            if not ok or result == nil then
                if sameSession(source, player) then Core:AddItem(source, item, count) end
                return deny('Storage failed. Contact a supervisor if your inventory was not restored.')
            end
        else
            if stored < count then return deny('Your locker does not contain that quantity.') end
            if player.canCarryItem and not player.canCarryItem(item, count) then return deny('Your inventory has no room.') end
            local changed = MySQL.update.await('UPDATE egg_police_lockers SET quantity = quantity - ? WHERE identifier = ? AND item = ? AND quantity >= ?', { count, identifier(player), item, count })
            if changed ~= 1 then return deny('Locker contents changed. Try again.') end
            if not sameSession(source, player) or not atLocker(source) or not Core:AddItem(source, item, count) then
                MySQL.update.await('UPDATE egg_police_lockers SET quantity = quantity + ? WHERE identifier = ? AND item = ?', { count, identifier(player), item })
                return deny('Your inventory has no room; the withdrawal was returned.')
            end
        end
        recordAudit(source, 'police.locker_transfer', { item = item, count = count, direction = data.direction })
        return { ok = true, message = 'Locker updated.' }
    end)
end)

action('barrier', { job = Config.PoliceJobs, cooldown = 1200 }, function(source, _, data)
    local ped = GetPlayerPed(source)
    if ped == 0 then return deny('Your player entity is unavailable.') end
    local point = GetEntityCoords(ped)
    if data.remove == true then
        local closest, distance
        for id, barrier in pairs(barriers) do
            if DoesEntityExist(barrier.entity) and GetEntityRoutingBucket(barrier.entity) == GetPlayerRoutingBucket(source) then
                local separation = #(point - GetEntityCoords(barrier.entity))
                if separation <= 4 and (not distance or separation < distance) then closest, distance = id, separation end
            elseif not DoesEntityExist(barrier.entity) then barriers[id] = nil end
        end
        if not closest then return deny('No police barrier is within four metres.') end
        DeleteEntity(barriers[closest].entity)
        barriers[closest] = nil
        recordAudit(source, 'police.barrier_removed', {})
        return { ok = true, message = 'Barrier removed.' }
    end
    local count = 0
    for id, barrier in pairs(barriers) do
        if not DoesEntityExist(barrier.entity) then barriers[id] = nil
        elseif barrier.owner == source then count = count + 1 end
    end
    if count >= Config.MaxBarriers then return deny('Remove one of your existing barriers first.') end
    local heading = tonumber(data.heading)
    if not heading or heading ~= heading or heading < 0 or heading > 360 then return deny('Invalid barrier heading.') end
    local angle = math.rad(heading)
    local x, y = point.x - math.sin(angle) * 1.8, point.y + math.cos(angle) * 1.8
    local entity = CreateObject(GetHashKey(Config.BarrierModel), x, y, point.z - 1.0, true, true, false)
    if entity == 0 then return deny('The barrier could not be created.') end
    SetEntityRoutingBucket(entity, GetPlayerRoutingBucket(source))
    SetEntityHeading(entity, heading)
    FreezeEntityPosition(entity, true)
    if SetEntityOrphanMode then SetEntityOrphanMode(entity, 2) end
    local id = NetworkGetNetworkIdFromEntity(entity)
    barriers[id] = { entity = entity, owner = source }
    recordAudit(source, 'police.barrier_placed', { x = x, y = y })
    return { ok = true, message = 'Barrier placed. Use /barrier remove to collect it.' }
end)

action('notices', {}, function(_, player)
    return { ok = true, notices = MySQL.query.await('SELECT id, plate, location, speed, speed_limit, fine, points, issued_at, paid_at FROM egg_police_infringements WHERE identifier = ? ORDER BY id DESC LIMIT 50', { identifier(player) }) }
end)

action('payNotice', { cooldown = 1000 }, function(source, player, data)
    local id = integer(data.id, 1, 2147483647)
    if not id then return deny('Invalid infringement reference.') end
    return Core:WithLock('police:notice:' .. id, function()
        local row = MySQL.single.await('SELECT fine, paid_at FROM egg_police_infringements WHERE id = ? AND identifier = ?', { id, identifier(player) })
        if not row or row.paid_at then return deny('That notice is unavailable or already paid.') end
        if not sameSession(source, player) then return deny('Your player session changed. Reopen your notices.') end
        if not Core:TryDebit(source, row.fine, 'bank') then return deny('Your bank balance cannot cover this notice.') end
        local ok, count = pcall(function() return MySQL.update.await('UPDATE egg_police_infringements SET paid_at = CURRENT_TIMESTAMP WHERE id = ? AND paid_at IS NULL', { id }) end)
        if not ok or count ~= 1 then
            if sameSession(source, player) then Core:Credit(source, row.fine, 'bank') end
            return deny('Payment failed. Contact staff if your bank debit was not restored.')
        end
        recordAudit(source, 'police.infringement_paid', { notice = id, fine = row.fine })
        return { ok = true, message = ('Infringement E%s paid: $%s.'):format(id, row.fine) }
    end)
end)

-- OneSync entities are the only measurement source. No client speed or fine event is accepted.
CreateThread(function()
    while true do
        Wait(750)
        local now, active = GetGameTimer(), {}
        for _, player in pairs(ESX.GetExtendedPlayers()) do
            local source, ped = player.source, GetPlayerPed(player.source)
            if ped ~= 0 and GetPlayerRoutingBucket(source) == Config.CameraRoutingBucket then
                local vehicle = GetVehiclePedIsIn(ped, false)
                if vehicle ~= 0 and GetPedInVehicleSeat(vehicle, -1) == ped then
                    local point, speed = GetEntityCoords(vehicle), GetEntitySpeed(vehicle) * 3.6
                    local previous = speedSamples[source]
                    local plate = clean(GetVehicleNumberPlateText(vehicle), 16)
                    active[source] = true
                    speedSamples[source] = { point = point, time = now, vehicle = vehicle }
                    if previous and previous.vehicle == vehicle and plate and now > previous.time then
                        local displacement = #(point - previous.point) / ((now - previous.time) / 1000) * 3.6
                        if speed <= Config.MaximumMeasuredSpeed and math.abs(speed - displacement) <= 60 then
                            for _, camera in ipairs(Config.Cameras) do
                                local location = vector3(camera.x, camera.y, camera.z)
                                if #(point - location) <= camera.radius and #(previous.point - location) <= camera.radius + 35 then
                                    local measured, penalty = math.floor(math.min(speed, displacement) + 0.5), nil
                                    for _, bracket in ipairs(Config.SpeedPenalties) do
                                        if measured - camera.limit >= bracket.over then penalty = bracket end
                                    end
                                    local key = identifier(player) .. ':' .. plate .. ':' .. camera.id
                                    if penalty and (not cameraVisits[key] or os.time() - cameraVisits[key] >= Config.CameraCooldown) then
                                        cameraVisits[key] = os.time()
                                        local ok, id = pcall(function()
                                            return MySQL.insert.await('INSERT INTO egg_police_infringements (identifier, driver_name, plate, camera_id, location, speed, speed_limit, fine, points) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', { identifier(player), name(player), plate:upper(), camera.id, camera.label, measured, camera.limit, penalty.fine, penalty.points })
                                        end)
                                        if ok and id then
                                            if sameSession(source, player) then
                                                TriggerClientEvent('egg_police:notice', source, { id = id, plate = plate:upper(), location = camera.label, speed = measured, speed_limit = camera.limit, fine = penalty.fine, points = penalty.points })
                                            end
                                            recordAudit(sameSession(source, player) and source or 0, 'police.speed_camera', { notice = id, camera = camera.id, speed = measured, fine = penalty.fine })
                                        else
                                            print('[egg_police] Camera notice storage failed; camera remains active and will retry after its cooldown.')
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
        for source in pairs(speedSamples) do if not active[source] then speedSamples[source] = nil end end
        -- The cooldown cache must not grow with every past registration plate.
        for key, timestamp in pairs(cameraVisits) do if os.time() - timestamp > Config.CameraCooldown * 2 then cameraVisits[key] = nil end end
        for target, request in pairs(pendingPrints) do if request.expires <= os.time() then pendingPrints[target] = nil end end
    end
end)

AddEventHandler('playerDropped', function()
    local source = source
    pendingPrints[source], speedSamples[source] = nil, nil
    for target, request in pairs(pendingPrints) do if request.officer == source then pendingPrints[target] = nil end end
    for id, barrier in pairs(barriers) do if barrier.owner == source then DeleteEntity(barrier.entity) barriers[id] = nil end end
end)
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for _, barrier in pairs(barriers) do if DoesEntityExist(barrier.entity) then DeleteEntity(barrier.entity) end end
end)
