local Core = exports.egg_core
local open, mode, bodycam = false, nil, false
local consentToken
local allowed = {
    dashboard = true, people = true, person = true, anpr = true, certify = true,
    fingerprintRequest = true, fingerprintConsent = true, weaponRegister = true,
    cases = true, case = true, caseCreate = true, caseNote = true, caseStatus = true,
    evidence = true, suspend = true, reinstate = true, locker = true,
    lockerTransfer = true, barrier = true, notices = true, payNotice = true
}
local function show(view, payload)
    open, mode = true, view
    SetNuiFocus(true, true)
    SendNUIMessage({ type = 'open', view = view, payload = payload })
end
local function close()
    if consentToken then
        Core:Action('police:fingerprintConsent', { token = consentToken, accept = false }, function() end)
        consentToken = nil
    end
    open, mode = false, nil
    SetNuiFocus(false, false)
    SendNUIMessage({ type = 'close' })
end
local function openMDT()
    Core:Action('police:dashboard', {}, function(result)
        if result.ok then show('mdt', result) end
    end)
end
exports('OpenMDT', openMDT)
RegisterCommand('mdt', openMDT, false)
RegisterCommand('eggmdt', openMDT, false)
RegisterKeyMapping('eggmdt', 'Open police records', 'keyboard', 'F10')
RegisterCommand('infringements', function()
    Core:Action('police:notices', {}, function(result) if result.ok then show('notices', result) end end)
end, false)
RegisterCommand('policelocker', function()
    Core:Action('police:dashboard', {}, function(result)
        if result.ok and result.police then show('mdt', result) SendNUIMessage({ type = 'navigate', view = 'locker' }) end
    end)
end, false)
RegisterCommand('barrier', function(_, arguments)
    Core:Action('police:barrier', { remove = arguments[1] == 'remove', heading = GetEntityHeading(PlayerPedId()) }, function() end)
end, false)
RegisterCommand('anpr', function()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if vehicle == 0 then
        local point = GetEntityCoords(ped)
        vehicle = GetClosestVehicle(point.x, point.y, point.z, 25.0, 0, 70)
    end
    if vehicle == 0 then return end
    local plate = GetVehicleNumberPlateText(vehicle)
    Core:Action('police:dashboard', {}, function(result)
        if result.ok then show('mdt', result) SendNUIMessage({ type = 'navigate', view = 'anpr', plate = plate }) end
    end)
end, false)
RegisterCommand('bodycam', function()
    Core:Action('police:dashboard', {}, function(result)
        if not result.ok or not result.police then return end
        bodycam = not bodycam
        SendNUIMessage({ type = 'bodycam', enabled = bodycam, officer = result.name })
    end)
end, false)
RegisterNetEvent('egg_police:fingerprintRequest', function(request)
    if open then close() end
    consentToken = request.token
    show('consent', request)
    SetTimeout((request.expires or 30) * 1000, function()
        if consentToken == request.token then consentToken = nil close() end
    end)
end)

RegisterNetEvent('egg_police:notice', function(notice)
    SendNUIMessage({ type = 'noticeToast', payload = notice })
end)
RegisterNUICallback('close', function(_, callback) close() callback({ ok = true }) end)
RegisterNUICallback('action', function(data, callback)
    if not open or type(data) ~= 'table' or not allowed[data.action] then callback({ ok = false, error = 'Action unavailable.' }) return end
    local payload = type(data.payload) == 'table' and data.payload or {}
    if data.action == 'fingerprintConsent' then
        if not consentToken then callback({ ok = false, error = 'Request expired.' }) return end
        payload.token = consentToken
    end
    Core:Action('police:' .. data.action, payload, function(result)
        if data.action == 'fingerprintConsent' and result.ok then consentToken = nil close() end
        callback(result)
    end)
end)
-- A bodycam label is a roleplay status indicator, not a video recorder.
CreateThread(function()
    while true do
        Wait(5000)
        if bodycam then
            local player = exports.es_extended:getSharedObject().GetPlayerData()
            if not player.job or not Config.PoliceJobs[player.job.name] then
                bodycam = false
                SendNUIMessage({ type = 'bodycam', enabled = false })
            end
        end
    end
end)
AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then SetNuiFocus(false, false) end
end)
