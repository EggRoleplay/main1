fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Egg Roleplay'
description 'Egg police records, traffic infringements and court workflow'
version '0.1.0'
shared_script 'config.lua'
client_script 'client.lua'
server_script '@egg_core/server_api.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }
ui_page 'web/index.html'
files { 'web/index.html', 'web/style.css', 'web/app.js' }
dependencies { 'es_extended', 'oxmysql', 'egg_core' }
