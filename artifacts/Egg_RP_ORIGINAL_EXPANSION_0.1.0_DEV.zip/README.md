# Egg RP — original ESX expansion

This is a **development build for staging**, built from scratch around the supplied feature list and readable screenshots. It adds original city, work, drugs, crime, police/DOJ, dispatch, garage, staff and quality resources, with optional HUD/menu/spawn polish.

The original large ZIPs and videos could not be transferred. This is not a merged restore archive or a standalone ESX server. Your original Smart Phone Pro, standard Illenium Appearance, existing upper-right HUD and character backend must remain installed separately. No exact earlier fix is claimed without its source or description.

Start with [installation](docs/INSTALL.md), [feature coverage and limits](docs/FEATURES.md), [duplicate consolidation](docs/DEDUPE.md) and [staging checks](docs/LIVE_CHECKS.md).

## Development checks

```bash
python3 -m pip install --target /tmp/egg-validation -r tests/requirements.txt
PYTHONPATH=/tmp/egg-validation python3 tests/run_checks.py
PYTHONPATH=/tmp/egg-validation python3 'resources/[egg]/egg_spawn/tests/server_checks.py'
node 'resources/[egg]/egg_spawn/tests/ui.test.js'
python3 tools/check_assets.py
python3 tools/package.py
```

DOM checks use `jsdom@26.0.0` installed outside the checkout; see `docs/spawn.md` and `tests/ui_checks.js`. Tests use simulated services and cannot establish live FXServer readiness. Import numbered SQL into the existing ESX database and run the multiplayer checklist before rollout.

The generated archive is `artifacts/Egg_RP_ORIGINAL_EXPANSION_0.1.0_DEV.zip`. The package includes original source, migrations, config, tests and docs plus the OFL font licence used by the spawn screen; it excludes credentials, dependency caches and Git metadata.
